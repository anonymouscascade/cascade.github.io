import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class RunDriver {
    public static void main(String[] args) throws IOException {
        Scanner in = new Scanner(new File(args[0]));
        while (in.hasNext()) {

            String[] line = {in.nextLine().replaceAll("^\uFEFF", "")};
            Run.main(line);
        }
    }
}
