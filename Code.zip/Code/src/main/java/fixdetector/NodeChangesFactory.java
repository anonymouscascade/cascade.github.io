package fixdetector;

import com.github.gumtreediff.actions.model.Action;

import java.util.List;


public class NodeChangesFactory {

    public static NodeChanges getNodeChanges(String type, Action action, List<String> parsed){
        if(type.equals("UPD")){
            //in UPDATE actions we need 8 elements
            if (parsed.size() == 8) {
                return new UpdNodeChanges(action, parsed);
            } else {
                return null;
            }
        }
        else if(type.equals("DEL")){
            if (parsed.size() == 3 || parsed.size() == 4) {
                return new DelNodeChanges(action, parsed);
            } else {
                return null;
            }
        }
        else if(type.equalsIgnoreCase("INS")){
            if (parsed.size() >= 7 || parsed.size() <= 9) {
                return new InsNodeChanges(action, parsed);
            } else {
                return null;
            }
        }
        else if(type.equalsIgnoreCase("MOV")){
            if (parsed.size() == 3 || parsed.size() == 4 || parsed.size() == 7 || parsed.size() == 8) {
                return new MovNodeChanges(action, parsed);
            } else {
                return null;
            }
        }
        else{
            System.exit(1);
            return null;
        }

    }
}
