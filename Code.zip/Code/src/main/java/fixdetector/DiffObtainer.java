package fixdetector;

import com.github.gumtreediff.actions.ActionGenerator;
import com.github.gumtreediff.actions.model.Action;
import com.github.gumtreediff.client.Option;
import com.github.gumtreediff.client.Run;
import com.github.gumtreediff.gen.Generators;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.matchers.Matcher;
import com.github.gumtreediff.matchers.Matchers;
import com.github.gumtreediff.tree.ITree;
import com.github.gumtreediff.tree.TreeContext;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;


/**
 * In this class, the changes between two files (a vulnerable and fixed version) are obtained
 * gumtree is used to get the diff
 */
public class DiffObtainer {
    public static final String textElement = "TextElement";
    public static final String tagElement = "TagElement";
    public static final String javaDoc = "JavaDoc";
    public MappingStore mappings;

    public static void main(String[] args) throws IOException {
        DiffObtainer de = new DiffObtainer();
        String file1 = args[0];
        String file2 = args[1];
        System.out.println("running");
        de.run(file1, file2);

    }

    static TreeContext pickRightContext(Action action, TreeContext treeContext1, TreeContext treeContext2) {
        if (action.getName().equalsIgnoreCase("DEL")) {
            return treeContext1;
        } else {
            return treeContext2;
        }
    }

    /**
     * this method gets the best context for an action: when we have a delete action, more context is provided by the first file
     *
     * @param action
     * @param treeContext1
     * @param treeContext2
     * @return
     */
    static String getFormattedAction(Action action, TreeContext treeContext1, TreeContext treeContext2) {
        if (action.getName().equalsIgnoreCase("DEL")) {
            return action.format(treeContext1);
        } else {
            return action.format(treeContext2);
        }


    }

    /**
     * this method takes as input the path to two versions of a file that has changed, and returns a list of NodeChanges objects
     * which describe the changes that have happened to the file
     * @param file1
     * @param file2
     * @return
     * @throws IOException
     */
    public List<NodeChanges> run(String file1, String file2) throws IOException {

        //GumTree setup
        Run.initGenerators();
        System.out.println("Diff Generators created.");
        Option.Verbose.verbose = true;

        File fileRep1 = new File(file1);
        File fileRep2 = new File(file2);

        List<NodeChanges> nodeChanges = new ArrayList<NodeChanges>();
        boolean proceed = fileRep1.isFile() && fileRep2.isFile() && file1.endsWith(".java") && file2.endsWith(".java");
        if (proceed) {
            ITree src = Generators.getInstance().getTree(file1).getRoot();
            ITree dst = Generators.getInstance().getTree(file2).getRoot();


            //both files provide some context for the changes, so we get both contexts and use them later
            //as suitable
            TreeContext txc1 = Generators.getInstance().getTree(file1);
            TreeContext txc2 = Generators.getInstance().getTree(file2);
            Matcher m = Matchers.getInstance().getMatcher(src, dst); // retrieve the default matcher
            m.match();

            mappings = m.getMappings();

            ActionGenerator g = new ActionGenerator(src, dst, m.getMappings());
            g.generate();

            //GumTree provides a list of objects Action, which describe the changes that have happened
            List<Action> actions = g.getActions();


            //iterate those actions and format them into strings, by getting the right context and adding the line number of the code structure where the change has happened


            for (Action action : actions) {

                //modified the getPos() method from the original gumtree to provide the line number
                String toWrite = getFormattedAction(action, txc1, txc2) + " " + action.getNode().getPos() + "\n";


                List<String> matches = new ArrayList<String>();
                java.util.regex.Matcher mn = Pattern.compile("([^\"]\\S*|\".+?\")\\s*").matcher(toWrite);
                while (mn.find()) {
                    matches.add(mn.group(1));
                }

                TreeContext rightContext = pickRightContext(action, txc1, txc2);
                String nodeType = action.getNode().toPrettyString(rightContext).split(":")[0].trim();
                String parentNodeType = action.getNode().getParent().toPrettyString(rightContext).split(":")[0].trim();
                if (!nodeType.equalsIgnoreCase(textElement) &&
                        !(parentNodeType.equalsIgnoreCase(tagElement)
                                || parentNodeType.equalsIgnoreCase(textElement)
                                || parentNodeType.equalsIgnoreCase(javaDoc)
                                || nodeType.equalsIgnoreCase(tagElement)
                                || nodeType.equalsIgnoreCase(javaDoc))) {

                    NodeChanges nodeChange = NodeChangesFactory.getNodeChanges(matches.get(0), action, matches);
                    if (nodeChange != null) {
                        nodeChanges.add(nodeChange);

//                        if (nodeChange.action.getName().equalsIgnoreCase("INS")
//                                && nodeType.equalsIgnoreCase("SingleVariableDeclaration")
//                                && parentNodeType.equalsIgnoreCase("MethodDeclaration")){
//
//                            System.out.println("potential candidate!!!");
//                            System.out.println(nodeChange.toString());
//                        }
                    }
                }


            }


            System.out.println("Node Changes collected.");

        }
        return nodeChanges;
    }

    public MappingStore getMappings() {
        return mappings;
    }
}






