package fixdetector;

import com.github.gumtreediff.actions.model.Move;
import com.github.gumtreediff.gen.Generators;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.tree.ITree;
import com.github.gumtreediff.tree.TreeContext;
import javafx.util.Pair;
import util.SootUtilities;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

import static util.Constants.*;

/**
 * This class is used to identify vulnerable nodes based on the changes made to fix a vulnerability
 */
public class VulnerableNodeIdentifier {
    //we need these constants to build a matrix of changes
    static final int INSERT_CONST = 0;
    static final int UPDATE_CONST = 1;
    static final int MOV_CONST = 2;
    static final int DEL_CONST = 3;

    static final int IF_CONST = 0;
    static final int VAR_CONST = 1;
    static final int MD_CONST = 2;
    static final int MI_CONST = 3;
    static final int LOOP_CONST = 4;
    static final int OTHER = 5;


    public LinkedHashMap<Integer, LinkedHashMap<Integer, List<NodeChanges>>> groupedNodeChangesByFile = new LinkedHashMap<>();
    public String[] listOfFiles;
    public List<MappingStore> mappingStores = new ArrayList<>();


    LinkedHashMap<Integer, HashMap<String, List<NodeChanges>>> changesPerMethodinClass = new LinkedHashMap<>();

    List<Pair<Integer, ITree>> vulnerableDescendants = new ArrayList<>();
    List<Pair<Integer, ITree>> vulnerableNodes = new ArrayList<>();

    List<Pair<Integer, ITree>> vulnerablePredecessors = new ArrayList<>();
    List<Pair<Integer, ITree>> apiChangesNew = new ArrayList<>();
    List<Pair<Integer, ITree>> apiChangesOld = new ArrayList<>();

    //we need these for casualty changes analyses
    List<ITree> insertedMethodInvocations = new ArrayList<>();
    List<ITree> deletedMethodInvocations = new ArrayList<>();

    /**
     * This method takes two files as parameters and then it gets the changes between those two files
     * based on those changes it deduces the vulnerable nodes
     *
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        VulnerableNodeIdentifier vulnerableNodeIdentifier = new VulnerableNodeIdentifier();
        vulnerableNodeIdentifier.run(args);


    }

    static void matrixPopulator(int a, int index, NodeChanges nodeChangeSummary, ArrayList<Pair<Integer, Integer>>[][] factMatrix) {
        String nodeType = nodeChangeSummary.nodeType;

        switch (nodeType) {
            case IF_COND:
                factMatrix[0][index].add(new Pair<>(a, nodeChangeSummary.getLine()));
                break;
            case VAR_DECL:
            case ASSGNMT:
            case VAR_FRAG:
            case SINGLE_VAR_DECL:
                factMatrix[1][index].add(new Pair<>(a, nodeChangeSummary.getLine()));
                break;
            case MET_DECL:
                factMatrix[2][index].add(new Pair<>(a, nodeChangeSummary.getLine()));
                break;
            case MET_INV:
                factMatrix[3][index].add(new Pair<>(a, nodeChangeSummary.getLine()));
                break;
            case WHILE_STMT:
            case FOR_STMT:
                factMatrix[4][index].add(new Pair<>(a, nodeChangeSummary.getLine()));
                break;
            default:
                factMatrix[5][index].add(new Pair<>(a, nodeChangeSummary.getLine()));
                break;
        }

    }

    /**
     * this method is used to check if an element that has been inserted in a file is in the range of a method declaration that has been inserted
     * if it is, then the element should not be considered as a vulnerable node or descendant
     *
     * @param insertElementFileLine
     * @param insertedMethodDeclarationBounds
     * @return
     */
    static boolean checkForPresenceinMDBounds(Pair<Integer, Integer> insertElementFileLine,
                                              List<Pair<Integer, Pair<Integer, Integer>>> insertedMethodDeclarationBounds) {

        int ifFileId = insertElementFileLine.getKey();
        int ifLine = insertElementFileLine.getValue();

        ArrayList<Integer> counters = new ArrayList<>();
        for (int i = 0; i < insertedMethodDeclarationBounds.size(); i++) {
            Pair<Integer, Pair<Integer, Integer>> insertedMethodDeclarationBound = insertedMethodDeclarationBounds.get(i);
            int mdFileId = insertedMethodDeclarationBound.getKey();
            if (mdFileId == ifFileId) {
                counters.add(i);
            }

        }
        if (counters.size() > 0) {
            for (int counter : counters) {
                Pair<Integer, Integer> mdRange = insertedMethodDeclarationBounds.get(counter).getValue();
                if (ifLine >= mdRange.getKey() && ifLine <= mdRange.getValue()) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * this method is used to find the last child in a structural code element
     *
     * @param tree
     * @return
     */
    static int findLastChild(ITree tree) {
        int line;
        List<ITree> children = tree.getChildren();
        ITree lastChild = children.get(children.size() - 1);
        while (!lastChild.isLeaf()) {
            children = lastChild.getChildren();
            lastChild = children.get(children.size() - 1);
        }
        line = lastChild.getPos();
        return line;
    }

    static void printMatrix(ArrayList<Pair<Integer, Integer>>[][] factMatrix) {
        System.out.println("\tINSERT |" + "UPDATE |" + "MOVE |" + "DELETE ");
        for (int i = 0; i < factMatrix.length; i++) {
            if (i == 0) {
                System.out.print("IF");
            } else if (i == 1) {
                System.out.print("VAR");
            } else if (i == 2) {
                System.out.print("MD");
            } else if (i == 3) {
                System.out.print("MI");
            } else if (i == 4) {
                System.out.print("LOOP");
            } else if (i == 5) {
                System.out.println("Other");
            }
            for (int j = 0; j < factMatrix[i].length; j++) {
                System.out.print(factMatrix[i][j]);
                System.out.print("|");
            }
            System.out.println("\n");
        }
    }

    public List<ITree> getInsertedMethodInvocations() {
        return insertedMethodInvocations;
    }

    public List<ITree> getDeletedMethodInvocations() {
        return deletedMethodInvocations;
    }

    public LinkedHashMap<Integer, HashMap<String, List<NodeChanges>>> getChangesPerMethodinClass() {
        return changesPerMethodinClass;
    }

    //apiChangesNew gets apichanges that can be observed in the new version (updated or inserted parameters)
    public List<Pair<Integer, ITree>> getApiChangesNew() {
        return apiChangesNew;
    }

    //apiChangedOld gets api changes that can be observed in the old version (deleted parameters)
    public List<Pair<Integer, ITree>> getApiChangedOld() {
        return apiChangesOld;
    }

    public List<Pair<Integer, ITree>> getVulnerablePredecessors() {
        return vulnerablePredecessors;
    }

    public void setVulnerablePredecessors(List<Pair<Integer, ITree>> vulnerablePredecessors) {
        this.vulnerablePredecessors = vulnerablePredecessors;
    }

    public List<Pair<Integer, ITree>> getVulnerableDescendants() {
        return vulnerableDescendants;
    }

    public void setVulnerableDescendants(List<Pair<Integer, ITree>> vulnerableDescendants) {
        this.vulnerableDescendants = vulnerableDescendants;
    }

    public void addToVulnerableNodes(Pair<Integer, ITree> vulnerableNode) {
        vulnerableDescendants.add(vulnerableNode);
    }

    public void addToVulnerableDescendants(Pair<Integer, ITree> vulnerableDescendant) {
        vulnerableDescendants.add(vulnerableDescendant);
    }

    public List<Pair<Integer, ITree>> getVulnerableNodes() {
        return vulnerableNodes;
    }

    public void setVulnerableNodes(List<Pair<Integer, ITree>> vulnerableNodes) {
        this.vulnerableNodes = vulnerableNodes;
    }

    public void run(String[] args) throws IOException {
        listOfFiles = new String[args.length];
        listOfFiles = args.clone();
        DiffObtainer diffObtainer = new DiffObtainer();

        ArrayList<Pair<Integer, Integer>>[][] factMatrix = new ArrayList[6][4];
        for (int i = 0; i < factMatrix.length; i++) {
            for (int j = 0; j < factMatrix[i].length; j++) {
                factMatrix[i][j] = new ArrayList<>();
            }
        }
        for (int a = 0; a < args.length; a += 2) {
            try {
                List<NodeChanges> nodeChangesList = diffObtainer.run(args[a], args[a + 1]);
                mappingStores.add(diffObtainer.getMappings());


                LinkedHashMap<Integer, List<NodeChanges>> groupedNodeChanges = new LinkedHashMap<>();

                //group the same-line nodeChanges
                for (NodeChanges nodeChange : nodeChangesList) {
                    //check if that line of changes already exists
                    if (groupedNodeChanges.containsKey(nodeChange.line)) {
                        //if yes, check if the particular change exists
                        if (!groupedNodeChanges.get(nodeChange.line).contains(nodeChange)) {
                            List<NodeChanges> newNodeChanges = groupedNodeChanges.get(nodeChange.line);
                            newNodeChanges.add(nodeChange);
                            groupedNodeChanges.replace(nodeChange.line, newNodeChanges);
                        }


                    } else {
                        List<NodeChanges> newNodeChanges = new ArrayList<>();
                        newNodeChanges.add(nodeChange);
                        groupedNodeChanges.put(nodeChange.line, newNodeChanges);
                    }
                }


                groupedNodeChangesByFile.put(a, groupedNodeChanges);

                Iterator<Map.Entry<Integer, List<NodeChanges>>> nodeChangesIterator = groupedNodeChanges.entrySet().iterator();


                //iterate the node changes to create a matrix summarizing the type of changes
                //and lines where these changes happen, together with the file id (represented as a list <x, y>
                //the matrix will be used to pinpoint vulnerable nodes
                //   | INSERT| UPDATE|  MOVE | DELETE|
                //IF | <X, Y>| <X, Y>| <X, Y>| <X, Y>|
                //VAR| <X, Y>| <X, Y>| <X, Y>| <X, Y>|
                //MD | <X, Y>| <X, Y>| <X, Y>| <X, Y>|
                //MI | <X, Y>| <X, Y>| <X, Y>| <X, Y>|
                // LP | <X, Y>| <X, Y>| <X, Y>| <X, Y>|
                //OTH| <X, Y>| <X, Y>| <X, Y>| <X, Y>|
                while (nodeChangesIterator.hasNext()) {

                    Map.Entry<Integer, List<NodeChanges>> groupOfNodeChanges = nodeChangesIterator.next();

                    List<NodeChanges> lineNodeChanges = groupOfNodeChanges.getValue();

                    for (NodeChanges nodeChange : lineNodeChanges) {
                        if (nodeChange.actionType != null) {
                            if (nodeChange.actionType.equalsIgnoreCase("INS")) {
                                matrixPopulator(a, INSERT_CONST, nodeChange, factMatrix);
                            } else if (nodeChange.actionType.equalsIgnoreCase("UPD")) {
                                matrixPopulator(a, UPDATE_CONST, nodeChange, factMatrix);
                            } else if (nodeChange.actionType.equalsIgnoreCase("MOV")) {
                                matrixPopulator(a, MOV_CONST, nodeChange, factMatrix);
                            } else {
                                matrixPopulator(a, DEL_CONST, nodeChange, factMatrix);
                            }
                        }

                    }

                }

            } catch (FileNotFoundException foe) {
                System.out.println("File not found: " + foe.getMessage());

            }
//            finally {
//                continue;
//            }
        }

        //printMatrix(factMatrix);
        rules(factMatrix);

    }

    /**
     * get the method of each change and update the hashmap
     *
     * @param vulnerableNode
     * @param involvedFileID
     * @param nodeChange
     * @throws IOException
     */
    public void gatherChangesPerMethod(ITree vulnerableNode, int involvedFileID, NodeChanges nodeChange, boolean isDescendant) throws IOException {
        TreeContext treeContext = Generators.getInstance().getTree(listOfFiles[involvedFileID]);
        ITree methodDeclaration = SootUtilities.getMethod(vulnerableNode, treeContext);
        boolean isFileOfOriginCorrect = false;
        if (involvedFileID % 2 == 0) {
            isFileOfOriginCorrect = findOriginOfMethodDeclaration(treeContext, methodDeclaration);
        } else {
            isFileOfOriginCorrect = !findOriginOfMethodDeclaration(treeContext, methodDeclaration);
        }

        if (isDescendant || isFileOfOriginCorrect) {
            //if the node is found to be descendant, then we need to find the mapped method in the vulnerable version
            methodDeclaration = SootUtilities.getMappedMethod(methodDeclaration, mappingStores.get(involvedFileID / 2));
        }


        if (methodDeclaration != null) {
            int line = methodDeclaration.getPos();
            String methodName = SootUtilities.getMethodName(methodDeclaration, treeContext) + ": " + line;
            HashMap<String, List<NodeChanges>> changesPerMethod;
            if (changesPerMethodinClass.containsKey(involvedFileID)) {
                changesPerMethod = changesPerMethodinClass.get(involvedFileID);
                List<NodeChanges> nodeChanges;
                if (changesPerMethod.containsKey(methodName)) {
                    nodeChanges = changesPerMethod.get(methodName);
                    if (!nodeChanges.contains(nodeChange)) {
                        nodeChanges.add(nodeChange);

                    }
                } else {
                    nodeChanges = new ArrayList<>();
                    nodeChanges.add(nodeChange);
                }

                changesPerMethod.put(methodName, nodeChanges);
            } else {
                changesPerMethod = new HashMap<>();
                List<NodeChanges> nodeChanges = new ArrayList<>();
                nodeChanges.add(nodeChange);
                changesPerMethod.put(methodName, nodeChanges);
            }


            changesPerMethodinClass.put(involvedFileID, changesPerMethod);
        }
    }

    public boolean findOriginOfMethodDeclaration(TreeContext firstTreeContext, ITree iTree) {
        ITree root = firstTreeContext.getRoot();
        Iterator<ITree> iTrees = root.breadthFirst().iterator();
        while (iTrees.hasNext()) {
            ITree next = iTrees.next();
            if (next.isIsomorphicTo(iTree)) {
                return true;
            }
        }
        return false;

    }

    /**
     * @param firstConstant
     * @param secondConstant
     * @param factMatrix
     * @param vulnerableNodes
     * @param type
     */
    public void findVulnerableNode(int firstConstant, int secondConstant,
                                   ArrayList<Pair<Integer, Integer>>[][] factMatrix, List<Pair<Integer, ITree>> vulnerableNodes, String type) throws IOException {
        List<Pair<Integer, Integer>> involvedLines = factMatrix[firstConstant][secondConstant];
        for (Pair<Integer, Integer> involvedFileLine : involvedLines) {
            int involvedLine = involvedFileLine.getValue();

            int involvedFileID = involvedFileLine.getKey();

            LinkedHashMap<Integer, List<NodeChanges>> groupedNodeChanges = groupedNodeChangesByFile.get(involvedFileID);
            List<NodeChanges> lineNodeChangesList = groupedNodeChanges.get(involvedLine);
            for (NodeChanges lineNodeChanges : lineNodeChangesList) {
                if (lineNodeChanges.getNodeType().equalsIgnoreCase(type)) {
                    ITree node = lineNodeChanges.action.getNode();
                    Pair<Integer, ITree> vulnerableNode = new Pair<>(involvedFileID, node);
                    if (!vulnerableNodes.contains(vulnerableNode)) {
                        vulnerableNodes.add(vulnerableNode);
                        gatherChangesPerMethod(vulnerableNode.getValue(), involvedFileID, lineNodeChanges, false);
                    }
                    TreeContext treeContext = Generators.getInstance().getTree(listOfFiles[involvedFileID]);
                    String nodeType = node.toPrettyString(treeContext).split(":")[0];
                    if (lineNodeChanges.getActionType().equalsIgnoreCase("DEL") && nodeType.equalsIgnoreCase(MET_INV)) {
                        deletedMethodInvocations.add(node);
                    }
                }
            }
        }
    }

    /**
     * Find the vulnerable node for variable declaration which has more than one type that it can match to:
     * VARDECL, FIELDDECL, VARFRAG
     *
     * @param firstConstant
     * @param secondConstant
     * @param factMatrix
     * @param vulnerableNodes
     * @param types
     */
    public void findVulnerableNode(int firstConstant, int secondConstant,
                                   ArrayList<Pair<Integer, Integer>>[][] factMatrix, List<Pair<Integer, ITree>> vulnerableNodes, List<String> types) throws IOException {
        List<Pair<Integer, Integer>> involvedLines = factMatrix[firstConstant][secondConstant];
        for (Pair<Integer, Integer> involvedFileLine : involvedLines) {
            int involvedLine = involvedFileLine.getValue();

            int involvedFileID = involvedFileLine.getKey();

            LinkedHashMap<Integer, List<NodeChanges>> groupedNodeChanges = groupedNodeChangesByFile.get(involvedFileID);
            List<NodeChanges> lineNodeChangesList = groupedNodeChanges.get(involvedLine);
            for (NodeChanges lineNodeChanges : lineNodeChangesList) {

                if (types.contains(lineNodeChanges.getNodeType())) {
                    Pair<Integer, ITree> vulnerableNode = new Pair<>(involvedFileID, lineNodeChanges.action.getNode());
                    if (!vulnerableNodes.contains(vulnerableNode)) {
                        vulnerableNodes.add(vulnerableNode);
                        gatherChangesPerMethod(vulnerableNode.getValue(), involvedFileID, lineNodeChanges, false);
                        TreeContext treeContext = Generators.getInstance().getTree(listOfFiles[involvedFileID]);
                        boolean isApiChange = checkIfApiChange(lineNodeChanges.action.getNode(), treeContext);
                        if (isApiChange) {

                            Pair<Integer, ITree> methodDeclaration = new Pair<>(involvedFileID, lineNodeChanges.action.getNode().getParent());
                            if (DEBUG) {
                                System.out.println("potential candidate!!!");
                                System.out.println(lineNodeChanges.toString());
                                System.out.println(lineNodeChanges.line);
                                System.out.println(listOfFiles[involvedFileID]);
                                String methodName = SootUtilities.getMethodName(lineNodeChanges.action.getNode().getParent(), treeContext);
                                System.out.println(methodName);
                            }
                            if (secondConstant == 0 || secondConstant == 1 || secondConstant == 2) {
                                if (!apiChangesNew.contains(methodDeclaration)) {
                                    apiChangesNew.add(methodDeclaration);
                                }
                            } else {
                                if (!apiChangesOld.contains(methodDeclaration)) {
                                    apiChangesOld.add(methodDeclaration);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * this method is used to get the name of declared methods that have been added
     *
     * @param insertMethodDeclarationLines
     * @return
     * @throws IOException
     */

    public List<String> getMethodNames(List<Pair<Integer, Integer>> insertMethodDeclarationLines,
                                       List<Pair<Integer, Pair<Integer, Integer>>> insertedMethodDeclarationBounds, List<Pair<Integer, ITree>> vulnerableDescendants)
            throws IOException {
        List<String> methodDeclarationNames = new ArrayList<>();

        //for every pair of file, line number in which we know a method has been added
        for (Pair<Integer, Integer> insertMethodDeclarationFileLine : insertMethodDeclarationLines) {

            //the first number in the pair is the ID of the file where the change has happened
            int insertMethodDeclarationFile = insertMethodDeclarationFileLine.getKey();

            //get all the changes that have happened in that file
            LinkedHashMap<Integer, List<NodeChanges>> groupedNodeChanges = groupedNodeChangesByFile.get(insertMethodDeclarationFile);

            //get the number of the line from the pair, which is the second number in the pair
            int insertMethodDeclarationLine = insertMethodDeclarationFileLine.getValue();


            //get the  changes that have happened in that line
            List<NodeChanges> nodeChangesList = groupedNodeChanges.get(insertMethodDeclarationLine);

            //get the context of the second file (since this method is being used for insert actions); if this changes later
            //the context also needs to change
            TreeContext treeContext = Generators.getInstance().getTree(listOfFiles[insertMethodDeclarationFile + 1]);

            //in those nodechanges
            if (!nodeChangesList.isEmpty()) {
                for (NodeChanges nodeChanges : nodeChangesList) {

                    //check for MethodDeclarations ones
                    if (nodeChanges.getNodeType().equalsIgnoreCase(MET_DECL)) {
                        Pair<Integer, ITree> vulnerableDescendant = new Pair<>(insertMethodDeclarationFile, nodeChanges.action.getNode());
                        vulnerableDescendants.add(vulnerableDescendant);
                        //get their children
                        List<ITree> methodDeclarationChildren = nodeChanges.action.getNode().getChildren();

                        for (ITree methodDeclarationChild : methodDeclarationChildren) {

                            //get their name by checking for nodes of type SimpleName
                            if (methodDeclarationChild.toPrettyString(treeContext).contains(SIMPLE_NAME) &&
                                    methodDeclarationChild.hasLabel()) {

                                String methodDeclaration = methodDeclarationChild.getLabel();
                                methodDeclarationNames.add(methodDeclaration);
                            }

                        }

                        //find the last line that belongs to the method delcaration
                        //this is needed to check if variables or if conditions being added are part of a method declaration or not
                        int lowerBoundary = findLastChild(nodeChanges.action.getNode());
                        Pair<Integer, Integer> methodDeclarationBoundaries = new Pair<>(insertMethodDeclarationLine, lowerBoundary);
                        Pair<Integer, Pair<Integer, Integer>> methodDeclarationBoundariesPerFile
                                = new Pair<>(insertMethodDeclarationFile, methodDeclarationBoundaries);
                        insertedMethodDeclarationBounds.add(methodDeclarationBoundariesPerFile);


                    }

                }
            }
        }
        return methodDeclarationNames;
    }

    public List<Pair<Integer, ITree>> getVulnerableMethodInvocations(List<Pair<Integer, Integer>> insertMethodInvocationsLines,
                                                                     List<String> methodDeclarationNames,
                                                                     List<Pair<Integer, Pair<Integer, Integer>>> insertedMethodDeclarationBounds) throws IOException {
        List<Pair<Integer, ITree>> vulnerableMethodInvocations = new ArrayList<>();

        for (Pair<Integer, Integer> insertMethodInvocationFileLine : insertMethodInvocationsLines) {

            LinkedHashMap<Integer, List<NodeChanges>> groupedNodeChanges
                    = groupedNodeChangesByFile.get(insertMethodInvocationFileLine.getKey());

            boolean sameFile = checkForPresenceinMDBounds(insertMethodInvocationFileLine, insertedMethodDeclarationBounds);
            if (!sameFile) {
                int insertMethodInvocationLine = insertMethodInvocationFileLine.getValue();

                TreeContext treeContext = Generators.getInstance().getTree(listOfFiles[insertMethodInvocationFileLine.getKey() + 1]);

                List<NodeChanges> nodeChangesList = groupedNodeChanges.get(insertMethodInvocationLine);

                for (NodeChanges nodeChange : nodeChangesList) {
                    List<ITree> methodInvocationChildren = nodeChange.action.getNode().getChildren();
                    for (ITree methodInvocationChild : methodInvocationChildren) {
                        if (methodInvocationChild.toPrettyString(treeContext).contains(SIMPLE_NAME) &&
                                methodInvocationChild.hasLabel()) {
                            if (methodDeclarationNames.contains(methodInvocationChild.getLabel())) {
                                Pair<Integer, ITree> vulnerableNode = new Pair(insertMethodInvocationFileLine.getKey(), nodeChange.action.getNode());
                                if (!vulnerableMethodInvocations.contains(vulnerableNode)) {
                                    vulnerableMethodInvocations.add(vulnerableNode);
                                    gatherChangesPerMethod(vulnerableNode.getValue(), insertMethodInvocationFileLine.getKey(), nodeChange, false);
                                }
                            }
                        }
                    }
                }
            }
        }


        return vulnerableMethodInvocations;
    }

    public List<ITree> getMovedNodes(int file, int firstLine, int lastLine,
                                     ArrayList<Pair<Integer, Integer>>[][] factMatrix,
                                     List<Pair<Integer, Pair<Integer, Integer>>> insertedMethodDeclarationBounds) {
        List<ITree> movedNodes = new ArrayList<>();
        int[] constants = {OTHER, MD_CONST, MI_CONST, IF_CONST, LOOP_CONST, VAR_CONST};
        for (int constant : constants) {
            getMovedNodes(constant, firstLine, lastLine, factMatrix, file, insertedMethodDeclarationBounds, movedNodes);
        }
        return movedNodes;
    }

    public void getMovedNodes(int constantValue, int firstLine, int lastLine,
                              ArrayList<Pair<Integer, Integer>>[][] factMatrix, int file,
                              List<Pair<Integer, Pair<Integer, Integer>>> insertedMethodDeclarationBounds, List<ITree> movedNodes
    ) {
        if (factMatrix[constantValue][MOV_CONST].size() > 0) {
            List<Pair<Integer, Integer>> moveOtherLines = factMatrix[constantValue][MOV_CONST];
            for (Pair<Integer, Integer> moveOtherFileLine : moveOtherLines) {
                int moveOtherFile = moveOtherFileLine.getKey();
                if (file == moveOtherFile) {
                    boolean sameFile = checkForPresenceinMDBounds(moveOtherFileLine, insertedMethodDeclarationBounds);
                    if (!sameFile) {

                        LinkedHashMap<Integer, List<NodeChanges>> groupedNodeChanges = groupedNodeChangesByFile.get(moveOtherFile);

                        int moveOtherLine = moveOtherFileLine.getValue();

                        List<NodeChanges> lineNodeChangesList = groupedNodeChanges.get(moveOtherLine);
                        if (!lineNodeChangesList.isEmpty()) {
                            for (NodeChanges nodeChanges : lineNodeChangesList) {
                                if (nodeChanges != null && nodeChanges.getAction() != null) {

                                    if (nodeChanges.getAction().equals("MOV")) {
                                        Move moveAction = (Move) nodeChanges.action;
                                        ITree node = moveAction.getParent();
                                        if (node.getPos() >= firstLine && node.getPos() <= lastLine) {
                                            movedNodes.add(moveAction.getNode());
                                        }
                                    }
                                }
                            }
                        }

                    }
                }

            }
        }
    }

    public ITree getVulnerableParent(ITree node, MappingStore mappingStore, TreeContext treeContext) {
        if (mappingStore.hasDst(node.getParent())) {
            if (!node.getParent().toPrettyString(treeContext).equalsIgnoreCase(BLOCK))
                return node.getParent();
        }
        return null;
    }

    public boolean checkIfApiChange(ITree node, TreeContext treeContext) {
        String nodeType = node.toPrettyString(treeContext).split(":")[0].trim();
        String parentNodeType = node.getParent().toPrettyString(treeContext).split(":")[0].trim();

        return nodeType.equalsIgnoreCase(SINGLE_VAR_DECL) && parentNodeType.equalsIgnoreCase(MET_DECL);
    }

    public void rules(ArrayList<Pair<Integer, Integer>>[][] factMatrix) throws IOException {

        List<Pair<Integer, Pair<Integer, Integer>>> insertedMethodDeclarationBounds = new ArrayList<>();
        List<Pair<Integer, ITree>> vulnerableNodes = new ArrayList<>();
        //we need a separate list for nodes that have been inserted, because differently from other nodes
        List<Pair<Integer, ITree>> vulnerableDescendants = new ArrayList<>();


        //CHECK IF THERE IS A METHOD DECLARATION ADDED
        //IF YES, CHECK ITS LINE NUMBER AND NAME
        //ADD THE METHOD DECLARATION IN VULNERABLE DESCENDANT LIST
        //CHECK IF THERE IS A METHOD INVOCATION
        //CHECK IF THE METHOD INVOCATION HAS A CHILD WITH SIMPLE NAME METHOD DECLARATION NAME
        //IF YES, THE PLACE WHERE THE METHOD IS INVOKED IS VULNERABLE
        if (factMatrix[MD_CONST][INSERT_CONST].size() > 0) {
            List<Pair<Integer, Integer>> insertMethodDeclarationLines = factMatrix[MD_CONST][INSERT_CONST];
            List<String> methodDeclarationNames = getMethodNames(insertMethodDeclarationLines, insertedMethodDeclarationBounds, vulnerableDescendants);


            if (factMatrix[MI_CONST][INSERT_CONST].size() > 0) {

                List<Pair<Integer, Integer>> insertMethodInvocationsLines = factMatrix[MI_CONST][INSERT_CONST];

                List<Pair<Integer, ITree>> vulnerableInvocations = getVulnerableMethodInvocations(insertMethodInvocationsLines, methodDeclarationNames, insertedMethodDeclarationBounds);
                for (Pair<Integer, ITree> vulnerableInvocation : vulnerableInvocations) {

                    int fileNumber = vulnerableInvocation.getKey();
                    MappingStore mappingStore = mappingStores.get(fileNumber / 2);
                    TreeContext treeContext = Generators.getInstance().getTree(listOfFiles[fileNumber]);
                    ITree node = getVulnerableParent(vulnerableInvocation.getValue(), mappingStore, treeContext);
                    //the changes per method are gathered in the getVulnerableMethodInvoactions and not here
                    if (node != null) {
                        Pair<Integer, ITree> vulnerableNode = new Pair<>(fileNumber, node);
                        if (!vulnerableNodes.contains(vulnerableNode)) {
                            vulnerableNodes.add(vulnerableNode);
                        }
                    } else if (!vulnerableDescendants.contains(vulnerableInvocation)) {
                        vulnerableDescendants.add(vulnerableInvocation);
                    }
                }
            }
        }

        //CHECK IF THERE IS AN IF CONDITION ADDED
        //CHECK IF IT'S IN THE SAME FILE WITH THE METHOD DECLARATION
        //CHECK IF ITS LINE NUMBER IS IN THE RANGE OF THE METHOD DELCARATION
        //IF BEFORE, ANYTHING DEPENDENT ON THE IF CONDITION IS VULNERABLE

        if (factMatrix[IF_CONST][INSERT_CONST].size() > 0) {
            List<Pair<Integer, Integer>> insertIfConditionLines = factMatrix[IF_CONST][INSERT_CONST];
            for (Pair<Integer, Integer> insertIfConditionFileLine : insertIfConditionLines) {
                int insertIfConditionFile = insertIfConditionFileLine.getKey();
                boolean sameFile = checkForPresenceinMDBounds(insertIfConditionFileLine, insertedMethodDeclarationBounds);
                if (!sameFile) {

                    LinkedHashMap<Integer, List<NodeChanges>> groupedNodeChanges = groupedNodeChangesByFile.get(insertIfConditionFile);

                    int insertIfConditionLine = insertIfConditionFileLine.getValue();

                    List<NodeChanges> lineNodeChangesList = groupedNodeChanges.get(insertIfConditionLine);
                    if (!lineNodeChangesList.isEmpty()) {
                        for (NodeChanges nodeChanges : lineNodeChangesList) {
                            if (nodeChanges.getNodeType().equalsIgnoreCase(IF_COND)) {
                                int firstLine = nodeChanges.action.getNode().getPos();
                                int lastLine = findLastChild(nodeChanges.action.getNode());

                                List<ITree> movedNodes = getMovedNodes(insertIfConditionFile, firstLine, lastLine, factMatrix, insertedMethodDeclarationBounds);
                                for (ITree movedNode : movedNodes) {
                                    Pair<Integer, ITree> vulnerableNode = new Pair<>(insertIfConditionFile, movedNode);
                                    if (!vulnerableNodes.contains(vulnerableNode)) {
                                        vulnerableNodes.add(vulnerableNode);
                                        gatherChangesPerMethod(vulnerableNode.getValue(), insertIfConditionFile, nodeChanges, false);
                                    }
                                }


                                Pair<Integer, ITree> vulnerableDescendant = new Pair<>(insertIfConditionFile, nodeChanges.action.getNode());
                                if (!vulnerableDescendants.contains(vulnerableDescendant)) {
                                    vulnerableDescendants.add(vulnerableDescendant);
                                    gatherChangesPerMethod(vulnerableDescendant.getValue(), insertIfConditionFile, nodeChanges, true);
                                }
                            }
                        }
                    }
                }

            }
        }

        //CHECK IF THERE IS A VARIABLE ADDED
        //CHECK IF ITS LINE NUMBER IS AFTER OR BEFORE THE METHOD DECLARATION
        //IF AFTER, IGNORE
        //IF BEFORE, ANYTHING DEPENDENT ON THE VARIABLE IS VULNERABLE

        if (factMatrix[VAR_CONST][INSERT_CONST].size() > 0) {
            List<Pair<Integer, Integer>> insertVariableLines = factMatrix[VAR_CONST][INSERT_CONST];
            for (Pair<Integer, Integer> insertVariableFileLine : insertVariableLines) {
                int insertVariableFile = insertVariableFileLine.getKey();
                boolean sameFile = checkForPresenceinMDBounds(insertVariableFileLine, insertedMethodDeclarationBounds);
                if (!sameFile) {

                    LinkedHashMap<Integer, List<NodeChanges>> groupedNodeChanges = groupedNodeChangesByFile.get(insertVariableFile);

                    int insertVariableLine = insertVariableFileLine.getValue();

                    List<NodeChanges> lineNodeChangesList = groupedNodeChanges.get(insertVariableLine);
                    if (!lineNodeChangesList.isEmpty()) {

                        for (NodeChanges nodeChanges : lineNodeChangesList) {
                            if (nodeChanges.getNodeType().equalsIgnoreCase(VAR_DECL) || nodeChanges.getNodeType().equalsIgnoreCase(FIELD_DECL)
                                    || nodeChanges.getNodeType().equalsIgnoreCase(VAR_FRAG) || nodeChanges.getNodeType().equalsIgnoreCase(SINGLE_VAR_DECL)) {
                                Pair<Integer, ITree> vulnerableDescendant = new Pair<>(insertVariableFile, nodeChanges.action.getNode());
                                TreeContext treeContext = Generators.getInstance().getTree(listOfFiles[insertVariableFile]);
                                MappingStore mappingStore = mappingStores.get(insertVariableFile / 2);
                                ITree vulnerableNode = getVulnerableParent(nodeChanges.action.getNode(), mappingStore, treeContext);
                                if (vulnerableNode != null) {
                                    Pair<Integer, ITree> vulnerableParent = new Pair<>(insertVariableFile, vulnerableNode);
                                    if (!vulnerableNodes.contains(vulnerableParent)) {
                                        vulnerableNodes.add(vulnerableParent);
                                        gatherChangesPerMethod(vulnerableParent.getValue(), insertVariableFile, nodeChanges, false);
                                    }

                                } else if (!vulnerableDescendants.contains(vulnerableDescendant)) {
                                    vulnerableDescendants.add(vulnerableDescendant);
                                    gatherChangesPerMethod(vulnerableDescendant.getValue(), insertVariableFile, nodeChanges, true);
                                }
                                //obtaining potential api changes
                                String parentNodeType = nodeChanges.action.getNode().getParent().toPrettyString(treeContext).split(":")[0];
                                if (nodeChanges.getNodeType().equalsIgnoreCase("SingleVariableDeclaration")
                                        && parentNodeType.equalsIgnoreCase("MethodDeclaration")) {
                                    if (DEBUG) {
                                        System.out.println("potential candidate!!!");
                                        System.out.println(nodeChanges.toString());
                                        System.out.println(nodeChanges.line);
                                        System.out.println(listOfFiles[insertVariableFile]);
                                        String methodName = SootUtilities.getMethodName(nodeChanges.action.getNode().getParent(), treeContext);
                                        System.out.println(methodName);
                                    }
                                    Pair<Integer, ITree> methodDeclaration = new Pair<>(insertVariableFile, nodeChanges.action.getNode());
                                    if (!apiChangesNew.contains(methodDeclaration)) {
                                        apiChangesNew.add(methodDeclaration);
                                    }

                                }

                                //check if the node that was changed is part of an API change
                                boolean isApiChange = checkIfApiChange(nodeChanges.action.getNode().getParent(), treeContext);
                                if (isApiChange) {
                                    Pair<Integer, ITree> methodDeclaration = new Pair<>(insertVariableFile, nodeChanges.action.getNode().getParent());
                                    if (DEBUG) {
                                        System.out.println("potential candidate!!!");
                                        System.out.println(nodeChanges.toString());
                                        System.out.println(nodeChanges.line);
                                        System.out.println(listOfFiles[insertVariableFile]);
                                        String methodName = SootUtilities.getMethodName(nodeChanges.action.getNode().getParent(), treeContext);
                                        System.out.println(methodName);
                                    }
                                    if (!apiChangesNew.contains(methodDeclaration)) {
                                        apiChangesNew.add(methodDeclaration);
                                    }
                                }
                            }
                        }
                    }
                }

            }
        }

        //CHECK IF THERE IS A LOOP ADDED
        //CHECK IF ITS LINE NUMBER IS AFTER OR BEFORE THE METHOD DECLARATION
        //IF AFTER, IGNORE
        //IF BEFORE, ANYTHING DEPENDENT ON THE VARIABLE IS VULNERABLE
        if (factMatrix[LOOP_CONST][INSERT_CONST].size() > 0) {
            List<Pair<Integer, Integer>> insertLoopLines = factMatrix[LOOP_CONST][INSERT_CONST];
            for (Pair<Integer, Integer> insertLoopFileLine : insertLoopLines) {
                int insertLoopFile = insertLoopFileLine.getKey();
                boolean sameFile = checkForPresenceinMDBounds(insertLoopFileLine, insertedMethodDeclarationBounds);
                if (!sameFile) {

                    LinkedHashMap<Integer, List<NodeChanges>> groupedNodeChanges = groupedNodeChangesByFile.get(insertLoopFile);

                    int insertLoopLine = insertLoopFileLine.getValue();

                    List<NodeChanges> lineNodeChangesList = groupedNodeChanges.get(insertLoopLine);
                    if (!lineNodeChangesList.isEmpty()) {
                        for (NodeChanges nodeChanges : lineNodeChangesList) {
                            if (nodeChanges.getNodeType().equalsIgnoreCase(WHILE_STMT) || nodeChanges.getNodeType().equalsIgnoreCase(FOR_STMT)) {
                                Pair<Integer, ITree> vulnerableDescendant = new Pair<>(insertLoopFile, nodeChanges.action.getNode());
                                int firstLine = nodeChanges.action.getNode().getPos();
                                int lastLine = findLastChild(nodeChanges.action.getNode());
                                List<ITree> movedNodes = getMovedNodes(insertLoopFile, firstLine, lastLine, factMatrix, insertedMethodDeclarationBounds);
                                for (ITree movedNode : movedNodes) {
                                    Pair<Integer, ITree> vulnerableNode = new Pair<>(insertLoopFile, movedNode);
                                    if (!vulnerableNodes.contains(vulnerableNode)) {
                                        vulnerableNodes.add(vulnerableNode);
                                        gatherChangesPerMethod(vulnerableNode.getValue(), insertLoopFile, nodeChanges, false);
                                    }
                                }
                                if (!vulnerableDescendants.contains(vulnerableDescendant)) {
                                    vulnerableDescendants.add(vulnerableDescendant);
                                    gatherChangesPerMethod(vulnerableDescendant.getValue(), insertLoopFile, nodeChanges, true);
                                }
                            }
                        }
                    }
                }

            }
        }

        if (factMatrix[MI_CONST][INSERT_CONST].size() > 0) {
            List<Pair<Integer, Integer>> insertMethodInvocationLines = factMatrix[MI_CONST][INSERT_CONST];
            for (Pair<Integer, Integer> insertMethodDeclarationFileLines : insertMethodInvocationLines) {
                int insertMethodDeclarationFile = insertMethodDeclarationFileLines.getKey();
                boolean sameFile = checkForPresenceinMDBounds(insertMethodDeclarationFileLines, insertedMethodDeclarationBounds);
                if (!sameFile) {
                    int insertMethodDeclarationLine = insertMethodDeclarationFileLines.getValue();

                    LinkedHashMap<Integer, List<NodeChanges>> groupedNodeChanges = groupedNodeChangesByFile.get(insertMethodDeclarationFile);

                    List<NodeChanges> groupedNodeChangesPerLine = groupedNodeChanges.get(insertMethodDeclarationLine);

                    for (NodeChanges nodeChange : groupedNodeChangesPerLine) {
                        if (nodeChange.getNodeType().equalsIgnoreCase(MET_INV)) {
                            //here we need to make sure the node was being inserted cause there are cases when nodes are inserted and deleted in the same line
                            if (nodeChange.getActionType().equalsIgnoreCase("INS")) {
                                if (nodeChange.action.getNode().getParent() != null) {
                                    ITree parent = nodeChange.action.getNode().getParent();
                                    if (nodeChange.parNodeType.equalsIgnoreCase(MET_INV) || nodeChange.parNodeType.equalsIgnoreCase(VAR_DECL) || nodeChange.parNodeType.equalsIgnoreCase(ASSGNMT)) {
                                        MappingStore mappingStore = mappingStores.get(insertMethodDeclarationFile / 2);

                                        if (mappingStore.hasDst(parent)) {
                                            ITree src = mappingStore.getSrc(parent);
                                            Pair<Integer, ITree> vulnerableNode = new Pair<>(insertMethodDeclarationFile, src);
                                            if (!vulnerableNodes.contains(vulnerableNode)) {
                                                vulnerableNodes.add(vulnerableNode);
                                                gatherChangesPerMethod(vulnerableNode.getValue(), insertMethodDeclarationFile, nodeChange, false);
                                            }

                                        } else {
                                            Pair<Integer, ITree> vulnerableDescendant = new Pair<>(insertMethodDeclarationFile, parent);
                                            if (!vulnerableDescendants.contains(vulnerableDescendant)) {
                                                vulnerableDescendants.add(vulnerableDescendant);
                                                gatherChangesPerMethod(vulnerableDescendant.getValue(), insertMethodDeclarationFile, nodeChange, true);
                                            }

                                        }

                                    }
                                } else {
                                    Pair<Integer, ITree> vulnerableDescendant = new Pair<>(insertMethodDeclarationFile, nodeChange.action.getNode());
                                    if (!vulnerableDescendants.contains(vulnerableDescendant)) {
                                        vulnerableDescendants.add(vulnerableDescendant);
                                        gatherChangesPerMethod(vulnerableDescendant.getValue(), insertMethodDeclarationFile, nodeChange, true);
                                    }
                                }
                            }
                            insertedMethodInvocations.add(nodeChange.getAction().getNode());
                        }
                    }
                }
            }
        }
        List<String> namedVariables = new ArrayList<>();
        namedVariables.add(IF_COND);
        namedVariables.add(VAR_DECL);
        namedVariables.add(VAR_FRAG);
        namedVariables.add(SINGLE_VAR_DECL);
        namedVariables.add(FIELD_DECL);
        namedVariables.add(WHILE_STMT);
        namedVariables.add(FOR_STMT);
        namedVariables.add(MET_DECL);
        namedVariables.add(MET_INV);
        if (factMatrix[OTHER][INSERT_CONST].size() > 0) {
            List<Pair<Integer, Integer>> insertOtherLines = factMatrix[OTHER][INSERT_CONST];
            for (Pair<Integer, Integer> insertOtherFileLine : insertOtherLines) {
                int insertOtherFile = insertOtherFileLine.getKey();
                boolean sameFile = checkForPresenceinMDBounds(insertOtherFileLine, insertedMethodDeclarationBounds);
                if (!sameFile) {
                    LinkedHashMap<Integer, List<NodeChanges>> groupedNodeChanges = groupedNodeChangesByFile.get(insertOtherFile);
                    int insertOtherLine = insertOtherFileLine.getValue();

                    List<NodeChanges> lineNodeChangesList = groupedNodeChanges.get(insertOtherLine);
                    if (!lineNodeChangesList.isEmpty()) {
                        for (NodeChanges nodeChanges : lineNodeChangesList) {
                            if (!namedVariables.contains(nodeChanges.getNodeType().trim())) {
                                Pair<Integer, ITree> vulnerableDescendant = new Pair<>(insertOtherFile, nodeChanges.action.getNode());
                                TreeContext treeContext = Generators.getInstance().getTree(listOfFiles[insertOtherFile]);
                                MappingStore mappingStore = mappingStores.get(insertOtherFile / 2);
                                ITree vulnerableNode = getVulnerableParent(nodeChanges.action.getNode(), mappingStore, treeContext);
                                if (vulnerableNode != null) {
                                    Pair<Integer, ITree> vulnerableParent = new Pair<>(insertOtherFile, vulnerableNode);
                                    if (!vulnerableNodes.contains(vulnerableParent)) {
                                        vulnerableNodes.add(vulnerableParent);
                                        gatherChangesPerMethod(vulnerableParent.getValue(), insertOtherFile, nodeChanges, false);
                                    }
                                } else if (!vulnerableDescendants.contains(vulnerableDescendant)) {
                                    vulnerableDescendants.add(vulnerableDescendant);
                                    gatherChangesPerMethod(vulnerableDescendant.getValue(), insertOtherFile, nodeChanges, true);
                                }

                                ITree parentNode = nodeChanges.action.getNode().getParent();
                                boolean isApiChange = checkIfApiChange(parentNode, treeContext);
                                if (isApiChange) {
                                    Pair<Integer, ITree> methodDeclaration = new Pair<>(insertOtherFile, nodeChanges.action.getNode().getParent());
                                    if (DEBUG) {
                                        System.out.println("potential candidate!!!");
                                        System.out.println(nodeChanges.toString());
                                        System.out.println(nodeChanges.line);
                                        System.out.println(listOfFiles[insertOtherFile]);
                                        String methodName = SootUtilities.getMethodName(nodeChanges.action.getNode().getParent(), treeContext);
                                        System.out.println(methodName);
                                    }
                                    if (!apiChangesNew.contains(methodDeclaration)) {
                                        apiChangesNew.add(methodDeclaration);
                                    }
                                }
                            }
                        }
                    }

                }
            }
        }

        List<String> variableTypes = new ArrayList<>();
        variableTypes.add(VAR_DECL);
        variableTypes.add(VAR_FRAG);
        variableTypes.add(FIELD_DECL);
        variableTypes.add(ASSGNMT);

        //CHECK IF AN IF CONDITION HAS BEEN UPDATED
        //IF CONDITION IS VULNERABLE

        if (factMatrix[IF_CONST][UPDATE_CONST].size() > 0) {
            findVulnerableNode(IF_CONST, UPDATE_CONST, factMatrix, vulnerableNodes, IF_COND);
        }
        //CHECK IF A VARIABLE HAS BEEN UPDATED
        //THE VARIABLE IS VULNERABLE

        if (factMatrix[VAR_CONST][UPDATE_CONST].size() > 0) {
            findVulnerableNode(VAR_CONST, UPDATE_CONST, factMatrix, vulnerableNodes, variableTypes);
        }

        if (factMatrix[MI_CONST][DEL_CONST].size() > 0) {
            findVulnerableNode(MI_CONST, DEL_CONST, factMatrix, vulnerableNodes, MET_INV);
        }

        //CHECK IF A METHOD DECLARATION HAS BEEN DELETED
        //THE METHOD IS VULNERABLE

        if (factMatrix[MD_CONST][DEL_CONST].size() > 0) {
            findVulnerableNode(MD_CONST, DEL_CONST, factMatrix, vulnerableNodes, MET_DECL);
        }
        //CHECK IF AN IF CONDITION HAS BEEN DELETED
        //THE IF CONDITION IS VULNERABLE
        if (factMatrix[IF_CONST][DEL_CONST].size() > 0) {
            findVulnerableNode(IF_CONST, DEL_CONST, factMatrix, vulnerableNodes, IF_COND);
        }

        //CHECK IF AN VARIABLE HAS BEEN DELETED
        //THE VARIABLE IS VULNERABLE
        if (factMatrix[VAR_CONST][DEL_CONST].size() > 0) {
            findVulnerableNode(VAR_CONST, DEL_CONST, factMatrix, vulnerableNodes, namedVariables);
        }

        //CHECK IF THERE IS AN INSERT AND DELETE AT THE SAME LINE UNDER OTHER
        //IF YES, SOMETHING HAS BEEN UPDATED
        //CHECK PARENTS UNTIL A SIMPLER CODE STRUCTURE: VAR, IF, METHOD
        if (factMatrix[OTHER][INSERT_CONST].size() > 0 && factMatrix[OTHER][DEL_CONST].size() > 0) {
            List<Pair<Integer, Integer>> insertOtherLines = factMatrix[OTHER][INSERT_CONST];
            List<Pair<Integer, Integer>> deleteOtherLines = factMatrix[OTHER][DEL_CONST];

            for (Pair<Integer, Integer> insertOtherFileLine : insertOtherLines) {
                int insertOtherFileID = insertOtherFileLine.getKey();
                int insertOtherLine = insertOtherFileLine.getValue();

                for (Pair<Integer, Integer> deleteOtherFileline : deleteOtherLines) {

                    int deleterOtherFileID = deleteOtherFileline.getKey();
                    int deleterOtherLine = deleteOtherFileline.getValue();

                    if (insertOtherFileID == deleterOtherFileID && insertOtherLine == deleterOtherLine) {
                        LinkedHashMap<Integer, List<NodeChanges>> groupedNodeChanges = groupedNodeChangesByFile.get(insertOtherFileID);
                        List<NodeChanges> lineNodeChangesList = groupedNodeChanges.get(insertOtherLine);
                        TreeContext treeContext = Generators.getInstance().getTree(listOfFiles[insertOtherFileID + 1]);
                        for (NodeChanges nodeChange : lineNodeChangesList) {

                            if (!nodeChange.action.getNode().isRoot()) {
                                ITree node = nodeChange.action.getNode().getParent();

                                int counter = 0;
                                if (!node.isRoot() && !node.toPrettyString(treeContext).contains("TextElement") && !node.toPrettyString(treeContext).contains("TagElement")) {
                                    whileloop:
                                    while (!node.toPrettyString(treeContext).contains(IF_COND) &&
                                            !node.toPrettyString(treeContext).contains(VAR_DECL) &&
                                            !node.toPrettyString(treeContext).contains(VAR_FRAG) &&
                                            !node.toPrettyString(treeContext).contains(FIELD_DECL) &&
                                            !node.toPrettyString(treeContext).contains(MET_INV) &&
                                            !node.toPrettyString(treeContext).contains(MET_DECL) &&
                                            !node.toPrettyString(treeContext).contains(FOR_STMT) &&
                                            !node.isRoot()) {
                                        //this is a hack, fix it
                                        if (counter > 20) {
                                            node = node.getParent();
                                        }
                                        if (counter > 25) {
                                            break whileloop;
                                        }
                                        if (node.getPos() == insertOtherLine) {
                                            node = node.getParent();
                                        } else {
                                            counter++;
                                        }

                                    }
                                }

                                Pair<Integer, ITree> vulnerableNode = new Pair<>(insertOtherFileID, node);
                                if (vulnerableNodes.contains(vulnerableNode)) {
                                    vulnerableNodes.add(vulnerableNode);
                                    gatherChangesPerMethod(vulnerableNode.getValue(), insertOtherFileID, nodeChange, false);
                                }
                            }
                        }
                    }

                }


            }
        }

        if (factMatrix[OTHER][UPDATE_CONST].size() > 0) {
            List<Pair<Integer, Integer>> otherUpdateLines = factMatrix[OTHER][UPDATE_CONST];
            for (Pair<Integer, Integer> otherUpdateFileLine : otherUpdateLines) {
                int fileID = otherUpdateFileLine.getKey();
                int lineNumber = otherUpdateFileLine.getValue();

                LinkedHashMap<Integer, List<NodeChanges>> groupedChanges = groupedNodeChangesByFile.get(fileID);
                List<NodeChanges> groupedChangesbyLine = groupedChanges.get(lineNumber);
                for (NodeChanges nodeChange : groupedChangesbyLine) {
                    if (nodeChange.actionType.equalsIgnoreCase("UPD")) {
                        ITree node = nodeChange.action.getNode().getParent();
                        TreeContext treeContext = Generators.getInstance().getTree(listOfFiles[fileID + 1]);
                        int counter = 0;
                        if (!node.isRoot() && !node.toPrettyString(treeContext).contains("TextElement") && !node.toPrettyString(treeContext).contains("TagElement") && node.getPos() == lineNumber) {
                            //TODO: FIX THIS!!!
                            whileloop:
                            while (!node.toPrettyString(treeContext).contains(IF_COND) &&
                                    !node.toPrettyString(treeContext).contains(VAR_DECL) &&
                                    !node.toPrettyString(treeContext).contains(VAR_FRAG) &&
                                    !node.toPrettyString(treeContext).contains(FIELD_DECL) &&
                                    !node.toPrettyString(treeContext).contains(MET_INV) &&
                                    !node.toPrettyString(treeContext).contains(MET_DECL) &&
                                    !node.toPrettyString(treeContext).contains(FOR_STMT) &&
                                    !node.isRoot()) {
                                if (counter > 20) {
                                    node = node.getParent();
                                }
                                if (counter > 25) {
                                    break whileloop;
                                }
                                if (node.getPos() == lineNumber) {
                                    node = node.getParent();
                                    counter++;
                                } else if (!node.isLeaf()) {
                                    node = node.getChild(0);
                                    counter++;
                                } else {
                                    counter++;
                                }
                            }

                            if (!node.toPrettyString(treeContext).equalsIgnoreCase("CompilationUnit")) {
                                Pair<Integer, ITree> vulnerableNode = new Pair<>(fileID, node);
                                if (!vulnerableNodes.contains(vulnerableNode)) {
                                    vulnerableNodes.add(vulnerableNode);
                                    gatherChangesPerMethod(vulnerableNode.getValue(), fileID, nodeChange, false);
                                }
                            }

                        }


                    }
                }

            }
        }

        if (factMatrix[OTHER][DEL_CONST].size() > 0) {
            List<Pair<Integer, Integer>> otherDeleteLines = factMatrix[OTHER][DEL_CONST];
            for (Pair<Integer, Integer> otherDeleteFileLine : otherDeleteLines) {
                int fileID = otherDeleteFileLine.getKey();
                int lineNumber = otherDeleteFileLine.getValue();
                LinkedHashMap<Integer, List<NodeChanges>> groupedChanges = groupedNodeChangesByFile.get(fileID);
                List<NodeChanges> groupedChangesbyLine = groupedChanges.get(lineNumber);
                for (NodeChanges nodeChange : groupedChangesbyLine) {
                    if (nodeChange.actionType.equalsIgnoreCase("DEL")) {
                        TreeContext treeContext = Generators.getInstance().getTree(listOfFiles[fileID + 1]);
                        String nodeType = nodeChange.action.getNode().toPrettyString(treeContext).split(":")[0];
                        if (!namedVariables.contains(nodeType)) {
                            Pair<Integer, ITree> vulnerableNode = new Pair<>(fileID, nodeChange.action.getNode());
                            if (!vulnerableNodes.contains(vulnerableNode)) {
                                vulnerableNodes.add(vulnerableNode);
                                gatherChangesPerMethod(vulnerableNode.getValue(), fileID, nodeChange, false);
                            }
                        }
                    }

                }


            }
        }


//        System.out.println("Vulnerable Nodes");
//
//        for(Pair<Integer, ITree> vulnerableNode: vulnerableNodes){
//            Integer fileID = vulnerableNode.getKey();
//            TreeContext treeContext = Generators.getInstance().getTree(listOfFiles[fileID]);
//            TreeContext treeContext1 = Generators.getInstance().getTree(listOfFiles[fileID + 1]);
//            System.out.println(vulnerableNode.getKey() + ": " + vulnerableNode.getValue().toPrettyString(treeContext));
//            System.out.println(vulnerableNode.getKey() + ": " + vulnerableNode.getValue().toPrettyString(treeContext1));
//
//        }
//
//        System.out.println("Vulnerable Descendants");
//
//        for(Pair<Integer, ITree> vulnerableNode: vulnerableDescendants){
//            Integer fileID = vulnerableNode.getKey();
//            TreeContext treeContext = Generators.getInstance().getTree(listOfFiles[fileID]);
//            TreeContext treeContext1 = Generators.getInstance().getTree(listOfFiles[fileID + 1]);
//            System.out.println(vulnerableNode.getKey() + ": " + vulnerableNode.getValue().toPrettyString(treeContext));
//            System.out.println(vulnerableNode.getKey() + ": " + vulnerableNode.getValue().toPrettyString(treeContext1));
//
//        }
        setVulnerableDescendants(vulnerableDescendants);
        setVulnerableNodes(vulnerableNodes);


    }


}
