package fixdetector;

import com.github.gumtreediff.actions.model.Insert;
import com.github.gumtreediff.actions.model.Move;
import com.github.gumtreediff.gen.Generators;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.tree.ITree;
import com.github.gumtreediff.tree.TreeContext;
import javafx.util.Pair;
import util.ChangeUtil;
import util.SootUtilities;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.*;
import java.util.logging.Level;

import static util.Constants.*;

public class ChangedNodesIdentifier implements Serializable {

    //CONSTANTS

    static final int DEL_CONST = 0;
    static final int INS_CONST = 1;


    public LinkedHashMap<Integer, LinkedHashMap<Integer, List<NodeChanges>>> groupedNodeChangesByFile = new LinkedHashMap<>();
    public String[] listOfFiles;
    public List<MappingStore> mappingStores = new ArrayList<>();
    public List<Pair<Integer, ITree>> apiChangesNew = new ArrayList<>();
    public List<Pair<Integer, ITree>> apiChangesOld = new ArrayList<>();

    public List<Pair<Integer, ITree>> mvarChangesNew = new ArrayList<>();
    public List<Pair<Integer, ITree>> mvarChangesOld = new ArrayList<>();

    public LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassNew = new LinkedHashMap<>();
    public LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassOld = new LinkedHashMap<>();

    public List<ITree> insertedMethodInvocations = new ArrayList<>();
    public List<ITree> deletedMethodInvocations = new ArrayList<>();
    int lineCount;

    ArrayList<Pair<Integer, Integer>>[] factMatrix = new ArrayList[2];

    boolean apiChanges = false;
    boolean mvarChanges = false;

    List<Pair<Integer, Pair<Integer, Integer>>> insertedMethodDeclarationBounds = new ArrayList<>();

    HashMap<Integer, HashMap<String, List<ITree>>> insOrDelMethodSignatures = new HashMap<>();


    static int findLastChildLine(ITree tree) {
        int line = -1;

        ITree lastChild = findLastChild(tree);
        if (lastChild != null) {
            line = lastChild.getPos();
        }
        return line;
    }

    static ITree findLastChild(ITree tree) {

        List<ITree> children = tree.getChildren();
        if (children.size() > 1) {
            ITree lastChild = children.get(children.size() - 1);
            while (!lastChild.isLeaf()) {
                children = lastChild.getChildren();
                lastChild = children.get(children.size() - 1);
            }
            return lastChild;
        }

        return null;
    }

    public void run(String[] args) throws IOException {
        listOfFiles = new String[args.length];
        listOfFiles = args.clone();
        DiffObtainer diffObtainer = new DiffObtainer();

        for (int a = 0; a < args.length; a += 2) {
            try {

                List<NodeChanges> nodeChangesList = diffObtainer.run(args[a], args[a + 1]);
                List<NodeChanges> filterNodeChangesList = checkInsertsAndMoves(nodeChangesList, a, diffObtainer.getMappings());
                mappingStores.add(diffObtainer.getMappings());

                getOverloadedMethodsHelper(a);


                //group the same-line nodeChanges
                LinkedHashMap<Integer, List<NodeChanges>> groupedNodeChanges = groupNodeChanges(filterNodeChangesList, a);

                //store the results in a global map per each file
                groupedNodeChangesByFile.put(a, groupedNodeChanges);


            } catch (FileNotFoundException foe) {
                System.out.println("File not found: " + foe.getMessage());

            }
            finally {
                continue;
            }
        }


        sortChangedNodes();

    }


    void getOverloadedMethodsHelper(int a) throws IOException {
        getOverloadedMethods(a);
        getOverloadedMethods(a + 1);
    }

    void getOverloadedMethods(int a) throws IOException {
        TreeContext treeContext = getTreeContext(a);
        ITree root = treeContext.getRoot();
        Iterable<ITree> iTrees = root.breadthFirst();

        for (ITree iTree : iTrees) {
            if (treeContext.getTypeLabel(iTree).equalsIgnoreCase(MET_DECL)) {
                String partialMethodSignature = getPartialMethodSignature(iTree, treeContext);
                if (insOrDelMethodSignatures.containsKey(a)) {
                    HashMap<String, List<ITree>> methods = insOrDelMethodSignatures.get(a);
                    if (methods.containsKey(partialMethodSignature) && !methods.get(partialMethodSignature).contains(iTree)) {
                        methods.get(partialMethodSignature).add(iTree);
                    } else if (!methods.containsKey(partialMethodSignature)) {
                        List<ITree> methodITrees = new ArrayList<>();
                        methodITrees.add(iTree);

                        methods.put(partialMethodSignature, methodITrees);
                    }
                } else {
                    HashMap<String, List<ITree>> methods = new HashMap<>();
                    List<ITree> methodITrees = new ArrayList<>();
                    methodITrees.add(iTree);
                    methods.put(partialMethodSignature, methodITrees);
                    insOrDelMethodSignatures.put(a, methods);


                }
            }
        }
    }

    /**
     * In some cases (CVE-2013-4590_1, ParserUtils) when a node A is inserted to a node B,
     * and if a isomorphic node to node A, A' exists, GT will have two change actions:
     * insert node A to A''s parent and move A' to B
     * we fix this since it causes issues with soot finding root changes for API-based cc
     *
     * @param nodeChangesList
     * @param fileNo
     * @param mappingStore
     * @return
     * @throws IOException
     */
    List<NodeChanges> checkInsertsAndMoves(List<NodeChanges> nodeChangesList, int fileNo, MappingStore mappingStore) throws IOException {
        List<ITree> insertedNodes = new ArrayList<>();
        List<NodeChanges> insertedNodeChanges = new ArrayList<>();

        List<ITree> movedNodes = new ArrayList<>();
        List<NodeChanges> movedNodeChanges = new ArrayList<>();
        for (NodeChanges nodeChanges : nodeChangesList) {
            if (nodeChanges.actionType.equalsIgnoreCase("INS")) {
                ITree node = nodeChanges.action.getNode();
                insertedNodes.add(node);
                insertedNodeChanges.add(nodeChanges);
            }
            if (nodeChanges.actionType.equalsIgnoreCase("MOV")) {
                ITree node = nodeChanges.action.getNode();
                movedNodes.add(node);
                movedNodeChanges.add(nodeChanges);
            }
        }

        for (int i = 0; i < movedNodes.size(); i++) {
            ITree movedNode = movedNodes.get(i);
            NodeChanges movedNodeChange = movedNodeChanges.get(i);
            ITree movedNodeParent = ((Move) movedNodeChange.action).getParent();
            String movedParentType = getTreeContext(fileNo + 1).getTypeLabel(movedNodeParent);
            for (int j = 0; j < insertedNodes.size(); j++) {

                ITree insertedNode = insertedNodes.get(j);
                NodeChanges insertedNodeChange = insertedNodeChanges.get(j);
                ITree insertedNodeParent = ((Insert) insertedNodeChange.action).getParent();
                String insertedParentType = getTreeContext(fileNo + 1).getTypeLabel(insertedNodeParent);

                if (movedNode.isIsomorphicTo(insertedNode) && insertedParentType.equalsIgnoreCase(movedParentType)) {
                    ITree mappedNode = mappingStore.getDst(movedNode);
                    if (mappedNode != null) {
                        insertedNodeChange.getAction().setNode(mappedNode);
                        insertedNodeChange.getAction().getNode().setParent(movedNodeParent);
                        insertedNodeChange.line = mappedNode.getPos();
                        List<ITree> children = insertedNode.getChildren();
                        for (int k = 0; k < children.size(); k++) {
                            ITree child = children.get(k);
                            if (insertedNodes.contains(child)) {
                                int index = insertedNodes.indexOf(child);
                                NodeChanges childNodeChange = insertedNodeChanges.get(index);
                                childNodeChange.getAction().setNode(mappedNode.getChild(k));
                                childNodeChange.getAction().getNode().setParent(mappedNode);
                                childNodeChange.line = mappedNode.getChild(k).getPos();
                            }
                        }
                        nodeChangesList.remove(movedNodeChange);
                    }
                }
            }
        }
        return nodeChangesList;
    }

    /**
     * this method is used to get the name of declared methods that have been added
     *
     * @param
     * @return
     * @throws IOException
     */

    public void getMethodDeclarationBounds(NodeChanges nodeChanges, int insertMethodDeclarationLine, int insertMethodDeclarationFile)
            throws IOException {


        //check for MethodDeclarations ones
        if (nodeChanges.getNodeType().equalsIgnoreCase(MET_DECL)) {


            //find the last line that belongs to the method delcaration
            //this is needed to check if variables or if conditions being added are part of a method declaration or not
            int lowerBoundary = findLastChildLine(nodeChanges.action.getNode());
            Pair<Integer, Integer> methodDeclarationBoundaries = new Pair<>(insertMethodDeclarationLine, lowerBoundary);
            Pair<Integer, Pair<Integer, Integer>> methodDeclarationBoundariesPerFile
                    = new Pair<>(insertMethodDeclarationFile, methodDeclarationBoundaries);
            insertedMethodDeclarationBounds.add(methodDeclarationBoundariesPerFile);


        }
    }

    private LinkedHashMap<Integer, List<NodeChanges>> groupNodeChanges(List<NodeChanges> nodeChangesList, int fileNo) throws IOException {

        LinkedHashMap<Integer, List<NodeChanges>> groupedNodeChanges = new LinkedHashMap<>();
        for (NodeChanges nodeChange : nodeChangesList) {

            //we need to perform this check for API-based casualty changes

            if (apiChanges && nodeChange.getNodeType().equalsIgnoreCase(MET_DECL) &&
                    (nodeChange.getAction().getName().equalsIgnoreCase("INS") ||
                            nodeChange.getAction().getName().equalsIgnoreCase("DEL"))) {
                int fileNoFinal = nodeChange.getActionType().equalsIgnoreCase("INS") ? fileNo + 1 : fileNo;

                checkIfOverloadMethodApiChange(nodeChange.action.getNode(), fileNoFinal);

                getMethodDeclarationBounds(nodeChange, nodeChange.line, fileNoFinal);
            }

            //check if that line of changes already exists
            if (groupedNodeChanges.containsKey(nodeChange.line)) {
                //if yes, check if the particular change exists
                if (!groupedNodeChanges.get(nodeChange.line).contains(nodeChange)) {
                    List<NodeChanges> newNodeChanges = groupedNodeChanges.get(nodeChange.line);
                    newNodeChanges.add(nodeChange);
                    groupedNodeChanges.replace(nodeChange.line, newNodeChanges);
                }


            } else {
                List<NodeChanges> newNodeChanges = new ArrayList<>();
                newNodeChanges.add(nodeChange);
                groupedNodeChanges.put(nodeChange.line, newNodeChanges);
                lineCount++;
            }
        }

        return groupedNodeChanges;
    }

    void checkIfOverloadMethodApiChange(ITree metDecl, int fileNo) throws IOException {
        String partialSignature = getPartialMethodSignature(metDecl, getTreeContext(fileNo));
        TreeContext treeContext = getTreeContext(fileNo);
        if (insOrDelMethodSignatures.containsKey(fileNo) && insOrDelMethodSignatures.get(fileNo).containsKey(partialSignature)) {


            List<String> metDeclParameters = getParametersString(metDecl, treeContext);
            List<ITree> potentiallyOverloadedMethods = insOrDelMethodSignatures.get(fileNo).get(partialSignature);

            //handling cases like in CVE-2014-0230_1 IdentityInputFilter where a method is overloaded implicitly
            //i.e. there is an old implicit constructor, and now it's made explicit by adding a parameter
            //this is not working as planned; need to think more about it
//            if(partialSignatureConstructor(partialSignature) && metDeclParameters.size() > 0 && potentiallyOverloadedMethods.size()==1){
//                List<ITree> params = getParameters(metDecl, treeContext);
//                for(ITree param: params){
//                    addToApiChange(param, fileNo);
//                    gatherChangesPerMethod(param, fileNo);
//                }
//               return;
//            }
            int max = 0;
            int index = -1;
            for (int i = 0; i < potentiallyOverloadedMethods.size(); i++) {
                ITree iTree = potentiallyOverloadedMethods.get(i);
                if (!iTree.equals(metDecl)) {
                    List<String> iTreeParameters = getParametersString(iTree, treeContext);
                    int difference = getDifference(metDeclParameters, iTreeParameters);
                    if (difference >= max) {
                        max = difference;
                        index = i;
                    }
                }
            }

            getChangedParameters(metDecl, potentiallyOverloadedMethods.get(index), fileNo);
        }
    }

    boolean partialSignatureConstructor(String partialSignature) {
        String[] partialSignatureSplit = partialSignature.split(" ");
        return partialSignatureSplit.length == 2 && partialSignatureSplit[0].equalsIgnoreCase(partialSignatureSplit[1]);

    }


    void getChangedParameters(ITree overloaded, ITree overloadee, int fileNo) throws IOException {
        TreeContext treeContext = getTreeContext(fileNo);
        List<String> overloadeeParameters = getParametersString(overloadee, treeContext);

        //for the moment we're only handling cases when the overloadedMethod has more parameters
        List<ITree> children = overloaded.getChildren();
        boolean[] matched = new boolean[overloadeeParameters.size()];
        for (ITree child : children) {
            if (treeContext.getTypeLabel(child).equalsIgnoreCase(SINGLE_VAR_DECL)) {
                String type = child.getChildren().get(0).getLabel();
                if (!overloadeeParameters.contains(type)) {
                    addToApiChange(child, fileNo);
                    gatherChangesPerMethod(child, fileNo);
                } else {
                    int index = overloadeeParameters.indexOf(type);
                    if (matched[index]) {
                        addToApiChange(child, fileNo);
                        gatherChangesPerMethod(child, fileNo);
                    }
                    matched[index] = true;
                }
            }
        }
    }

    int getDifference(List<String> parameters1, List<String> parameters2) {
        int difference = 0;
        for (String parameter : parameters1) {
            if (!parameters2.contains(parameter)) {
                difference++;
            }
        }
        if (difference == 0) {
            return Math.abs(parameters1.size() - parameters2.size());
        }

//        for(String parameter: parameters2){
//            if(!parameters2.contains(parameter)){
//                difference ++;
//            }
//        }

        return difference;
    }

    List<String> getParametersString(ITree metDecl, TreeContext treeContext) {

        List<String> result = new ArrayList<>();
        List<ITree> children = metDecl.getChildren();
        for (ITree child : children) {
            if (treeContext.getTypeLabel(child.getType()).equals(SINGLE_VAR_DECL)) {
                //type
                result.add(child.getChildren().get(0).getLabel());
            }
        }
        //for easier comparison
        Collections.sort(result);
        return result;
    }

    List<ITree> getParameters(ITree metDecl, TreeContext treeContext) {

        List<ITree> result = new ArrayList<>();
        List<ITree> children = metDecl.getChildren();
        for (ITree child : children) {
            if (treeContext.getTypeLabel(child.getType()).equals(SINGLE_VAR_DECL)) {
                //type
                result.add(child);
            }
        }

        return result;
    }


    void checkIfApiChange(ITree node, int fileNo) throws IOException {
        TreeContext treeContext = getTreeContext(fileNo);
        String nodeType = node.toPrettyString(treeContext).split(":")[0].trim();
        boolean inMDBounds = checkForPresenceinMDBounds(node.getPos(), fileNo);
        if (inMDBounds) {
            return;
        }
        if (!node.isRoot()) {
            String parentNodeType = node.getParent().toPrettyString(treeContext).split(":")[0].trim();

            boolean isApi = nodeType.equalsIgnoreCase(SINGLE_VAR_DECL) && parentNodeType.equalsIgnoreCase(MET_DECL);
            if (isApi) {
                addToApiChange(node, fileNo);
            }
        }
    }

    boolean checkForPresenceinMDBounds(int line, int fileNo) {


        ArrayList<Integer> counters = new ArrayList<>();
        for (int i = 0; i < insertedMethodDeclarationBounds.size(); i++) {
            Pair<Integer, Pair<Integer, Integer>> insertedMethodDeclarationBound = insertedMethodDeclarationBounds.get(i);
            int mdFileId = insertedMethodDeclarationBound.getKey();
            if (mdFileId == fileNo) {
                counters.add(i);
            }

        }
        if (counters.size() > 0) {
            for (int counter : counters) {
                Pair<Integer, Integer> mdRange = insertedMethodDeclarationBounds.get(counter).getValue();
                if (line >= mdRange.getKey() && line <= mdRange.getValue()) {
                    return true;
                }
            }
        }
        return false;
    }

    public void checkIfMVarChange(ITree node, int fileNo) throws IOException {
        TreeContext treeContext = getTreeContext(fileNo);
        String nodeType = getNodeType(node, treeContext);
        if (!node.isRoot()) {


            boolean isMVarNode = nodeType.equalsIgnoreCase(FIELD_DECL);
            if (isMVarNode) {
                addToMVarChange(node, fileNo);
            } else {
                ITree parent = node.getParent();
                String parentNodeType = getNodeType(parent, treeContext);

                boolean isMVarPar = parentNodeType.equalsIgnoreCase(FIELD_DECL);
                if (isMVarPar) {
                    addToMVarChange(node.getParent(), fileNo);
                }
            }
        }
    }

    private void addToApiChange(ITree node, int fileNo) {
        List<Pair<Integer, ITree>> apiChanges = fileNo % 2 == 0 ? apiChangesOld : apiChangesNew;
        Pair<Integer, ITree> pair = new Pair<>(fileNo, node);
        if (!apiChanges.contains(pair)) {
            apiChanges.add(pair);
        }
    }

    private void addToMVarChange(ITree node, int fileNo) {
        List<Pair<Integer, ITree>> mvarChanges = fileNo % 2 == 0 ? mvarChangesOld : mvarChangesNew;
        Pair<Integer, ITree> pair = new Pair<>(fileNo, node);
        if (!mvarChanges.contains(pair)) {
            mvarChanges.add(pair);
        }
    }

    private TreeContext getTreeContext(int fileNo) throws IOException {
        return Generators.getInstance().getTree(listOfFiles[fileNo]).deriveTree();
    }

    public void sortChangedNodes() throws IOException {
        initializeFactMatrix();
        Iterator<Map.Entry<Integer, LinkedHashMap<Integer, List<NodeChanges>>>> iterator = groupedNodeChangesByFile.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, LinkedHashMap<Integer, List<NodeChanges>>> entry = iterator.next();
            int fileNo = entry.getKey();
            LinkedHashMap<Integer, List<NodeChanges>> changesMap = entry.getValue();
            Set<Integer> lineNos = changesMap.keySet();
            //you might have to figure out how to handle inserted method declarations and everything in them too; might need to determine the boundaries and not include
            // those additional lines
            for(int lineNo: lineNos){
                List<NodeChanges> nodeChangeslist = changesMap.get(lineNo);
                inner:
                for(NodeChanges nodeChanges: nodeChangeslist) {

                    if (apiChanges) {
                        int fileTemp = determineFileNo(nodeChanges.actionType, fileNo);
                        if (checkForPresenceinMDBounds(lineNo, fileTemp)) {
                            //some are not being deleted; check why
                            continue inner;
                        }
                    }

                    //when nodes are moved to the same method, which is divided in two we do not consider that as a change
                    //example: CVE-2009-2693 return node in method expand
                    if (nodeChanges.actionType.equals("MOV")) {
                        Move move = (Move) nodeChanges.getAction();
                        ITree child = move.getNode();
                        ITree parent = move.getParent();

                        if (sameMethod(child, parent, fileNo)) {
                            continue inner;
                        }

                    }
                    ITree[] involvedITrees = getITreesfromChanges(nodeChanges, fileNo);
                    int fileTemp = determineFileNo(nodeChanges.actionType, fileNo);
                    doubleinner:
                    for (ITree involvedITree : involvedITrees) {
                        if(involvedITree != null) {


                            //when allchanges this is needed
                            //TODO handle this better
                            if (apiChanges && checkForPresenceinMDBounds(involvedITree.getPos(), fileTemp)) {
                                continue doubleinner;
                            }
                            gatherChangesPerMethod(involvedITree, fileTemp);

                            if (apiChanges)
                                checkIfApiChange(involvedITree, fileTemp);

                            if (mvarChanges) {
                                checkIfMVarChange(involvedITree, fileTemp);
                            }
                        }
                    }
                    if(nodeChanges.getActionType().equalsIgnoreCase("INS")
                            || nodeChanges.getActionType().equalsIgnoreCase("DEL")) {
                        checkIfInsertedOrDeletedMethodInvocation(getTreeContext(fileTemp), nodeChanges);
                        matrixPopulator(fileNo, nodeChanges);
                    }


                }

            }

        }
        //this is not well implemented for the moment
        filterInsertsAndDeletes();

    }

    boolean sameMethod(ITree child, ITree parent, int index) throws IOException {
        ITree childMethod = SootUtilities.getMethod(child, getTreeContext(index));
        ITree parentMethod = SootUtilities.getMethod(child, getTreeContext(index + 1));

        boolean same = mappingStores.get(index / 2).has(child, parent);
        boolean childParentAPI = compareApis(childMethod, parentMethod, index);
        if (!same && childParentAPI && mappingStores.get(index / 2).hasSrc(childMethod)) {

            ITree mapped = mappingStores.get(index / 2).getDst(childMethod);
            boolean mappedApis = compareApis(childMethod, mapped, index);

            String childMethodName = SootUtilities.getMethodName(childMethod, getTreeContext(index));
            String mappedMethodName = SootUtilities.getMethodName(mapped, getTreeContext(index + 1));
            return !mappedApis && childMethodName.equals(mappedMethodName);

        }

        return false;
    }

    boolean compareApis(ITree method1, ITree method2, int index) throws IOException {
        TreeContext treeContext1 = getTreeContext(index);
        TreeContext treeContext2 = getTreeContext(index + 1);
        String methodName1 = SootUtilities.getMethodName(method1, treeContext1);
        String methodName2 = SootUtilities.getMethodName(method2, treeContext2);

        if (!methodName1.equals(methodName2)) {
            return false;
        }


        String returnType1 = ChangeUtil.getMethodDeclarationReturnType(method1, treeContext1);
        String returnType2 = ChangeUtil.getMethodDeclarationReturnType(method2, treeContext2);

        if (!returnType1.equals(returnType2)) {
            return false;
        }

        if (treeContext1.getTypeLabel(method1).equalsIgnoreCase(COMPILATION_UNIT) && treeContext2.getTypeLabel(method2).equalsIgnoreCase(COMPILATION_UNIT)) {
            return true;
        }

        List<String> modifiers1 = new ArrayList<>();
        List<String> parameters1 = new ArrayList<>();
        getModifiers(method1, treeContext1, modifiers1, parameters1);

        List<String> modifiers2 = new ArrayList<>();
        List<String> parameters2 = new ArrayList<>();
        getModifiers(method2, treeContext2, modifiers2, parameters2);

        if (modifiers1.size() != modifiers2.size()) {
            return false;
        }

        for (String modifier : modifiers1) {
            if (!modifiers2.contains(modifier)) {
                return false;
            }
        }

        for (String parameter : parameters2) {
            if (!parameters2.contains(parameter)) {
                return false;
            }
        }

        return true;

    }

    String getPartialMethodSignature(ITree methodDecl, TreeContext treeContext) {

        String methodName = SootUtilities.getMethodName(methodDecl, treeContext);

        String returnType = ChangeUtil.getMethodDeclarationReturnType(methodDecl, treeContext);

        return returnType + " " + methodName;
    }

    void getModifiers(ITree methodDeclaration, TreeContext treeContext, List<String> modifiers, List<String> parameters) {
        List<ITree> children = methodDeclaration.getChildren();


        for (ITree child : children) {
            if (treeContext.getTypeLabel(child.getType()).equals(MOD)) {
                modifiers.add(child.getLabel());
            }

            if (treeContext.getTypeLabel(child.getType()).equals(SINGLE_VAR_DECL)) {
                parameters.add(child.getChildren().get(0).getLabel());
            }
        }

    }
    public void filterInsertsAndDeletes() throws IOException {
        //filter deletes that are in the same line with inserts
        if(factMatrix[DEL_CONST].size()>0 && factMatrix[INS_CONST].size()>0){
            List<Pair<Integer, Integer>> deletedPairs = factMatrix[DEL_CONST];
            List<Pair<Integer, Integer>> insertedPairs = factMatrix[INS_CONST];

            for(Pair<Integer, Integer> deletedPair: deletedPairs){
                int deletedFile = deletedPair.getKey();
                int deletedLine = deletedPair.getValue();

                for(Pair<Integer, Integer> insertedPair: insertedPairs){
                    int insertedFile = insertedPair.getKey();
                    int insertedLine = insertedPair.getValue();

                    //if they are in the same line
                    //TODO: need to see cases in which this happens and how to handle it better
                    //the nodes have to have additional things in common
                    if (insertedFile == deletedFile && insertedLine == deletedLine) {

                        List<NodeChanges> nodeChanges = groupedNodeChangesByFile.get(insertedFile).get(insertedLine);
                        logger.log(Level.INFO, "inserted and deleted nodes: " + nodeChanges.toString());

                        //filterDeletes(insertedFile, nodeChanges, insertedLine);
                    }
                }
            }

        }

    }

    public int determineFileNo(String action, int initial) {
        if (action.equalsIgnoreCase("INS") || action.equalsIgnoreCase("UPD") || action.equalsIgnoreCase("MOV")) {
            if (initial % 2 == 0) {
                return initial + 1;
            }
        }
        return initial;
    }

    public void filterDeletes(int fileNo, List<NodeChanges> nodeChanges, int line) throws IOException {
        ITree methodDeclaration = null;
        TreeContext treeContext = getTreeContext(fileNo);
        if (changesPerMethodInClassOld.containsKey(fileNo)) {
            HashMap<String, List<ITree>> methodToChangesMap = changesPerMethodInClassOld.get(fileNo);
            for (NodeChanges nodeChange : nodeChanges) {
                if (nodeChange.getActionType().equalsIgnoreCase("DEL")) {
                    ITree[] iTrees = getITreesfromChanges(nodeChange, fileNo);
                    inner:
                    for (ITree iTree : iTrees) {
                        if (iTree.getPos() != line) {
                            continue inner;
                        }
                        if (methodDeclaration == null) {
                            methodDeclaration = SootUtilities.getMethod(iTree, treeContext);
                        }
                        String methodName = getMethodName(methodDeclaration, treeContext);
                        if (methodToChangesMap.containsKey(methodName)) {
                            methodToChangesMap.get(methodName).remove(iTree);
                        }

                    }
                }
            }
        }
    }

    public ITree[] getITreesfromChanges(NodeChanges nodeChanges, int fileNo) {

        ITree[] iTrees = new ITree[2];
        //if (!nodeChanges.getActionType().equalsIgnoreCase("UPD")) {
            ITree childNode = nodeChanges.getAction().getNode();
            if(nodeChanges.getActionType().equalsIgnoreCase("UPD")
                    || nodeChanges.getActionType().equalsIgnoreCase("MOV")){
                childNode = getMappedNode(childNode, fileNo);
            }
            iTrees[0] = childNode;
            if(!childNode.isRoot()) {
                ITree parentNode = childNode.getParent();
                iTrees[1] = parentNode;
            }
            //check if you have to add a null element here since you've declared the array to be of length 2

            return iTrees;
    }

    /**
     * we track inserted and deleted method invocations because this information is needed for API-based changes
     * @param treeContext
     * @param nodeChanges
     */
    public void checkIfInsertedOrDeletedMethodInvocation(TreeContext treeContext, NodeChanges nodeChanges){
        List<ITree> methodInvocations = nodeChanges.action.getName().equalsIgnoreCase("INS")? insertedMethodInvocations : deletedMethodInvocations;
        String nodeType = getNodeType(nodeChanges.getAction().getNode(), treeContext);
        if (nodeType.equalsIgnoreCase(CLASS_INSTC_CREAT)
                || nodeType.equalsIgnoreCase(MET_INV) || nodeType.equalsIgnoreCase(CONSTR_INV)) {
            if (!methodInvocations.contains(nodeChanges.action.getNode())) {
                methodInvocations.add(nodeChanges.getAction().getNode());
            }
        }

    }

    public void initializeFactMatrix(){
        for (int i = 0; i < factMatrix.length; i++) {

                factMatrix[i] = new ArrayList<>();

        }
    }

    void matrixPopulator(int fileNo, NodeChanges nodeChanges){
        int constant = nodeChanges.getActionType().equalsIgnoreCase("DEL")? DEL_CONST : INS_CONST;
        factMatrix[constant].add(new Pair<>(fileNo, nodeChanges.getLine()));

    }


    /**
     * this method is used to get the mapped node in the other version of a node
     * @param node
     */
    public ITree getMappedNode(ITree node, int fileNo){
        MappingStore mappingStore = getMappingStore(fileNo);
        ITree mappedNode = mappingStore.getDst(node);
        if (mappedNode == null) {
            mappedNode = mappingStore.getSrc(node);
        }
        if (mappedNode == null) {
           return node;
        }
        return mappedNode;
    }

    public MappingStore getMappingStore(int fileNo){
        return mappingStores.get(fileNo / 2);
    }

    public void gatherChangesPerMethod(ITree involvedNode, int involvedFileID) throws IOException {
        //TODO check in CVE-2012-0022_12 how do you get the method of the node since it seems to get the method of the old node sometimes when a node is moved
        TreeContext treeContext = Generators.getInstance().getTree(listOfFiles[involvedFileID]);
        ITree methodDeclaration = SootUtilities.getMethod(involvedNode, treeContext);

        LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClass = involvedFileID % 2 == 0? changesPerMethodInClassOld: changesPerMethodInClassNew;

        if (methodDeclaration != null) {
            int line = methodDeclaration.getPos();
            String methodName = SootUtilities.getMethodName(methodDeclaration, treeContext) + ": " + line;

            HashMap<String, List<ITree>> changesPerMethod;
            if (changesPerMethodInClass.containsKey(involvedFileID)) {
                changesPerMethod = changesPerMethodInClass.get(involvedFileID);
                List<ITree> involvedNodes;
                if (changesPerMethod.containsKey(methodName)) {
                    involvedNodes = changesPerMethod.get(methodName);
                    if (!involvedNodes.contains(involvedNode)) {
                        involvedNodes.add(involvedNode);

                    }
                } else {
                    involvedNodes = new ArrayList<>();
                    involvedNodes.add(involvedNode);
                }

                changesPerMethod.put(methodName, involvedNodes);
            } else {
                changesPerMethod = new HashMap<>();
                List<ITree> involvedNodes = new ArrayList<>();
                involvedNodes.add(involvedNode);
                changesPerMethod.put(methodName, involvedNodes);
            }


            changesPerMethodInClass.put(involvedFileID, changesPerMethod);
        }
    }

    public List<Pair<Integer, ITree>> getApiChangesNew() {
        return apiChangesNew;
    }

    public List<Pair<Integer, ITree>> getApiChangesOld() {
        return apiChangesOld;
    }

    public LinkedHashMap<Integer, HashMap<String, List<ITree>>> getChangesPerMethodInClassNew() {
        return changesPerMethodInClassNew;
    }

    public LinkedHashMap<Integer, HashMap<String, List<ITree>>> getChangesPerMethodInClassOld() {
        return changesPerMethodInClassOld;
    }

    public String getNodeType(ITree node, TreeContext treeContext) {
        return treeContext.getTypeLabel(node.getType());
    }

    public List<ITree> getInsertedMethodInvocations() {
        return insertedMethodInvocations;
    }

    public List<ITree> getDeletedMethodInvocations() {
        return deletedMethodInvocations;
    }

    public String getMethodName(ITree node, TreeContext treeContext) throws IOException {
        return SootUtilities.getMethodName(node, treeContext) + ": " + node.getPos();
    }

    public void setApiChanges(boolean apiChanges) {
        this.apiChanges = apiChanges;
    }

    public void setMvarChanges(boolean mvarChanges) {
        this.mvarChanges = mvarChanges;
    }

    public List<Pair<Integer, ITree>> getMvarChangesNew() {
        return mvarChangesNew;
    }

    public List<Pair<Integer, ITree>> getMvarChangesOld() {
        return mvarChangesOld;
    }

    public int getLineCount() {
        return lineCount;
    }
}
