package fixdetector;

import com.github.gumtreediff.actions.model.Action;

import java.util.List;

public class UpdNodeChanges extends NodeChanges {

    UpdNodeChanges(Action action, List<String> parsed){
        super();
        this.action = action;
        this.actionType = parsed.get(0);
        this.nodeType = parsed.get(1).split(":")[0];
        this.nodeName = parsed.get(2);
        this.newUpd = parsed.get(6);
        this.line = Integer.parseInt(parsed.get(7));
    }

}
