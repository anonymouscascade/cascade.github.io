package fixdetector;

import com.github.gumtreediff.actions.model.Action;

public class NodeChanges implements Comparable {
    int line;

    public Action getAction() {
        return action;
    }

    public void setAction(Action action) {
        this.action = action;
    }

    Action action;
    String actionType;
    String nodeType;
    public String nodeName;
    public String newUpd = " ";
    String parNodeType;
    String parNodeName;


    public NodeChanges() {

    }


    /**
     * gets p_nodeType and par Children for MOV actions only for origin nodes comparison purposes
     * @return string
     */
    //public String getPar_nodeType(){
        //return p_nodeType + " " + parChildren;
    //}

    /**
     * returns nodeType and n_location to check for origin nodes
     * @return
     */

//    public String getnodeType(){
//        return nodeType + " " + children;
//    }

    /**
     * returns the type of action
     *
     * @return string
     */
    public String getActionType() {
        return actionType;
    }

    public int getLine() {
        return line;
    }

    public String getNodeType() {
        return nodeType;
    }


    /**
     * debugging purposes
     * @return String representation of Node Changes
     */
    public String toString(){
            if(actionType.equalsIgnoreCase("UPD")){
            return "Action: " + actionType + "\n Node Type: " + nodeType +
                    "\n Node Name: " + nodeName +
                    "\n Updated Name: " + newUpd;
            }

        else {
            return "Action: " + actionType + "\n Node Type: " + nodeType +
                    "\n Node Value: " + nodeName +
                    "\n Parent Node Type: " + parNodeType +
                    "\n Parent Node Value: " + parNodeName;
        }
    }

    static public void main(String[] args){

    }

    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
