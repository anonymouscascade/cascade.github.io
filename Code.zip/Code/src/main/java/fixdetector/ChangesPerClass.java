package fixdetector;

import com.github.gumtreediff.tree.ITree;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ChangesPerClass {

    HashMap<String, List<ITree>> changesPerMethodNew;
    HashMap<String, List<ITree>> changesPerMethodOld;

    ChangesPerClass(){
        changesPerMethodNew = new HashMap<>();
        changesPerMethodOld = new HashMap<>();
    }

    void addToVersion(String method, ITree node, boolean old){
        HashMap<String, List<ITree>> changesPerMethod = old? changesPerMethodOld : changesPerMethodNew;
        List<ITree> iTrees = new ArrayList<>();
        if(changesPerMethod.containsKey(method)){
            iTrees = changesPerMethod.get(method);
        }
        if(!iTrees.contains(node)){
            iTrees.add(node);
        }
        changesPerMethod.put(method, iTrees);
    }

}
