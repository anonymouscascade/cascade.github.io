package fixdetector;

import com.github.gumtreediff.actions.model.Action;

import java.util.List;

public class DelNodeChanges extends NodeChanges {
    DelNodeChanges(Action action, List<String> parsed){
        super();
        if(parsed.size() == 4){
            this.action = action;
            this.actionType = parsed.get(0);
            this.nodeType = parsed.get(1).split(":")[0];
            this.nodeName = parsed.get(2);
            this.line = Integer.parseInt(parsed.get(3));
        }
        else if(parsed.size() == 3){
            this.action = action;
            this.actionType = parsed.get(0);
            this.nodeType = parsed.get(1).split(":")[0];
            this.line = Integer.parseInt(parsed.get(2));
        }


    }
}
