package fixdetector;

import com.github.gumtreediff.actions.model.Action;

import java.util.List;

public class InsNodeChanges extends NodeChanges {


    InsNodeChanges(Action action, List<String> parsed){
        if(parsed.size() == 9){
            this.action = action;
            this.actionType = parsed.get(0);
            this.nodeType = parsed.get(1).split(":")[0];
            this.nodeName = parsed.get(2);
            this.parNodeType = parsed.get(4).split(":")[0];
            this.parNodeName = parsed.get(5);
            this.line = Integer.parseInt(parsed.get(8));
        }
        else if(parsed.size() == 8 && parsed.get(3).equalsIgnoreCase("to")){
            this.action = action;
            this.actionType = parsed.get(0).split(":")[0];
            this.nodeType = parsed.get(1);
            this.nodeName = parsed.get(2);
            this.parNodeType = parsed.get(4).split(":")[0];
            this.parNodeName = " ";
            this.line = Integer.parseInt(parsed.get(7));
        }
        else if(parsed.size() == 8 && parsed.get(2).equalsIgnoreCase("to")){
            this.action = action;
            this.actionType = parsed.get(0);
            this.nodeType = parsed.get(1).split(":")[0];
            this.nodeName = " ";
            this.parNodeType = parsed.get(3).split(":")[0];
            this.parNodeName = parsed.get(4);
            this.line = Integer.parseInt(parsed.get(7));
        }
        else if(parsed.size() == 7){
            this.action = action;
            this.actionType = parsed.get(0);
            this.nodeType = parsed.get(1).split(":")[0];
            this.nodeName = " ";
            this.parNodeType = parsed.get(3).split(":")[0];
            this.parNodeName = " ";
            this.line = Integer.parseInt(parsed.get(6));
        }
    }
}
