package util;

import java.util.logging.Logger;

public class Constants {
    //GumTree constants
    public static final String ASSGNMT = "Assignment";
    public static final String BLOCK = "Block";
    public static final String CATCH_CLAUSE = "CatchClause";
    public static final String CLASS_INSTC_CREAT = "ClassInstanceCreation";
    public static final String COMPILATION_UNIT = "CompilationUnit";
    public static final String CONSTR_INV = "ConstructorInvocation";
    public static final String EXPRSSSTMT = "ExpressionStatement";
    public static final String FIELD_ACC = "FieldAccess";
    public static final String FIELD_DECL = "FieldDeclaration";
    public static final String FOR_STMT = "ForStatement";
    public static final String IF_COND = "IfStatement";
    public static final String INFIX = "InfixExpression";
    public static final String JAVA_DOC = "Javadoc";
    public static final String MARKER_ANNOT = "MarkerAnnotation";
    public static final String MET_DECL = "MethodDeclaration";
    public static final String MET_INV = "MethodInvocation";
    public static final String MOD = "Modifier";
    public static final String POSTFIX = "PostfixExpression";
    public static final String PRIM_TYPE = "PrimitiveType";
    public static final String QUALIFIED_NAMED = "QualifiedName";
    public static final String RETURN = "ReturnStatement";
    public static final String SIMPLE_NAME = "SimpleName";
    public static final String SIMPLE_TYPE = "SimpleType";
    public static final String SINGLE_VAR_DECL = "SingleVariableDeclaration";
    public static final String STRING_LITERAL = "StringLiteral";
    public static final String SWITCH_STMT = "SwitchStatement";
    public static final String SYNC_STMT = "SynchronizedStatement";
    public static final String THROW_STMT = "ThrowStatement";
    public static final String TRY_STMT = "TryStatement";
    public static final String TYPE_DECLA = "TypeDeclaration";
    public static final String VAR_DECL = "VariableDeclarationStatement";
    public static final String VAR_FRAG = "VariableDeclarationFragment";
    public static final String WHILE_STMT = "WhileStatement";

    //RefMine constants
    public static final String EXTRACT_VAR = "Extract Variable";


    public final static Logger logger = Logger.getLogger("");


    public static final boolean DEBUG = true;


}
