package util;

import java.util.*;
//code copied from GeeksforGeeks; slighlty modified
public class DirectedGraph {
    // A user define class to represent a directed graph.
    // A graph is an array of adjacency lists.
    // Size of array will be V (number of vertices
    // in graph)
    int V;

    LinkedList<Integer>[] adjListArray;


    HashMap<Integer, List<Integer>> reachability = new HashMap<>();

    // constructor
    public DirectedGraph(int V) {
        this.V = V;
        // define the size of array as
        // number of vertices
        adjListArray = new LinkedList[V];

        // Create a new list for each vertex
        // such that adjacent nodes can be stored

        for (int i = 0; i < V; i++) {
            adjListArray[i] = new LinkedList<Integer>();
        }
    }

    // Driver program to test above
    public static void main(String[] args) {
        // Create a graph given in the above diagram
        DirectedGraph g = new DirectedGraph(5); // 5 vertices numbered from 0 to 4

        g.addEdge(1, 0);
        g.addEdge(2, 3);
        g.addEdge(3, 4);
        System.out.println("Following are connected components");
        g.connectedComponents();
    }

    public HashMap<Integer, List<Integer>> getReachability() {
        return reachability;
    }

    /**
     * checks if an integer reaches all other vertices
     *
     * @param V
     * @return
     */
    public boolean reachesAll(int V) {
        return reachability.get(V).size() == this.V;

    }

    public boolean reaches(int a, int b) {
        return reachability.get(a).contains(b);
    }

    // Adds an edge to an undirected graph
    public void addEdge(int src, int dest) {
        // Add an edge from src to dest.
        adjListArray[src].add(dest);

        // Since graph is undirected, add an edge from dest
        // to src also
//        adjListArray[dest].add(src);
    }

    public void DFSUtil(int v, boolean[] visited) {
        // Mark the current node as visited and print it
        visited[v] = true;
        System.out.print(v + " ");
        // Recur for all the vertices
        // adjacent to this vertex
        for (int x : adjListArray[v]) {
            if (!visited[x]) DFSUtil(x, visited);
        }

    }

    public void connectedComponents() {
        // Mark all the vertices as not visited
        boolean[] visited = new boolean[V];
        for (int v = 0; v < V; ++v) {
            if (!visited[v]) {
                // print all reachable vertices
                // from v
                DFSUtil(v, visited);
                System.out.println();
            }
        }
    }

    public void reachability() {


        for (int v = 0; v < V; ++v) {
            List<Integer> reachable = new ArrayList<>();
            BFSUtil(v, reachable);
            reachability.put(v, reachable);
        }

    }

    void BFSUtil(int v, List<Integer> reachability) {
        // Mark all the vertices as not visited(By default
        // set as false)
        boolean[] visited = new boolean[V];

        // Create a queue for BFS
        LinkedList<Integer> queue = new LinkedList<Integer>();

        // Mark the current node as visited and enqueue it
        visited[v] = true;
        queue.add(v);

        while (queue.size() != 0) {
            // Dequeue a vertex from queue and print it

            v = queue.poll();
            reachability.add(v);

            // Get all adjacent vertices of the dequeued vertex s
            // If a adjacent has not been visited, then mark it
            // visited and enqueue it
            Iterator<Integer> i = adjListArray[v].listIterator();
            while (i.hasNext()) {
                int n = i.next();
                if (!visited[n]) {
                    visited[n] = true;
                    queue.add(n);
                }
            }
        }
    }
}
