package util;

import soot.G;
import soot.Scene;
import soot.SootClass;
import soot.SootMethod;
import soot.options.Options;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

public class MethodNameFinder {
    public static void main(String[] args) throws FileNotFoundException {

        Scanner in = new Scanner(new File(args[0]));
        while (in.hasNext()) {
            String[] elems = in.nextLine().split("\t");

            System.out.println(elems.toString());
            String className = elems[1];
            System.out.println(className);

            Scene.v().addBasicClass(className, SootClass.SIGNATURES);
            String sootClassPath = Scene.v().getSootClassPath() + File.pathSeparator + elems[0];

            Options.v().set_keep_line_number(true);
            Options.v().set_verbose(true);
            Options.v().setPhaseOption("jb", "use-original-names");
            Options.v().set_include_all(true);
            Options.v().set_whole_program(true);

            Scene.v().setSootClassPath(sootClassPath);


            Options.v().set_whole_shimple(true);


//load the class you want to analyze
//            for(SootClass sootClass: Scene.v().getApplicationClasses()){
//                System.out.println(sootClass.toString());
//            }
            SootClass sc = Scene.v().loadClassAndSupport(className);

//load any other necessary classes
            Scene.v().loadNecessaryClasses();

//application classes and library classes distinguished in soot
            sc.setApplicationClass();

            List<SootMethod> sootMethods = sc.getMethods();
            for (SootMethod sootMethod : sootMethods) {
                System.out.println(sootMethod.getNumberedSubSignature());
            }

            G.reset();
        }
    }
}
