package util;

public class Registrar {
    String[] files;
    String firstVersionClassPath;
    String secondVersionClassPath;
    String firstPrefix;
    String secondPrefix;
    String systemName;
    String revNumber;
    int type;

    public String[] getFiles() {
        return files;
    }

    public void setFiles(String[] files) {
        this.files = files;
    }

    public String getFirstVersionClassPath() {
        return firstVersionClassPath;
    }

    public void setFirstVersionClassPath(String firstVersionClassPath) {
        this.firstVersionClassPath = firstVersionClassPath;
    }

    public String getSecondVersionClassPath() {
        return secondVersionClassPath;
    }

    public void setSecondVersionClassPath(String secondVersionClassPath) {
        this.secondVersionClassPath = secondVersionClassPath;
    }

    public String getFirstPrefix() {
        return firstPrefix;
    }

    public void setFirstPrefix(String firstPrefix) {
        this.firstPrefix = firstPrefix;
    }

    public String getSecondPrefix() {
        return secondPrefix;
    }

    public void setSecondPrefix(String secondPrefix) {
        this.secondPrefix = secondPrefix;
    }

    public String getSystemName() {
        return systemName;
    }

    public void setSystemName(String systemName) {
        this.systemName = systemName;
    }

    public String getRevNumber() {
        return revNumber;
    }

    public void setRevNumber(String revNumber) {
        this.revNumber = revNumber;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
