package util;

import com.github.gumtreediff.matchers.Mapping;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.tree.ITree;
import com.github.gumtreediff.tree.TreeContext;
import javafx.util.Pair;
import org.eclipse.jdt.internal.compiler.ast.MethodDeclaration;
import soot.*;
import soot.jimple.*;
import soot.jimple.internal.*;
import soot.jimple.toolkits.annotation.logic.Loop;
import soot.jimple.toolkits.annotation.logic.LoopFinder;
import soot.options.Options;
import soot.tagkit.InnerClassTag;
import soot.tagkit.Tag;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.util.Chain;
import soot.util.NumberedString;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static util.Constants.*;


public class SootUtilities {

    public static void setUpSootEnvironmentWithCheck(String classPath) {
        if (!Scene.v().getSootClassPath().contains(classPath)) {
            G.reset();
            setUpSootEnvironment(classPath);
        }
    }

    /*
     * this method is used to set up the soot environment; we need certain options for the callgraph to be constructed.
     * in order to facilitate the construction of the callgraph for large programs, we set the process_dir as the classpath
     * this will enable us to construct the callgraph based on all the classes
     * @param classPath
     */
    public static void setUpSootEnvironment(String classPath) {

        String sootClassPath = Scene.v().getSootClassPath() + File.pathSeparator + classPath;
        Scene.v().setSootClassPath(sootClassPath);
        Options.v().set_keep_line_number(true);
        Options.v().set_whole_program(true);
        Options.v().set_full_resolver(true);
        Options.v().set_permissive_resolving(true);

        Options.v().set_allow_phantom_refs(true);
        Options.v().set_output_format(Options.output_format_jimple);
        Options.v().setPhaseOption("cg.spark", "add-tags:true");
        Options.v().set_verbose(true);


        Options.v().setPhaseOption("cg.spark", "on");
        Options.v().setPhaseOption("cg", "all-reachable:true");
        Options.v().set_print_tags_in_output(true);
        Options.v().setPhaseOption("jb.lns", "enabled:true");
        Options.v().setPhaseOption("jb.a", "enabled:false");
        Options.v().setPhaseOption("jb.a", "only-stack-locals:false");
        Options.v().setPhaseOption("jb.cp", "enabled:false");
        Options.v().setPhaseOption("jb.cp", "only-stack-locals:false");
        Options.v().setPhaseOption("jb.ulp", "enabled:false");
        Options.v().setPhaseOption("jb.cp-ule", "enabled:false");
        Options.v().setPhaseOption("jb.lp", "enabled:false");
        Options.v().setPhaseOption("wjop.si", "enabled:false");
        Options.v().setPhaseOption("jop.cpf", "enabled:false");
        Options.v().setPhaseOption("jj.cp", "enabled:false");
        Options.v().setPhaseOption("jj.cp", "only-stack-locals:false");
        Options.v().setPhaseOption("jop.cp", "enabled:false");


        List<String> process_dir = new ArrayList<>();
        String[] classPathArgs = classPath.split(":");
        process_dir.add(classPathArgs[classPathArgs.length - 1]);
        Options.v().set_process_dir(process_dir);
        Options.v().setPhaseOption("jb", "use-original-names");
        for (SootClass sootClass : Scene.v().getApplicationClasses()) {
            Scene.v().loadClassAndSupport(sootClass.getName());
        }
        System.out.println("Soot loading necessary classes");
        try {
            Scene.v().loadNecessaryClasses();
        } catch (IllegalArgumentException iae) {
            System.out.println("iae");
        }
        System.out.println("All classes loaded");


    }

    public static void setUpSootEnvironment(String classPath, String reflectionLog) {

        String sootClassPath = Scene.v().getSootClassPath() + File.pathSeparator + classPath;
        Scene.v().setSootClassPath(sootClassPath);
        Options.v().set_keep_line_number(true);
        Options.v().setPhaseOption("jb", "use-original-names");
        Options.v().set_include_all(true);
        Options.v().set_whole_program(true);
        Options.v().set_output_format(Options.output_format_jimple);
        Options.v().set_verbose(true);


        Options.v().set_allow_phantom_refs(true);

        Options.v().set_full_resolver(true);
        Options.v().set_permissive_resolving(true);
        String reflectionOption = "reflection-log:" + reflectionLog;
        Options.v().setPhaseOption("cg", reflectionOption);
        Options.v().setPhaseOption("cg.spark", "on");
        Options.v().setPhaseOption("cg", "all-reachable:true");
        Options.v().setPhaseOption("cg.spark", "add-tags:true");
        Options.v().set_print_tags_in_output(true);


        List<String> process_dir = new ArrayList<>();
        String[] classPathArgs = classPath.split(":");
        process_dir.add(classPathArgs[classPathArgs.length - 1]);
        Options.v().set_process_dir(process_dir);
        for (SootClass sootClass : Scene.v().getApplicationClasses()) {
            Scene.v().loadClassAndSupport(sootClass.getName());
        }
        System.out.println("Soot loading necessary classes");
        try {
            Scene.v().loadNecessaryClasses();
        } catch (IllegalArgumentException iae) {
            System.out.println("iae");
        }
        System.out.println("All classes loaded");

    }

    /**
     * Turn a filepath into a className, preserving the package name too
     *
     * @param prefix   the path from the root of the system to the beginning of the source code packages
     * @param fileName the name of the java file
     * @return
     */
    public static String getClassName(String prefix, String fileName) {
        fileName = fileName.substring(prefix.length(), fileName.length() - 5).replace(File.pathSeparator, ".");
        if (fileName.startsWith("/")) {
            fileName = fileName.substring(1);
        }
        if(fileName.endsWith("/")){
            fileName = fileName.substring(0, fileName.length()-1);
        }
        if(fileName.contains("/")){
            fileName = fileName.replace("/", ".");
        }
        return fileName;

    }

    public static String getClassName(String prefix, String fileName, boolean ofbiz) {
        fileName = fileName.substring(prefix.length() - 1, fileName.length() - 5).replace(File.pathSeparator, ".");
        if (fileName.startsWith("/")) {
            fileName = fileName.substring(1);
        }
        if (fileName.endsWith("/")) {
            fileName = fileName.substring(0, fileName.length() - 1);
        }
        if (fileName.contains("/")) {
            fileName = fileName.replace("/", ".");
        }
        int index = fileName.indexOf("org");
        if (index == -1) {
            System.out.println("-1 figure out how to deal with these!");
        }
        fileName = fileName.substring(index);

        return fileName;
    }

    public static String getClassName(String fileName, boolean ofbiz) {

        int index = fileName.indexOf("/org/");
        fileName = fileName.substring(index).replaceAll("/", ".").replace(".java", "");
        if (fileName.startsWith(".")) {
            fileName = fileName.substring(1);
        }
        if (fileName.endsWith(".")) {
            fileName = fileName.substring(0, fileName.length() - 1);
        }

        return fileName;
    }

    public static SootField getField(ITree node, String className, TreeContext treeContext) {

        SootClass sootClass = Scene.v().loadClassAndSupport(className);
        Chain<SootField> classFields = sootClass.getFields();
        for (SootField classField : classFields) {
            String name = classField.getName();
            boolean nameInChildren = nameInChildrenField(name, node, treeContext);
            if (nameInChildren) {
                //this is a constructor
                return classField;
            }
        }
        return null;


    }


    /**
     * this method returns a pair of the method in which the vulnerable node is and the corresponding soot unit to that node.
     *
     * @param className      -the name of the class where this change happens
     * @param vulnerableNode - the ITree object representing the vulnerable node, which we get from the VulnerableNodeIdentifier
     * @return
     */
    public static Pair<SootMethod, Unit> getUnit(String className, ITree vulnerableNode, TreeContext treeContext) {
        Pair<SootMethod, Unit> pair = new Pair<>(null, null);
        try {
            int line = vulnerableNode.getPos();
            String variable = vulnerableNode.getLabel();

            SootClass sc = Scene.v().loadClassAndSupport(className);
            Scene.v().loadNecessaryClasses();
            sc.setApplicationClass();
            String vulnerableNodeType = vulnerableNode.toPrettyString(treeContext);
            if (vulnerableNodeType.equalsIgnoreCase(FIELD_DECL)) {
                Chain<SootField> classFields = sc.getFields();
                for (SootField classField : classFields) {
                    String name = classField.getName();
                    boolean nameInChildren = nameInChildren(name, vulnerableNode);
                    //TODO need to handle cases like this
                    if (nameInChildren) {
                        //this is a constructor
                        return new Pair<SootMethod, Unit>(null, (Unit) classField);
                    }
                }
            }

            List<SootMethod> sootMethodList = sc.getMethods();
            SootMethod method = null;
            Unit unit = null;
            List<SootMethod> secondRoundMethods = new ArrayList<>();

            if (sc.isAbstract() || sc.isInterface()) {
                //TODO handle abstact classes and interfaces
            } else {
                int previousMethodLastLine = 0;
                methodloop:
                for (SootMethod sootMethod : sootMethodList) {
                    int firstLine = sootMethod.getJavaSourceStartLineNumber();
                    MethodSource methodSource = sootMethod.getSource();
                    if (methodSource != null || sootMethod.hasActiveBody()
                            && (!sootMethod.getName().equalsIgnoreCase("<clinit>")
                            && !sootMethod.getName().equalsIgnoreCase("<init>"))) {

                        Body methodBody = sootMethod.retrieveActiveBody();
                        ExceptionalUnitGraph exceptionalUnitGraph = new ExceptionalUnitGraph(methodBody);
                        PatchingChain<Unit> methodUnits = methodBody.getUnits();


                        int previousUnitsSize = methodBody.getUnits().size();
                        int lastLine = getMethodLastLine(methodBody);
                        int currentUnitsSize = methodBody.getUnits().size();
                        if (previousUnitsSize > currentUnitsSize) {
                            System.out.println("ERROR!! METHODS ARE BEING DELETED");
                        }

                        if ((line >= firstLine && line <= lastLine) || (line >= previousMethodLastLine && line <= lastLine)) {
                            if (!sootMethod.isConstructor()) {
                                previousMethodLastLine = lastLine;
                            }
                            if (!secondRoundMethods.contains(sootMethod)) {
                                secondRoundMethods.add(sootMethod);
                            }
                            //if the method declaration is inserted, then we consider its entry point being vulnerable
                            if (vulnerableNode.toPrettyString(treeContext).equalsIgnoreCase(MET_DECL)) {
                                method = sootMethod;
                                unit = exceptionalUnitGraph.getHeads().get(0);
                                if (vulnerableNode instanceof MethodDeclaration) {
                                    MethodDeclaration methodDeclaration = (MethodDeclaration) vulnerableNode;
                                    if (sootMethod.getSignature().equalsIgnoreCase(methodDeclaration.toString())) {
                                        System.out.println("it works");
                                    }
                                }
                                break methodloop;
                            }


                            for (Unit methodUnit : methodUnits) {
                                Tag lineNumberTag = methodUnit.getTag("LineNumberTag");
                                int linefromNumberTag = 0;
                                if (lineNumberTag != null) {
                                    linefromNumberTag = new BigInteger(lineNumberTag.getValue()).intValue();
                                }

                                if (methodUnit.getJavaSourceStartLineNumber() == line || linefromNumberTag == line) {
                                    Pair<SootMethod, Unit> getUnitPair = getUnit(variable, methodUnit, vulnerableNode, treeContext, sootMethod, methodBody);
                                    if (getUnitPair.getKey() != null && getUnitPair.getValue() != null) {
                                        method = getUnitPair.getKey();
                                        unit = getUnitPair.getValue();
                                        break methodloop;
                                    }

                                }
                            }
                        }
                    }


                }


                //do a second check with looser boundaries on the line
                if (method == null && unit == null) {
                    methodloop:
                    for (SootMethod sootMethod : secondRoundMethods) {
                        if (sootMethod.hasActiveBody()) {
                            Body methodBody = sootMethod.retrieveActiveBody();
                            PatchingChain<Unit> methodUnits = methodBody.getUnits();

                            for (Unit methodUnit : methodUnits) {
                                Tag lineNumberTag = methodUnit.getTag("LineNumberTag");
                                int linefromNumberTag = 0;
                                if (lineNumberTag != null) {
                                    linefromNumberTag = new BigInteger(lineNumberTag.getValue()).intValue();
                                }

                                int methodUnitLine = methodUnit.getJavaSourceStartLineNumber();

                                if ((methodUnitLine + 5 >= line && methodUnitLine - 5 <= line) || (linefromNumberTag + 5 >= line && linefromNumberTag - 5 <= line)) {
                                    Pair<SootMethod, Unit> getUnitPair = getUnit(variable, methodUnit, vulnerableNode, treeContext, sootMethod, methodBody);
                                    if (getUnitPair.getKey() != null && getUnitPair.getValue() != null) {
                                        method = getUnitPair.getKey();
                                        unit = getUnitPair.getValue();
                                        break methodloop;
                                    }

                                }
                            }
                        }
                    }
                }
                pair = new Pair<>(method, unit);
                return pair;
            }
        } catch (Exception e) {
            pair = new Pair<>(null, null);
            System.out.println(Scene.v().getSootClassPath());
            System.out.println("error message " + e.getLocalizedMessage());
        } finally {
            return pair;
        }
    }

    /**
     * finds the name of any method (gumtree format) given a node and context
     * @param node
     * @param treeContext
     * @return
     * @throws IOException
     */
    public static String getMethodName(ITree node, TreeContext treeContext) {
        String name = "";
        node = getMethod(node, treeContext);
        if (!node.isRoot()) {
            List<ITree> children = node.getChildren();
            for (ITree child : children) {
                String type = child.toPrettyString(treeContext).split(":")[0];
                if (type.equalsIgnoreCase(SIMPLE_NAME) && child.hasLabel()) {
                    name = child.getLabel();
                }
            }
        } else {
            name = "init";
        }
        return name.trim();
    }


    /**
     * this method finds and returns the method of any node
     * @param node
     * @param treeContext
     * @return
     */
    public static ITree getMethod(ITree node, TreeContext treeContext) {

        if (!node.toPrettyString(treeContext).equalsIgnoreCase(MET_DECL)) {
            while (!node.toPrettyString(treeContext).equalsIgnoreCase(MET_DECL) && !node.isRoot()) {
                node = node.getParent();
            }
        }

        return node;
    }

    /**
     * this method finds the method of vulnerable nodes identified in the AST patch
     * uses method boundary lines
     * processes the constructors last
     *
     * @param vulnerableNode
     * @return
     */
    public static SootMethod getSootMethod(ITree vulnerableNode, String className, TreeContext treeContext) {
        SootMethod method = null;
        try {
            int line = vulnerableNode.getPos();

            String methodName = getMethodName(vulnerableNode, treeContext);
            SootClass sc = Scene.v().loadClassAndSupport(className);

            Scene.v().loadNecessaryClasses();
            sc.setApplicationClass();
            List<SootMethod> sootMethods = sc.getMethods();
            List<NumberedString> constructorName = new ArrayList<>();
            int previousMethodLastLine = 0;
            for (SootMethod sootMethod : sootMethods) {
                int firstLine = sootMethod.getJavaSourceStartLineNumber();
                MethodSource methodSource = sootMethod.getSource();
                if (sootMethod.isConstructor()) {
                    constructorName.add(sootMethod.getNumberedSubSignature());
                }
                if (methodSource != null || sootMethod.hasActiveBody()
                        && (!sootMethod.getName().equalsIgnoreCase("<clinit>")
                        && !sootMethod.getName().equalsIgnoreCase("<init>"))) {

                    Body methodBody = sootMethod.retrieveActiveBody();

                    PatchingChain<Unit> methodUnits = methodBody.getUnits();

                    Iterator<Unit> methodUnitsIterator = methodUnits.iterator();
                    while (firstLine == -1) {
                        if (methodUnitsIterator.hasNext()) {
                            Unit unit = methodUnitsIterator.next();
                            firstLine = unit.getJavaSourceStartLineNumber();
                            Tag lineNumberTag = unit.getTag("LineNumberTag");
                            if (lineNumberTag != null) {
                                firstLine = new BigInteger(lineNumberTag.getValue()).intValue();
                            }
                        } else {
                            break;
                        }

                    }


                    int previousUnitsSize = methodBody.getUnits().size();
                    int lastLine = getMethodLastLine(methodBody);
                    int currentUnitsSize = methodBody.getUnits().size();
                    if (previousUnitsSize > currentUnitsSize) {
                        System.out.println("ERROR!! METHODS ARE BEING DELETED");
                    }

                    if ((line >= firstLine && line <= lastLine) || (line >= previousMethodLastLine && line <= lastLine)) {
                        if (!sootMethod.isConstructor()) {
                            previousMethodLastLine = lastLine;
                        }

                        if (methodName.equalsIgnoreCase(sootMethod.getName())) {
                            method = sootMethod;
                            if (!method.isConstructor()) {
                                break;
                            }
                        }
                    }
                }

            }
            String classNameProcessed = className;
            if (classNameProcessed.contains("\\$")) {
                String[] classNameSplit = classNameProcessed.split("\\$");
                classNameProcessed = classNameSplit[classNameSplit.length - 1];
            }

            if (classNameProcessed.contains(".")) {
                String[] classNameSplit = classNameProcessed.split("\\.");
                classNameProcessed = classNameSplit[classNameSplit.length - 1];

            }
            boolean constructorMethod = method == null && constructorName.size() > 0 && (methodName.equalsIgnoreCase("init") || methodName.equalsIgnoreCase(classNameProcessed));
            if (constructorMethod) {
                inner:
                for (NumberedString numberedString : constructorName) {
                    SootMethod constructor = sc.getMethod(numberedString);
                    int firstLine = constructor.getJavaSourceStartLineNumber();
                    int lastLine = getMethodLastLine(constructor.retrieveActiveBody());
                    if (firstLine - 1 <= line && lastLine + 1 >= line) {
                        method = constructor;
                        break inner;
                    }
                }
            } else if (method == null) {
                List<Tag> tags = sc.getTags();
                for (Tag tag : tags) {
                    if (tag instanceof InnerClassTag) {
                        InnerClassTag innerClassTag = (InnerClassTag) tag;
                        String innerClass = innerClassTag.getInnerClass().replace("/", ".");
                        SootClass sootClass = Scene.v().loadClassAndSupport(innerClass);
                        SootMethod method1 = SootUtilities.getSootMethod(sootClass, methodName, line);
                        if (method1 != null) {
                            method = method1;
                            break;
                        }

                    }
                }

            }

            if (method != null) {

            }
        } catch (Exception e) {
            System.out.println("Exception caught at: " + Arrays.toString(e.getStackTrace()));
        } finally {
            return method;
        }


    }

    /**
     * this method is used to get a sootmethod object given a method name and a line
     *
     * @param sootClass
     * @param methodName
     * @param line
     * @return
     */
    public static SootMethod getSootMethod(SootClass sootClass, String methodName, int line) {
        SootMethod method = null;
        int previousMethodLastLine = 0;
        NumberedString constructorName = null;
        List<SootMethod> sootMethods = sootClass.getMethods();
        for (SootMethod sootMethod : sootMethods) {
            int firstLine = sootMethod.getJavaSourceStartLineNumber();
            MethodSource methodSource = sootMethod.getSource();
            if (sootMethod.isConstructor()) {
                constructorName = sootMethod.getNumberedSubSignature();
            }
            if (methodSource != null || sootMethod.hasActiveBody()
                    && (!sootMethod.getName().equalsIgnoreCase("<clinit>")
                    && !sootMethod.getName().equalsIgnoreCase("<init>"))) {

                Body methodBody = sootMethod.retrieveActiveBody();

                PatchingChain<Unit> methodUnits = methodBody.getUnits();

                Iterator<Unit> methodUnitsIterator = methodUnits.iterator();
                while (firstLine == -1) {
                    if (methodUnitsIterator.hasNext()) {
                        Unit unit = methodUnitsIterator.next();
                        firstLine = unit.getJavaSourceStartLineNumber();
                        Tag lineNumberTag = unit.getTag("LineNumberTag");
                        if (lineNumberTag != null) {
                            firstLine = new BigInteger(lineNumberTag.getValue()).intValue();
                        }
                    } else {
                        break;
                    }

                }


                int previousUnitsSize = methodBody.getUnits().size();
                int lastLine = getMethodLastLine(methodBody);
                int currentUnitsSize = methodBody.getUnits().size();
                if (previousUnitsSize > currentUnitsSize) {
                    System.out.println("ERROR!! METHODS ARE BEING DELETED");
                }

                if ((line >= firstLine && line <= lastLine) || (line >= previousMethodLastLine && line <= lastLine)) {
                    if (!sootMethod.isConstructor()) {
                        previousMethodLastLine = lastLine;
                    }

                    if (methodName.equalsIgnoreCase(sootMethod.getName())) {
                        method = sootMethod;
                        if (!method.isConstructor()) {
                            break;
                        }
                    }
                }
            }

        }
        String[] classNameSplit = sootClass.getName().split("\\$");
        String classNameProcessed = "";
        if (classNameSplit.length == 2) {
            classNameProcessed = classNameSplit[1];

        }
        if (method == null && constructorName != null && (methodName.equalsIgnoreCase("init") || methodName.equalsIgnoreCase(classNameProcessed))) {
            method = sootClass.getMethod(constructorName);
        }

        return method;
    }

    public static Pair<SootMethod, Unit> getUnit(String variable, Unit methodUnit, ITree vulnerableNode, TreeContext treeContext,
                                                 SootMethod sootMethod, Body methodBody) {
        SootMethod method;
        Unit unit;
        if (!variable.equalsIgnoreCase("")) {
            String name = getUnitName(methodUnit, variable);
            if (name.equalsIgnoreCase(variable)) {
                method = sootMethod;
                unit = methodUnit;
                return new Pair<>(method, unit);
            }
        }
        if (vulnerableNode.toPrettyString(treeContext).equalsIgnoreCase(BLOCK)) {
            method = sootMethod;
            unit = methodUnit;
            return new Pair<>(method, unit);
        }
        if (vulnerableNode.toPrettyString(treeContext).contains(INFIX) || vulnerableNode.toPrettyString(treeContext).contains(POSTFIX)) {
            if (!vulnerableNode.isRoot()) {
                vulnerableNode = vulnerableNode.getParent();
            }
        }
        String type = vulnerableNode.toPrettyString(treeContext).split(":")[0];

        String unitClass = methodUnit.getClass().toString();
        //if the vulnerable node is an ifstatement, it will usually have no label
        //so we instead compare the types, rather than the labels
        if (type.contains("IfSt") && unitClass.contains("IfSt")) {
            method = sootMethod;
            unit = methodUnit;
            return new Pair<>(method, unit);
        }
        //if the node is a variable declaration statement and it does not have a label
        //the corresponding unit will be an assignment statement
        //however, we need to check if the value of the left box, which is the name of the variable
        //is human created or machine created (the way to tell is machine created values have a $ in front)
        //we pick the human created value
        if (type.equalsIgnoreCase(VAR_DECL) || type.equalsIgnoreCase(FIELD_DECL)
                || type.equalsIgnoreCase(VAR_FRAG) || type.equalsIgnoreCase(ASSGNMT)) {
            if (methodUnit instanceof AssignStmt) {
                AssignStmt assignStmt = (AssignStmt) methodUnit;
                String value = assignStmt.getLeftOpBox().getValue().toString();
                if (!value.startsWith("$")) {
                    method = sootMethod;
                    unit = methodUnit;
                    return new Pair<>(method, unit);
                }
            }
        }
        //if the node is method invocation, we need to check if the unit at hand is
        //an assignment and get the name of the method it's calling
        //at the same time, method invocations have their labels in their child list
        //so we compare the name from the invocation method in soot with the name in the child list

        if (type.equalsIgnoreCase(MET_INV)) {
            if (methodUnit instanceof InvokeStmt) {
                InvokeStmt invokeStmt = (InvokeStmt) methodUnit;
                ValueBox invokeExprBox = invokeStmt.getInvokeExprBox();

                if (invokeExprBox.getValue() instanceof JInterfaceInvokeExpr) {
                    JInterfaceInvokeExpr jInterfaceInvokeExpr = (JInterfaceInvokeExpr) invokeExprBox.getValue();

                    String name = jInterfaceInvokeExpr.getBase().toString();
                    if (name.equalsIgnoreCase(variable)) {
                        method = sootMethod;
                        unit = methodUnit;
                        return new Pair<>(method, unit);
                    } else if (!vulnerableNode.isLeaf()) {
                        boolean nameInChild = nameInChildren(name, vulnerableNode);

                        if (nameInChild) {
                            method = sootMethod;
                            unit = methodUnit;
                            return new Pair<>(method, unit);
                        }


                    }
                }
                if (invokeExprBox.getValue() instanceof JVirtualInvokeExpr) {
                    JVirtualInvokeExpr jVirtualInvokeExpr = (JVirtualInvokeExpr) invokeExprBox.getValue();

                    String name = jVirtualInvokeExpr.getMethodRef().name();
                    if (name.equalsIgnoreCase(variable)) {
                        method = sootMethod;
                        unit = methodUnit;
                        return new Pair<>(method, unit);
                    } else if (!vulnerableNode.isLeaf()) {
                        boolean nameInChildren = nameInChildren(name, vulnerableNode);

                        if (nameInChildren) {
                            method = sootMethod;
                            unit = methodUnit;
                            return new Pair<>(method, unit);


                        }
                    }

                }
                if (invokeExprBox.getValue() instanceof JStaticInvokeExpr) {
                    JStaticInvokeExpr jStaticInvokeExpr = (JStaticInvokeExpr) invokeExprBox.getValue();
                    String name = jStaticInvokeExpr.getMethodRef().name();
                    if (name.equalsIgnoreCase(variable)) {
                        method = sootMethod;
                        unit = methodUnit;
                        return new Pair<>(method, unit);
                    } else if (!vulnerableNode.isLeaf()) {
                        boolean nameInChildren = nameInChildren(name, vulnerableNode);
                        if (nameInChildren) {
                            method = sootMethod;
                            unit = methodUnit;
                            return new Pair<>(method, unit);
                        }


                    }
                }

            }

            if (methodUnit instanceof AssignStmt) {
                AssignStmt assignStmt = (AssignStmt) methodUnit;
                Value rightValue = assignStmt.getRightOp();
                String methodUnitname = "";
                if (rightValue instanceof InvokeExpr) {
                    methodUnitname = ((InvokeExpr) rightValue).getMethodRef().name();
                }
                List<String> vulnerableNodeName = new ArrayList<>();
                if (!vulnerableNode.isLeaf()) {
                    ITree vulnerableNodeChild = vulnerableNode.getChildren().get(0);
                    if (vulnerableNodeChild.hasLabel()) {
                        if (!vulnerableNodeName.contains(vulnerableNodeChild.getLabel())) {
                            vulnerableNodeName.add(vulnerableNodeChild.getLabel());
                        }
                    }
                }
                for (ITree child : vulnerableNode.getChildren()) {
                    if (child.hasLabel()) {
                        if (!vulnerableNodeName.contains(child.getLabel())) {
                            vulnerableNodeName.add(child.getLabel());
                        }
                    }
                }
                if (vulnerableNodeName.contains(methodUnitname)) {
                    method = sootMethod;
                    unit = methodUnit;
                    return new Pair<>(method, unit);
                }

            }
        }
        if (type.equalsIgnoreCase(WHILE_STMT) || type.equalsIgnoreCase(FOR_STMT)) {

            LoopFinder loopFinder = new LoopFinder();
            loopFinder.transform(methodBody);
            Collection<Loop> loops = loopFinder.loops();
            Iterator<Loop> loopIterator = loops.iterator();
            while (loopIterator.hasNext()) {
                Loop loop = loopIterator.next();
                Stmt loopStmt = loop.getHead();
                if (methodUnit.equals(loopStmt)) {
                    if (methodUnit.getJavaSourceStartLineNumber() == vulnerableNode.getPos()) {
                        method = sootMethod;
                        unit = methodUnit;
                        return new Pair<>(method, unit);
                    }
                }
            }

        }
        if (type.equalsIgnoreCase(RETURN)) {
            if (methodUnit instanceof ReturnStmt) {
                method = sootMethod;
                unit = methodUnit;
                return new Pair<>(method, unit);
            }
        }
        if (type.equalsIgnoreCase(EXPRSSSTMT)) {
            if (methodUnit instanceof AssignStmt) {
                method = sootMethod;
                unit = methodUnit;
                return new Pair<>(method, unit);

            }
        }
        if (type.equalsIgnoreCase(SINGLE_VAR_DECL)) {
            if (methodUnit instanceof IdentityStmt) {
                Value identityRefBox = ((IdentityStmt) methodUnit).getRightOp();
                if (identityRefBox instanceof ParameterRef) {
                    method = sootMethod;
                    unit = methodUnit;
                    return new Pair<>(method, unit);
                }
            }

        }
        if (type.equalsIgnoreCase(SWITCH_STMT)) {
            if (methodUnit instanceof SwitchStmt) {
                method = sootMethod;
                unit = methodUnit;
                return new Pair<>(method, unit);
            }
        }
        if (type.equalsIgnoreCase(TRY_STMT)) {
            List<Unit> trapUnits = getTrapRelatedUnits(methodBody);
            for (Unit trapUnit : trapUnits) {
                if (trapUnit.getJavaSourceStartLineNumber() == vulnerableNode.getPos()) {
                    method = sootMethod;
                    unit = trapUnit;
                    return new Pair<>(method, unit);
                }
            }
        }
        if (type.equalsIgnoreCase(CATCH_CLAUSE)) {
            List<Unit> trapUnits = getTrapRelatedUnits(methodBody);
            for (Unit trapUnit : trapUnits) {
                if (trapUnit.getJavaSourceStartLineNumber() == vulnerableNode.getPos()) {
                    method = sootMethod;
                    unit = trapUnit;
                    return new Pair<>(method, unit);
                }
            }
        }
        if (type.equalsIgnoreCase(THROW_STMT)) {
            if (methodUnit instanceof ThrowStmt) {
                method = sootMethod;
                unit = methodUnit;
                return new Pair<>(method, unit);
            }
        }
        if (type.equalsIgnoreCase(SYNC_STMT)) {
            if (methodUnit instanceof EnterMonitorStmt) {
                method = sootMethod;
                unit = methodUnit;
                return new Pair<>(method, unit);
            }
        }


        return new Pair<>(null, null);
    }

    /**
     * this method is used to compare an ITree To Unit (that have already been checked that they are more or less in the same line) and return true if they match
     *
     * @param variable
     * @param methodUnit
     * @param vulnerableNode
     * @param treeContext
     * @param methodBody
     * @return
     */
    public static boolean isITreeUnit(String variable, Unit methodUnit, ITree vulnerableNode, TreeContext treeContext,
                                      Body methodBody) {
        if (!variable.equalsIgnoreCase("")) {
            String name = getUnitName(methodUnit, variable);
            if (name.equalsIgnoreCase(variable)) {
                return true;
            }
        }

        if (treeContext.getTypeLabel(vulnerableNode.getType()).equalsIgnoreCase(MOD)) {
            //SOOT DOesn't capture modifiers, just their count;
            return false;
        }

        if (vulnerableNode.toPrettyString(treeContext).contains(INFIX) || vulnerableNode.toPrettyString(treeContext).contains(POSTFIX)) {
            if (!vulnerableNode.isRoot()) {
                vulnerableNode = vulnerableNode.getParent();
            }
        }
        //when used with PatchAnatomy doesn't work
//        if (vulnerableNode.toPrettyString(treeContext).equalsIgnoreCase(BLOCK)) {
//            return true;
//        }


        String type = vulnerableNode.toPrettyString(treeContext).split(":")[0];

        String unitClass = methodUnit.getClass().toString();
        //if the vulnerable node is an ifstatement, it will usually have no label
        //so we instead compare the types, rather than the labels
        if (type.contains("IfSt") && unitClass.contains("IfSt")) {
            return true;
        }
        //if the node is a variable declaration statement and it does not have a label
        //the corresponding unit will be an assignment statement
        //however, we need to check if the value of the left box, which is the name of the variable
        //is human created or machine created (the way to tell is machine created values have a $ in front)
        //we pick the human created value
        if (type.equalsIgnoreCase(VAR_DECL) || type.equalsIgnoreCase(FIELD_DECL)
                || type.equalsIgnoreCase(VAR_FRAG) || type.equalsIgnoreCase(ASSGNMT)) {
            if (methodUnit instanceof AssignStmt) {
                AssignStmt assignStmt = (AssignStmt) methodUnit;
                String value = assignStmt.getLeftOpBox().getValue().toString();
                if (vulnerableNode.getPos() == SootUtilities.getUnitLineNumber(methodUnit)) {
                    return !value.startsWith("$");
                }
            }
        }

        if (type.equalsIgnoreCase(CONSTR_INV)) {
            if (methodUnit instanceof InvokeStmt) {
                InvokeStmt invokeStmt = (InvokeStmt) methodUnit;
                ValueBox invokeExprBox = invokeStmt.getInvokeExprBox();
                if (invokeExprBox.getValue() instanceof JSpecialInvokeExpr) {
                    JSpecialInvokeExpr jSpecialInvokeExpr = (JSpecialInvokeExpr) invokeExprBox.getValue();
                    String base = jSpecialInvokeExpr.getBase().toString();
                    String name = jSpecialInvokeExpr.getMethod().getName();
                    if (name.equalsIgnoreCase("<init>") && base.equalsIgnoreCase("this")) {
                        return true;
                    }
                }
            }
        }
        //if the node is method invocation, we need to check if the unit at hand is
        //an assignment and get the name of the method it's calling
        //at the same time, method invocations have their labels in their child list
        //so we compare the name from the invocation method in soot with the name in the child list

        if (type.equalsIgnoreCase(MET_INV)) {
            if (methodUnit instanceof InvokeStmt) {
                InvokeStmt invokeStmt = (InvokeStmt) methodUnit;
                ValueBox invokeExprBox = invokeStmt.getInvokeExprBox();
                if (invokeExprBox.getValue() instanceof JSpecialInvokeExpr) {
                    JSpecialInvokeExpr jSpecialInvokeExpr = (JSpecialInvokeExpr) invokeExprBox.getValue();
                    String name = jSpecialInvokeExpr.getMethod().getName();
                    if (name.equalsIgnoreCase(variable)) {

                        return true;
                    } else if (!vulnerableNode.isLeaf()) {
                        boolean nameInChild = nameInChildren(name, vulnerableNode);

                        if (nameInChild) {

                            return true;
                        }


                    }
                }
                if (invokeExprBox.getValue() instanceof JInterfaceInvokeExpr) {
                    JInterfaceInvokeExpr jInterfaceInvokeExpr = (JInterfaceInvokeExpr) invokeExprBox.getValue();

                    String name = jInterfaceInvokeExpr.getBase().toString();
                    //CVE-2012-0022_12 Parameters, method setEncoding
                    String methodName = jInterfaceInvokeExpr.getMethodRef().name();
                    if (name.equalsIgnoreCase(variable) || methodName.equals(variable)) {

                        return true;
                    } else if (!vulnerableNode.isLeaf()) {
                        boolean nameInChild = nameInChildren(name, vulnerableNode);
                        boolean methodNameInChild = nameInChildren(methodName, vulnerableNode);
                        if (nameInChild || methodNameInChild) {

                            return true;
                        }


                    }
                }
                if (invokeExprBox.getValue() instanceof JVirtualInvokeExpr) {
                    JVirtualInvokeExpr jVirtualInvokeExpr = (JVirtualInvokeExpr) invokeExprBox.getValue();

                    String name = jVirtualInvokeExpr.getMethodRef().name();
                    if (name.equalsIgnoreCase(variable)) {
                        return true;
                    } else if (!vulnerableNode.isLeaf()) {
                        boolean nameInChildren = nameInChildren(name, vulnerableNode);

                        if (nameInChildren) {
                            return true;
                        }
                    }

                }
                if (invokeExprBox.getValue() instanceof JStaticInvokeExpr) {
                    JStaticInvokeExpr jStaticInvokeExpr = (JStaticInvokeExpr) invokeExprBox.getValue();
                    String name = jStaticInvokeExpr.getMethodRef().name();
                    if (name.equalsIgnoreCase(variable)) {
                        return true;
                    } else if (!vulnerableNode.isLeaf()) {
                        boolean nameInChildren = nameInChildren(name, vulnerableNode);
                        if (nameInChildren) {
                            return true;
                        }

                    }
                }

            }

            if (methodUnit instanceof AssignStmt) {
                AssignStmt assignStmt = (AssignStmt) methodUnit;
                Value rightValue = assignStmt.getRightOp();
                String methodUnitname = "";
                if (rightValue instanceof InvokeExpr) {
                    methodUnitname = ((InvokeExpr) rightValue).getMethodRef().name();
                }
                List<String> vulnerableNodeName = new ArrayList<>();
                if (!vulnerableNode.isLeaf()) {
                    ITree vulnerableNodeChild = vulnerableNode.getChildren().get(0);
                    if (vulnerableNodeChild.hasLabel()) {
                        if (!vulnerableNodeName.contains(vulnerableNodeChild.getLabel())) {
                            vulnerableNodeName.add(vulnerableNodeChild.getLabel());
                        }
                    }
                }
                for (ITree child : vulnerableNode.getChildren()) {
                    if (child.hasLabel()) {
                        if (!vulnerableNodeName.contains(child.getLabel())) {
                            vulnerableNodeName.add(child.getLabel());
                        }
                    }
                }
                return vulnerableNodeName.contains(methodUnitname);

            }
        }
        if (type.equalsIgnoreCase(WHILE_STMT) || type.equalsIgnoreCase(FOR_STMT)) {

            LoopFinder loopFinder = new LoopFinder();
            loopFinder.transform(methodBody);
            Collection<Loop> loops = loopFinder.loops();
            Iterator<Loop> loopIterator = loops.iterator();
            while (loopIterator.hasNext()) {
                Loop loop = loopIterator.next();
                Stmt loopStmt = loop.getHead();
                if (methodUnit.equals(loopStmt)) {
                    if (methodUnit.getJavaSourceStartLineNumber() == vulnerableNode.getPos()) {
                        return true;
                    }
                }
            }

        }

        if (type.equalsIgnoreCase(RETURN)) {
            if (methodUnit instanceof ReturnStmt) {
                return true;
            }
        }

        if (type.equalsIgnoreCase(EXPRSSSTMT)) {
            if (methodUnit instanceof AssignStmt) {
                if (vulnerableNode.getPos() == SootUtilities.getUnitLineNumber(methodUnit)) {
                    return true;
                }

            }

            if (methodUnit instanceof InvokeStmt && vulnerableNode.getChildren().size() > 0) {
                ITree firstChild = vulnerableNode.getChild(0);
                if (treeContext.getTypeLabel(firstChild.getType()).equals(MET_INV)) {
                    return isITreeUnit(firstChild.getLabel(), methodUnit, firstChild, treeContext, methodBody);
                }

            }
        }
        if (type.equalsIgnoreCase(SINGLE_VAR_DECL)) {
            if (methodUnit instanceof IdentityStmt) {
                IdentityStmt identityStmt = (IdentityStmt) methodUnit;

                List<ITree> children = vulnerableNode.getChildren();
                String gtType = "";
                String gtName = "";
                for (ITree child : children) {
                    String typeLabel = treeContext.getTypeLabel(child);
                    if (typeLabel.equalsIgnoreCase(SIMPLE_TYPE) || typeLabel.equalsIgnoreCase(PRIM_TYPE)) {
                        gtType = child.getLabel().trim();
                    }

                    if (typeLabel.equalsIgnoreCase(SIMPLE_NAME)) {
                        gtName = child.getLabel().trim();
                    }

                }

                Value rightOp = identityStmt.getRightOp();
                boolean typeMatch = false;
                if (rightOp instanceof ParameterRef) {
                    String[] typeSplit = rightOp.getType().toString().split("\\.");
                    String typePar = typeSplit[typeSplit.length - 1].trim();
                    typeMatch = typePar.equalsIgnoreCase(gtType);

                }

                if (typeMatch) {
                    Value leftOp = identityStmt.getLeftOp();
                    if (leftOp instanceof JimpleLocal) {
                        JimpleLocal local = (JimpleLocal) leftOp;
                        String name = local.getName();
                        if (name.equalsIgnoreCase(gtName)) {
                            return true;
                        }
                    }

                }
            }

        }
        if (type.equalsIgnoreCase(SWITCH_STMT)) {
            if (methodUnit instanceof SwitchStmt) {
                return true;
            }
        }

        if (type.equalsIgnoreCase(TRY_STMT)) {
            List<Unit> trapUnits = getTrapRelatedUnits(methodBody);
            for (Unit unit : trapUnits) {
                if (unit.getJavaSourceStartLineNumber() == vulnerableNode.getPos()) {
                    return true;
                }
            }
        }

        if (type.equalsIgnoreCase(CATCH_CLAUSE)) {
            List<Unit> trapUnits = getTrapRelatedUnits(methodBody);
            for (Unit unit : trapUnits) {
                if (unit.getJavaSourceStartLineNumber() == vulnerableNode.getPos()) {
                    return true;
                }
            }
        }
        if (type.equalsIgnoreCase(THROW_STMT)) {
            if (methodUnit instanceof ThrowStmt) {
                return true;
            }
        }

        if (type.equalsIgnoreCase(SYNC_STMT)) {
            return methodUnit instanceof EnterMonitorStmt;
        }

        if (type.equalsIgnoreCase(CLASS_INSTC_CREAT)) {
            if (methodUnit instanceof AssignStmt) {
                AssignStmt assignStmt = (AssignStmt) methodUnit;
                Value value = assignStmt.getRightOp();

                if (value.toString().contains("new") && value.toString().contains(".")) {
                    String[] objectNames = value.toString().split("\\.");

                    String objectName = objectNames[objectNames.length - 1];
                    List<String> childLabels = new ArrayList<>();
                    for (ITree child : vulnerableNode.getChildren()) {
                        if (child.hasLabel()) {
                            childLabels.add(child.getLabel().trim());
                        }
                    }

                    return childLabels.contains(objectName);

                }
            }
        }

        if (type.equalsIgnoreCase(QUALIFIED_NAMED)) {
            if (methodUnit instanceof AssignStmt) {
                AssignStmt assignStmt = (AssignStmt) methodUnit;
                Value rightOp = assignStmt.getRightOp();
                String name = "";
                if (rightOp instanceof FieldRef) {
                    FieldRef rightOpFieldRef = (FieldRef) rightOp;
                    name = rightOpFieldRef.getFieldRef().name();

                }
                return variable.contains(name.trim());


            }
        }

        if (type.equalsIgnoreCase(STRING_LITERAL) || type.equals(SIMPLE_NAME)) {
            if (methodUnit instanceof AssignStmt) {
                AssignStmt assignStmt = (AssignStmt) methodUnit;
                if (assignStmt.getRightOp() instanceof InvokeExpr) {
                    InvokeExpr invokeExpr = (InvokeExpr) assignStmt.getRightOp();
                    List<Value> args = invokeExpr.getArgs();
                    for (Value arg : args) {
                        if (arg.toString().equals(variable)) {
                            return true;
                        }
                    }

                }
            }
        }

        return false;
    }

    public static List<Unit> getTrapRelatedUnits(Body methodBody) {
        List<Unit> trapUnits = new ArrayList<>();
        Chain<Trap> trapChain = methodBody.getTraps();
        for (Trap trap : trapChain) {
            List<UnitBox> unitBoxes = trap.getUnitBoxes();
            for (UnitBox unitBox : unitBoxes) {
                Unit unit = unitBox.getUnit();
                trapUnits.add(unit);

            }
        }
        return trapUnits;

    }

    public static boolean nameInChildren(String name, ITree node) {
        for (ITree child : node.getChildren()) {
            if (child.hasLabel()) {
                String label = child.getLabel();
                if (label.trim().equalsIgnoreCase(name.trim())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * this method checks if a soot field has the same name as a gumtree field
     *
     * @param name
     * @param node
     * @param treeContext
     * @return
     */
    public static boolean nameInChildrenField(String name, ITree node, TreeContext treeContext) {
        List<String> fieldDeclarationNames = getFieldDeclarationInfo(node, treeContext);
        return fieldDeclarationNames.contains(name);
    }

    public static List<String> getFieldDeclarationInfo(ITree fieldDeclaration,
                                                       TreeContext treeContext) {

        List<ITree> children = fieldDeclaration.getChildren();
        int index = 0;

        ITree child = children.get(index);

        while (treeContext.getTypeLabel(child).equals(MOD) ||
                treeContext.getTypeLabel(child).equals(JAVA_DOC) ||
                treeContext.getTypeLabel(child).equalsIgnoreCase(MARKER_ANNOT)) {
            index++;
            if (index < children.size()) {
                child = children.get(index);
            } else {
                break;
            }
        }

        List<String> fieldDeclarationNames = new ArrayList<>();
        if (index + 1 < children.size()) {
            child = children.get(index + 1);
            String childType = treeContext.getTypeLabel(child);
            if (childType.equalsIgnoreCase(VAR_FRAG)) {
                List<ITree> grandChildren = child.getChildren();
                inner:
                for (ITree grandChild : grandChildren) {
                    if (treeContext.getTypeLabel(grandChild).equalsIgnoreCase(SIMPLE_NAME)) {
                        fieldDeclarationNames.add(grandChild.getLabel().trim());
                        break inner;
                    }
                }
            }
        }

        return fieldDeclarationNames;
    }

    public static int getMethodLastLine(Body methodBody) {
        int lastLine = methodBody.getUnits().getLast().getJavaSourceStartLineNumber();
        PatchingChain<Unit> units = methodBody.getUnits();
        List<Unit> copiedUnits = new ArrayList<>();
        List<Integer> lineNumbers = new ArrayList<>();
        for (Unit unit : units) {
            copiedUnits.add((Unit) unit.clone());
            int number = unit.getJavaSourceStartLineNumber();
            Tag lineNumberTag = unit.getTag("LineNumberTag");

            if (lineNumberTag != null) {
                number = new BigInteger(lineNumberTag.getValue()).intValue();
            }

            lineNumbers.add(number);

        }
//        int i = copiedUnits.size() - 2;
        for (int i = lineNumbers.size() - 1; i >= 0; i--) {
            int number = lineNumbers.get(i);
            if (number > lastLine) {
                lastLine = number;
            }
        }
//        while (lastLine == -1) {
//            if (i > -1) {
//                lastLine = copiedUnits.get(i--).getJavaSourceStartLineNumber();
//            } else {
//                break;
//            }
//        }
        return lastLine;

    }

    public static Unit getUnitFromMethod(SootMethod sootMethod, ITree vulnerableNode, TreeContext treeContext) {
        if (sootMethod != null) {
            SootClass sootClass = Scene.v().loadClassAndSupport(sootMethod.getDeclaringClass().toString());
            sootClass.setApplicationClass();
            SootMethod methodProcessed = ChangeUtil.getSootMethod(sootMethod, sootClass);
            Body body = methodProcessed.retrieveActiveBody();
            PatchingChain<Unit> units = body.getUnits();

            for (Unit unit : units) {
                int line = unit.getJavaSourceStartLineNumber();
                Tag lineNumberTag = unit.getTag("LineNumberTag");

                if (lineNumberTag != null) {
                    line = new BigInteger(lineNumberTag.getValue()).intValue();
                }
                if ((vulnerableNode.getPos() <= line + 3 &&
                        vulnerableNode.getPos() >= line - 3) || vulnerableNode.getPos() == line) {

                    if (isITreeUnit(vulnerableNode.getLabel(), unit, vulnerableNode, treeContext, body))
                        return unit;
                }
            }
        }
        return null;
    }

    public static Unit getParameter(SootMethod sootMethod, ITree vulnerableNode, TreeContext treeContext) {
        if (sootMethod != null) {
            SootClass sootClass = Scene.v().loadClassAndSupport(sootMethod.getDeclaringClass().toString());
            sootClass.setApplicationClass();
            SootMethod methodProcessed = ChangeUtil.getSootMethod(sootMethod, sootClass);
            Body body = methodProcessed.retrieveActiveBody();
            PatchingChain<Unit> units = body.getUnits();

            List<ITree> children = vulnerableNode.getChildren();
            String gtType = "";
            String gtName = "";
            for (ITree child : children) {
                String typeLabel = treeContext.getTypeLabel(child);
                if (typeLabel.equalsIgnoreCase(SIMPLE_TYPE) || typeLabel.equalsIgnoreCase(PRIM_TYPE)) {
                    gtType = child.getLabel().trim();
                }

                if (typeLabel.equalsIgnoreCase(SIMPLE_NAME)) {
                    gtName = child.getLabel().trim();
                }

            }

            for (Unit unit : units) {
                if (unit instanceof IdentityStmt) {
                    IdentityStmt identityStmt = (IdentityStmt) unit;

                    Value rightOp = identityStmt.getRightOp();
                    boolean typeMatch = false;
                    if (rightOp instanceof ParameterRef) {
                        String[] typeSplit = rightOp.getType().toString().split("\\.");
                        String type = typeSplit[typeSplit.length - 1].trim();
                        typeMatch = type.equalsIgnoreCase(gtType);

                    }

                    if (typeMatch) {
                        Value leftOp = identityStmt.getLeftOp();
                        if (leftOp instanceof JimpleLocal) {
                            JimpleLocal local = (JimpleLocal) leftOp;
                            String name = local.getName();
                            if (name.equalsIgnoreCase(gtName)) {
                                return unit;
                            }
                        }
                    }


                }


            }
        }
        return null;
    }

    public static String getUnitName(Unit unit, String variableName) {
        List<ValueBox> values = unit.getUseAndDefBoxes();
        String name = " ";
        for (ValueBox value : values) {
            name = value.getValue().toString();
            if (unit instanceof AssignStmt) {
                AssignStmt unitAssign = (AssignStmt) unit;
                Value leftOp = unitAssign.getLeftOp();

                Value rightOp = unitAssign.getRightOp();
                name = leftOp.toString();
                if(leftOp instanceof JInstanceFieldRef){
                    JInstanceFieldRef leftOpFieldRef = (JInstanceFieldRef) leftOp;
                    name = leftOpFieldRef.getFieldRef().name();

                }

                if(rightOp instanceof JInstanceFieldRef){
                    JInstanceFieldRef rightOpFieldRef = (JInstanceFieldRef) rightOp;
                    name = rightOpFieldRef.getFieldRef().name();

                }

                if(rightOp instanceof StaticFieldRef){
                    StaticFieldRef rightOpStaticField = (StaticFieldRef) rightOp;
                   name = rightOpStaticField.getFieldRef().name();

                }

            }

            if(unit instanceof IfStmt){
                IfStmt unitIfStmt = (IfStmt) unit;
                Value conditionExpr = unitIfStmt.getCondition();

                if(conditionExpr instanceof JimpleLocal){
                    JimpleLocal jlocal = (JimpleLocal) conditionExpr;
                    if(jlocal.getName().contains(variableName)){
                        name = jlocal.getName();
                    }
                }

                Stmt targetBox = unitIfStmt.getTarget();
                //this needs to be fixed cause it's repeatedly being called
                if(targetBox instanceof AssignStmt){
                    AssignStmt targetBoxAssign = (AssignStmt) targetBox;
                    Value leftOp = targetBoxAssign.getLeftOp();
                    if(leftOp.toString().contains(variableName)){
                        name = leftOp.toString();
                    }
                }


            }
            if(unit instanceof IdentityStmt){
                IdentityStmt unitIdStmt = (IdentityStmt) unit;
                Value unitValue = unitIdStmt.getLeftOp();
                name = unitValue.toString();
            }
            if (name.contains(variableName)) {
                if (name.contains("$")) {
                    name = name.replace("$", "");
                }
                if (name.contains("#")) {
                    name = name.substring(0, name.indexOf("#"));
                }

            }
        }

        return name;
    }

    public static String getSpecificTypes(Unit unit){
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JAssignStmt")) {
            AssignStmt unitAssign = (AssignStmt) unit;
            Type type = unitAssign.getLeftOp().getType();
            return stringifyType(type);
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JReturnStmt")) {
            ReturnStmt unitReturn = (ReturnStmt) unit;
            Type type = unitReturn.getOp().getType();
            return stringifyType(type);
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JIdentityStmt")) {
            IdentityStmt unitIdentity = (IdentityStmt) unit;
            Type type = unitIdentity.getLeftOp().getType();
            return type.toString();
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JTableSwitchStmt")) {
            TableSwitchStmt tableSwitchStmt = (TableSwitchStmt) unit;
            Type type = tableSwitchStmt.getKey().getType();
            //for switch statements we consider the type of the key as the specifc class
            return stringifyType(type);
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JLookupSwitchStmt")) {
            LookupSwitchStmt lookupSwitchStmt = (LookupSwitchStmt) unit;
            Type type = lookupSwitchStmt.getKey().getType();
            return stringifyType(type);
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JGotoStmt")) {
            GotoStmt gotoStmt = (GotoStmt) unit;
            Unit goToUnit = gotoStmt.getTarget();
            return getSpecificTypes(goToUnit);
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JIfStmt")) {
            IfStmt ifStmt = (IfStmt) unit;
            Type type = ifStmt.getCondition().getType();
            return stringifyType(type);
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JInvokeStmt")) {
            InvokeStmt invokeStmt = (InvokeStmt) unit;
            Type type = invokeStmt.getInvokeExprBox().getValue().getType();
            return stringifyType(type);
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JReturnVoidStmt")) {
            return "void";
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JThrowStmt")) {
            ThrowStmt throwStmt = (ThrowStmt) unit;
            Type type = throwStmt.getOp().getType();
            return stringifyType(type);
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JExitMonitorStmt")) {
            ExitMonitorStmt exitMonitorStmt = (ExitMonitorStmt) unit;
            Type type = exitMonitorStmt.getOp().getType();
            return stringifyType(type);
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JEnterMonitorStmt")) {
            EnterMonitorStmt enterMonitorStmt = (EnterMonitorStmt) unit;
            Type type = enterMonitorStmt.getOp().getType();
            return type.toString();
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JNopStmt")) {
            return "NA";
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JBreakpointStmt")) {

            return "NA";
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JRetStmt")) {
            RetStmt retStmt = (RetStmt) unit;
            Type type = retStmt.getStmtAddress().getType();
            return stringifyType(type);
        }


        return null;
    }

    public static String stringifyType(Type type) {
        String typeString = type.toString();
        if (Scene.v().containsClass(typeString)) {
            SootClass sc = Scene.v().loadClassAndSupport(type.toString());
            if (sc.isApplicationClass()) {
                return "application class";
            } else if (sc.isJavaLibraryClass()) {
                return type.toString();
            } else if (sc.isLibraryClass()) {
                return "library class";
            }
        }
        return type.toString();
    }

    public static String getTypesSecondFormat(Unit unit) {
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JAssignStmt")) {
            AssignStmt unitAssign = (AssignStmt) unit;
            Type unitType = unitAssign.getLeftOp().getType();
            return unitType.toString();
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JReturnStmt")) {
            ReturnStmt unitReturn = (ReturnStmt) unit;
            Type type = unitReturn.getOp().getType();

            return type.toString();
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JIdentityStmt")) {
            IdentityStmt unitIdentity = (IdentityStmt) unit;
            Type type = unitIdentity.getLeftOp().getType();
            return type.toString();
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JTableSwitchStmt")) {
            TableSwitchStmt tableSwitchStmt = (TableSwitchStmt) unit;
            Type type = tableSwitchStmt.getKey().getType();
            //for switch statements we consider the type of the key as the specifc class
            return type.toString();
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JLookupSwitchStmt")) {
            LookupSwitchStmt lookupSwitchStmt = (LookupSwitchStmt) unit;
            Type type = lookupSwitchStmt.getKey().getType();
            return type.toString();
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JGotoStmt")) {
            GotoStmt gotoStmt = (GotoStmt) unit;
            Unit goToUnit = gotoStmt.getTarget();
            return getTypesSecondFormat(goToUnit);
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JIfStmt")) {
            IfStmt ifStmt = (IfStmt) unit;
            Type type = ifStmt.getCondition().getType();
            return type.toString();
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JInvokeStmt")) {
            InvokeStmt invokeStmt = (InvokeStmt) unit;
            Type type = invokeStmt.getInvokeExprBox().getValue().getType();
            return type.toString();
        }

        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JThrowStmt")) {
            ThrowStmt throwStmt = (ThrowStmt) unit;
            Type type = throwStmt.getOp().getType();
            return type.toString();
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JExitMonitorStmt")) {
            ExitMonitorStmt exitMonitorStmt = (ExitMonitorStmt) unit;
            Type type = exitMonitorStmt.getOp().getType();
            return type.toString();
        }
        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JEnterMonitorStmt")) {
            EnterMonitorStmt enterMonitorStmt = (EnterMonitorStmt) unit;
            Type type = enterMonitorStmt.getOp().getType();
            return type.toString();
        }

        if (unit.getClass().toString().equalsIgnoreCase("class soot.jimple.internal.JRetStmt")) {
            RetStmt retStmt = (RetStmt) unit;
            Type type = retStmt.getStmtAddress().getType();
            return type.toString();
        }


        return null;
    }

    public static ITree getMappedMethod(ITree methodDeclaration, MappingStore mappingStore) {
        if (mappingStore.hasDst(methodDeclaration)) {
            return mappingStore.getSrc(methodDeclaration);
        }
        if (mappingStore.hasSrc(methodDeclaration)) {
            return mappingStore.getDst(methodDeclaration);
        }
        return null;
    }

    /**
     * this method is used to find the match between two units, using the mapping found from the AST diff
     *
     * @param mappingStore
     * @param unit
     * @return
     */
    public static Pair<SootMethod, Unit> getMappedUnit(String firstVersionClasspath, String secondVersionClasspath,
                                                       String className, MappingStore mappingStore, Unit unit, TreeContext dstTreeContext,
                                                       TreeContext srcTreeContext, SootMethod sootMethod, String CVEName) {
        Iterator<Mapping> mappingIterator = mappingStore.iterator();

        String reflectionFilePath = "reflection/tomcat/" + CVEName.trim() + "/" + "fixedVersion/refl.log";
        File reflectionFile = new File(reflectionFilePath);
        G.reset();
        boolean reflectionFileExists = reflectionFile.exists() && reflectionFile.isFile();
        if (reflectionFileExists) {
            setUpSootEnvironment(secondVersionClasspath, reflectionFilePath);
        } else {
            setUpSootEnvironment(secondVersionClasspath);
        }
        while (mappingIterator.hasNext()) {
            Mapping mapping = mappingIterator.next();
            ITree dst = mapping.getSecond();
            if (dst.getId() <= unit.getJavaSourceStartLineNumber() - 3 || dst.getId() >= unit.getJavaSourceStartLineNumber() + 3 || dst.getId() == unit.getJavaSourceStartLineNumber()) {
                boolean findMatch = isITreeUnit(dst.getLabel(), unit, dst, dstTreeContext, sootMethod.retrieveActiveBody());
                if (findMatch) {
                    G.reset();
                    ITree src = mapping.getFirst();

                    reflectionFilePath = "reflection/tomcat/" + CVEName.trim() + "/" + "vulnVersion/refl.log";
                    reflectionFile = new File(reflectionFilePath);
                    reflectionFileExists = reflectionFileExists && reflectionFile.isFile();
                    if (reflectionFileExists) {
                        setUpSootEnvironment(firstVersionClasspath, reflectionFilePath);
                    } else {
                        setUpSootEnvironment(firstVersionClasspath);
                    }
                    return getUnit(className, src, srcTreeContext);
                }
            }


        }
        return new Pair<>(null, null);
    }

    public static String getCVEName(String filePath) {
        String CVEName = " ";
        Matcher matcher = Pattern.compile("(CVE-\\d{4}-\\d{4,5}_*\\d*\\d*)").matcher(filePath);

        while (matcher.find()) {
            CVEName = matcher.group(1).trim();
        }

        return CVEName;
    }



    public static boolean compareTypes(String iTreeType, Unit unitType, SootMethod sootMethod) {
        //TODO refactor this and the one in getUnitMethod into one
        List<Stmt> loopStmts = new ArrayList<>();
        LoopFinder loopFinder = new LoopFinder();
        loopFinder.transform(sootMethod.retrieveActiveBody());
        Collection<Loop> loops = loopFinder.loops();

        Iterator<Loop> loopIterator = loops.iterator();

        while (loopIterator.hasNext()) {
            Loop loop = loopIterator.next();
            Stmt loopStmt = loop.getHead();
            if (!loopStmts.contains(loopStmt)) {
                loopStmts.add(loopStmt);
            }
        }
        Stmt unitStmt = null;
        if (unitType instanceof Stmt) {
            unitStmt = (Stmt) unitType;
        }

        if (iTreeType.contains(MET_INV) && unitType instanceof InvokeStmt) {
            return true;
        } else if ((iTreeType.contains(FIELD_DECL) || iTreeType.contains(VAR_DECL) || iTreeType.contains(VAR_FRAG))
                && (unitType instanceof AssignStmt || unitType instanceof IdentityStmt)) {
            return true;
        } else if (iTreeType.contains(IF_COND) && unitType instanceof IfStmt) {
            return true;
        } else if (unitStmt != null) {
            return (iTreeType.contains(WHILE_STMT) || iTreeType.contains(FOR_STMT) && loopStmts.contains(unitStmt));
        }

        return false;
    }


    public static int findFileNo(String[] files, String className) {
        //the inner classes are written after the $ sign, so we need to make sure we are getting the right class
        className = className.split("\\$")[0];
        for (int i = 0; i < files.length; i++) {
            String file = files[i];
            if (file.contains(className)) {
                return i;
            }
        }
        return -1;
    }

    public static String getClassNameFromSoot(SootMethod sootMethod) {
        return sootMethod.getDeclaringClass().toString().replace('.', '/');

    }

    public static String getMethodNameFromFullName(String fullMethodName) {
        String result = "";
        Matcher matcher = Pattern.compile("(\\s<*\\w*>*\\()").matcher(fullMethodName);
        while (matcher.find()) {
            result = matcher.group(0).trim();
            if (result.endsWith("(")) {
                result = result.replace("(", "").trim();
            }
        }
        return result;
    }

    public static String stringifyUnit(Unit unit, String className) {
        return className.trim() + unit.getJavaSourceStartLineNumber() + ": " + unit.toString();
    }

    public static String stringifyUnit(Unit unit) {
        return unit.getJavaSourceStartLineNumber() + ": " + unit.toString();
    }

    public static List<Unit> getUnitsInTheSameLine(PatchingChain<Unit> units, int line) {
        List<Unit> sameLineUnits = new ArrayList<>();
        for (Unit unit : units) {
            int unitLine = getUnitLineNumber(unit);
            if (unitLine == line) {
                if (!sameLineUnits.contains(unit)) {
                    sameLineUnits.add(unit);
                }
            }
        }
        return sameLineUnits;
    }

    private static int getUnitLineNumber(Unit unit) {
        int line = unit.getJavaSourceStartLineNumber();
        Tag lineNumberTag = unit.getTag("LineNumberTag");
        if (lineNumberTag != null) {
            line = new BigInteger(lineNumberTag.getValue()).intValue();
        }

        return line;
    }


}
