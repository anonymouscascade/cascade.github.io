package util;

import com.github.gumtreediff.gen.Generators;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.tree.ITree;
import com.github.gumtreediff.tree.TreeContext;
import fixdetector.NodeChanges;
import javafx.util.Pair;
import org.apache.commons.collections4.BidiMap;
import org.apache.commons.collections4.bidimap.DualLinkedHashBidiMap;
import proganalysis.DependencyTypes;
import proganalysis.InterProceduralPDG;
import proganalysis.ProgramDependenceGraph;
import soot.*;
import soot.jimple.AssignStmt;
import soot.jimple.InvokeExpr;
import soot.jimple.InvokeStmt;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Sources;
import soot.jimple.toolkits.callgraph.Targets;
import soot.tagkit.Tag;
import soot.toolkits.graph.HashMutableEdgeLabelledDirectedGraph;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.*;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static util.Constants.*;

public class ChangeUtil {
    public static final boolean DEBUG = true;

    BidiMap<ITree, Integer> idToNodeMap = new DualLinkedHashBidiMap<>();

    public BidiMap<ITree, Integer> getIdToNodeMap() {
        return idToNodeMap;
    }

    /**
     * this methods takes a list of node changes and builds a graph (parent -> child)
     * used when trying to see the origin changes in a method
     *
     * @param nodeChangesList
     * @return
     */
    public DirectedGraph buildChangesGraph(List<NodeChanges> nodeChangesList) {

        int i = 0;
        List<String> edges = new ArrayList<>();
        for (NodeChanges nodeChanges : nodeChangesList) {
            if (!nodeChanges.getActionType().equalsIgnoreCase("UPD")) {
                ITree childNode = nodeChanges.getAction().getNode();
                ITree parentNode = nodeChanges.getAction().getNode().getParent();
                int childId;
                if (!idToNodeMap.containsKey(childNode)) {
                    childId = i++;
                    idToNodeMap.put(childNode, childId);
                } else {
                    childId = idToNodeMap.get(childNode);
                }

                int parentId;
                if (!idToNodeMap.containsKey(parentNode)) {
                    parentId = i++;
                    idToNodeMap.put(parentNode, parentId);
                } else {
                    parentId = idToNodeMap.get(parentNode);
                }

                String edge = parentId + ":" + childId;
                if (!edges.contains(edge)) {
                    edges.add(edge);
                }
            }
        }
        DirectedGraph directedGraph = new DirectedGraph(idToNodeMap.size());
        for (String edge : edges) {
            String[] splitEdge = edge.split(":");
            int firstId = Integer.parseInt(splitEdge[0]);
            int secondId = Integer.parseInt(splitEdge[1]);
            directedGraph.addEdge(firstId, secondId);
        }

        return directedGraph;
    }

    /**
     * this method first obtains the connected components in an undirected graph, then builds a graph for each such connected component
     */
    public static List<DirectedGraph> buildGraphs(List<String> edges, int size, BidiMap<String, Integer> methodId, BidiMap<String, Integer> finalProcessedMethodId) {
        UndirectedGraph undirectedGraph = new UndirectedGraph(size);
        LinkedHashMap<Integer, LinkedList<Integer>> directedAdjacencyMatrix = new LinkedHashMap<>();
        List<DirectedGraph> directedGraphs = new ArrayList<>();

        for (String edge : edges) {
            int firstID = Integer.parseInt(edge.split(",")[0]);
            int secondID = Integer.parseInt(edge.split(",")[1]);

            undirectedGraph.addEdge(firstID, secondID);
            LinkedList<Integer> adjacencyList;
            if (directedAdjacencyMatrix.containsKey(secondID)) {
                adjacencyList = directedAdjacencyMatrix.get(secondID);
                if (!adjacencyList.contains(firstID)) {
                    adjacencyList.add(firstID);
                }
            } else {
                adjacencyList = new LinkedList<>();
                adjacencyList.add(firstID);
            }
            directedAdjacencyMatrix.put(secondID, adjacencyList);

        }
        undirectedGraph.connectedComponents();
        List<List<Integer>> connectedComponents = undirectedGraph.getConnectedComponents();
        for (List<Integer> connectedComponent : connectedComponents) {
            DirectedGraph directedGraph = new DirectedGraph(connectedComponent.size());
            int id = 0;
            for (int node : connectedComponent) {
                String nodeSignature = methodId.getKey(node);
                int nodeId;
                if (!finalProcessedMethodId.containsKey(nodeSignature)) {
                    nodeId = id++;
                    finalProcessedMethodId.put(nodeSignature, nodeId);
                } else {
                    nodeId = finalProcessedMethodId.get(nodeSignature);
                }
                if (directedAdjacencyMatrix.containsKey(node)) {
                    List<Integer> adjacencyList = directedAdjacencyMatrix.get(node);
                    for (int neighbor : adjacencyList) {
                        String neighborSignature = methodId.getKey(neighbor);
                        int neighborId;
                        if (!finalProcessedMethodId.containsKey(neighborSignature)) {
                            neighborId = id++;
                            finalProcessedMethodId.put(neighborSignature, neighborId);
                        } else {
                            neighborId = finalProcessedMethodId.get(neighborSignature);
                        }
                        directedGraph.addEdge(nodeId, neighborId);
                    }
                }
            }
            directedGraphs.add(directedGraph);

        }
        return directedGraphs;
    }

    /**
     * this method is used to build an undirected graph for changes, in order to be able to identify connected components
     * based on each connected component a directed graph is built in order to understand the origin nodes
     *
     * @param nodeChangesList
     * @return
     */
    public static int buildChangesFromUndirectedGraph(List<NodeChanges> nodeChangesList) {

        int i = 0;
        BidiMap<ITree, Integer> idToNodeMap2 = new DualLinkedHashBidiMap<>();
        List<String> edges = new ArrayList<>();
        LinkedHashMap<Integer, LinkedList<Integer>> directedAdjacencyMatrix = new LinkedHashMap<>();
        for (NodeChanges nodeChanges : nodeChangesList) {
            if (!nodeChanges.getActionType().equalsIgnoreCase("UPD")) {
                ITree childNode = nodeChanges.getAction().getNode();
                ITree parentNode = nodeChanges.getAction().getNode().getParent();
                int childId;
                if (!idToNodeMap2.containsKey(childNode)) {
                    childId = i++;
                    idToNodeMap2.put(childNode, childId);
                } else {
                    childId = idToNodeMap2.get(childNode);
                }

                int parentId;
                if (!idToNodeMap2.containsKey(parentNode)) {
                    parentId = i++;
                    idToNodeMap2.put(parentNode, parentId);
                } else {
                    parentId = idToNodeMap2.get(parentNode);
                }

                String edge = parentId + ":" + childId;
                if (!edges.contains(edge)) {
                    edges.add(edge);
                }
            }
        }
        UndirectedGraph undirectedGraph = new UndirectedGraph(idToNodeMap2.size());
        for (String edge : edges) {
            String[] splitEdge = edge.split(":");
            int firstId = Integer.parseInt(splitEdge[0]);
            int secondId = Integer.parseInt(splitEdge[1]);
            undirectedGraph.addEdge(firstId, secondId);
            LinkedList<Integer> adjacencyList;
            if (directedAdjacencyMatrix.containsKey(firstId)) {
                adjacencyList = directedAdjacencyMatrix.get(firstId);
                if (!adjacencyList.contains(secondId)) {
                    adjacencyList.add(secondId);
                }
            } else {
                adjacencyList = new LinkedList<>();
                adjacencyList.add(secondId);
            }
            directedAdjacencyMatrix.put(firstId, adjacencyList);

        }
        undirectedGraph.connectedComponents();
        List<List<Integer>> connectedComponents = undirectedGraph.getConnectedComponents();

        return connectedComponents.size();
    }

    /**
     * this is used for locus tomcat
     *
     * @param filePath
     * @return
     */
    public static String getRevisionNumberforTomcat(String filePath) {
        Matcher matcher = Pattern.compile("(\\d{5})").matcher(filePath);
        String revsionNo = "";
        while (matcher.find()) {
            revsionNo = matcher.group(0).trim();
        }
        return revsionNo;
    }

    public static int findFileNo(String[] files, SootMethod sootMethod) {
        String className = SootUtilities.getClassNameFromSoot(sootMethod);
        //the inner classes are written after the $ sign, so we need to make sure we are getting the right class
        className = className.split("\\$")[0];
        for (int i = 0; i < files.length; i++) {
            String file = files[i];
            if (file.contains(className)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * determines the correct fileno based on whether we are dealing with the prepatch (old) or postpatch (new) revision
     *
     * @param old
     * @param initial
     * @return
     */
    public static int determineFileNo(boolean old, int initial) {
        if (old) {
            if (initial % 2 != 0) {
                return initial - 1;
            }
        } else {
            if (initial % 2 == 0) {
                return initial + 1;
            }
        }
        return initial;
    }

    public static int determineFileNo(boolean old, String[] files, SootMethod sootMethod) {
        int initial = findFileNo(files, sootMethod);

        return determineFileNo(old, initial);
    }

    /**
     * check list overlap
     * @param sootMethodList1
     * @param gumTreeMethods1
     * @param sootMethodList2
     * @param gumTreeMethods2
     * @param files
     * @param mappingStores
     * @return
     */
    public static BidiMap<SootMethod, SootMethod> checkOverlap(List<SootMethod> sootMethodList1,
                                                               List<ITree> gumTreeMethods1,
                                                               List<SootMethod> sootMethodList2,
                                                               List<ITree> gumTreeMethods2,
                                                               String[] files,
                                                               List<MappingStore> mappingStores) {
        BidiMap<SootMethod, SootMethod> methodsMap = new DualLinkedHashBidiMap<>();
        outter:
        for (int i = 0; i < sootMethodList1.size(); i++) {
            SootMethod sootMethod1 = sootMethodList1.get(i);
            String className1 = sootMethod1.getDeclaringClass().getName();
            String name1 = SootUtilities.getMethodNameFromFullName(sootMethod1.getSignature());
            ITree gumTreeMethod1 = gumTreeMethods1.get(i);
            for (int j = 0; j < sootMethodList2.size(); j++) {
                SootMethod sootMethod2 = sootMethodList2.get(j);
                String name2 = SootUtilities.getMethodNameFromFullName(sootMethod2.getSignature());
                String className2 = sootMethod2.getDeclaringClass().getName();
                ITree gumTreeMethod2 = gumTreeMethods2.get(j);
                if (name1.equals(name2) && className1.equals(className2)) {
                    String className = className1.replace('.', '/');
                    int fileNo = SootUtilities.findFileNo(files, className);
                    MappingStore mappingStore = mappingStores.get(fileNo / 2);
                    if (mappingStore.has(gumTreeMethod1, gumTreeMethod2) || mappingStore.has(gumTreeMethod2, gumTreeMethod1) || sootMethod1.getSignature().equalsIgnoreCase(sootMethod2.getSignature())) {
                        methodsMap.put(sootMethod1, sootMethod2);
                        continue outter;

                    }
                }
            }
        }
        return methodsMap;
    }


    /**
     * this method is used to filter a mapped list (originalGum) when the mappee is changed from original soot to filtered soot
     * @param originalSoot
     * @param filteredSoot
     * @param originalGum
     * @return
     */
    public static List<ITree> filterList(List<SootMethod> originalSoot, List<SootMethod> filteredSoot, List<ITree> originalGum) {
        List<ITree> filteredGum = new ArrayList<>();
        for (SootMethod sootMethod : filteredSoot) {
            int index = originalSoot.indexOf(sootMethod);
            ITree gumTreeMethod = originalGum.get(index);
            filteredGum.add(gumTreeMethod);
        }
        return filteredGum;
    }

    public static List<SootMethod> removeListFromList(List<SootMethod> minuend, List<String> subtrahend){
        List<SootMethod> results = new ArrayList<>();
        for (SootMethod sootMethod : minuend) {
            if (!subtrahend.contains(sootMethod.getSignature())) {
                results.add(sootMethod);
            }
        }

        return results;
    }

    /**
     * add edges when identifying the root method in API-based cc
     *
     * @param methodId
     * @param edges
     * @param id
     * @param methodSignature
     * @param sourceMethodSignature
     * @return
     */
    public static int getEdge(BidiMap<String, Integer> methodId, List<String> edges, int id, String methodSignature, String sourceMethodSignature) {
        int firstID;
        if (methodId.containsKey(sourceMethodSignature)) {
            firstID = methodId.get(sourceMethodSignature);
        } else {
            firstID = id++;
            methodId.put(sourceMethodSignature, firstID);
        }

        int secondID;
        if (methodId.containsKey(methodSignature)) {
            secondID = methodId.get(methodSignature);
        } else {
            secondID = id++;
            methodId.put(methodSignature, secondID);
        }

        String edge = firstID + "," + secondID;
        if (!edges.contains(edge)) {
            edges.add(edge);
        }
        return id;
    }


    /**
     * this is used for nonessential paper, ant only
     *
     * @param filePath
     * @return
     */
    public static String getRevisionNumber(String filePath) {
        Matcher matcher = Pattern.compile("(\\d{3,4})").matcher(filePath);
        String revsionNo = "";
        while (matcher.find()) {
            revsionNo = matcher.group(0).trim();
        }
        return revsionNo;
    }

    public static String getRevisionNumberForCC(String filePath) {
        String revisionNo = filePath.split("/")[6];
        return revisionNo;
    }

    public static String getRevisionNumberForCC2(String filePath) {
        String revisionNo = filePath.split("/")[7];
        return revisionNo;
    }


    public BidiMap<ITree, Integer> getITreesfromChanges(List<NodeChanges> nodeChangesList) {

        int i = 0;
        BidiMap<ITree, Integer> idToNodeMap2 = new DualLinkedHashBidiMap<>();
        List<String> edges = new ArrayList<>();
        for (NodeChanges nodeChanges : nodeChangesList) {
            //if (!nodeChanges.getActionType().equalsIgnoreCase("UPD")) {
            ITree childNode = nodeChanges.getAction().getNode();
            ITree parentNode = nodeChanges.getAction().getNode().getParent();
            int childId;
            if (!idToNodeMap2.containsKey(childNode)) {
                childId = i++;
                idToNodeMap2.put(childNode, childId);
            } else {
                childId = idToNodeMap2.get(childNode);
            }

            int parentId;
            if (!idToNodeMap2.containsKey(parentNode)) {
                parentId = i++;
                idToNodeMap2.put(parentNode, parentId);
            } else {
                parentId = idToNodeMap2.get(parentNode);
            }

            String edge = parentId + ":" + childId;
            if (!edges.contains(edge)) {
                edges.add(edge);
            }
            //}
        }

        return idToNodeMap2;
    }

    public static boolean areEdgeConnectedThroughDataFlowHelper(ProgramDependenceGraph programDependenceGraph, Set<Unit> units, Unit unit2) {

        for (Unit unit1 : units) {
            if (!areEdgesConnectedThroughDataFlow(programDependenceGraph, unit1, unit2)) {
                return false;
            }
        }

        return true;
    }


    /**
     * check if there is an edge of dataflow between any two soot units
     *
     * @return
     */
    public static boolean areEdgesConnectedThroughDataFlow(ProgramDependenceGraph programDependenceGraph, Unit unit1, Unit unit2) {
        List<Unit> backwardSlice = programDependenceGraph.backwardSlice(unit1);
        List<Unit> forwardSlice = programDependenceGraph.forwardSlice(unit1);
        HashMutableEdgeLabelledDirectedGraph pdg = programDependenceGraph.pdg;
        if (backwardSlice.contains(unit2)) {
            int index = backwardSlice.indexOf(unit2);
            Unit previousUnit = unit2;
            for (int i = index; i < backwardSlice.size(); i++) {
                Unit slicedUnit = backwardSlice.get(i);
                if (pdg.containsEdge(previousUnit, slicedUnit, DependencyTypes.DATA_DEPENDENCY)) {
                    previousUnit = slicedUnit;
                } else {
                    break;
                }

            }
            return true;
        }

        if (forwardSlice.contains(unit2)) {
            int index = forwardSlice.indexOf(unit2);
            Unit previousUnit = unit2;
            for (int i = index; i == 0; i--) {
                Unit slicedUnit = forwardSlice.get(i);
                if (pdg.containsEdge(slicedUnit, previousUnit, DependencyTypes.DATA_DEPENDENCY)) {
                    previousUnit = slicedUnit;
                } else {
                    return false;
                }

            }
            return true;
        }
        return false;
    }

    public static boolean areEdgesConnectedThroughBackwardDataFlow(ProgramDependenceGraph programDependenceGraph, Unit unit1, Unit unit2) {
        List<Unit> backwardSlice = programDependenceGraph.backwardSlice(unit1);
        HashMutableEdgeLabelledDirectedGraph pdg = programDependenceGraph.pdg;


        //            int index = backwardSlice.indexOf(unit2);
        //            List<Unit> subsetBackwardSlice = backwardSlice.subList(0, index + 1);
        //            return hasPath(subsetBackwardSlice, pdg, unit1, unit2);
        //            Unit previousUnit = unit2;
        //            for (int i = index - 1; i >= 0; i--) {
        //                Unit slicedUnit = backwardSlice.get(i);
        //                if (pdg.containsEdge(previousUnit, slicedUnit, DependencyTypes.DATA_DEPENDENCY)) {
        //                    previousUnit = slicedUnit;
        //                } else {
        //                    return false;
        //                }
        //
        //            }
        //            return true;
        return backwardSlice.contains(unit2);
    }

    static boolean hasPath(List<Unit> units, HashMutableEdgeLabelledDirectedGraph pdg, Unit casualty, Unit change) {
        HashMap<Unit, Integer> nodeToCode = getNodeToCodeMap(units);
        boolean[] visited = new boolean[units.size()];

        List<Unit> toVisit = new ArrayList<>();

        toVisit.add(casualty);
        for (int i = 0; i < toVisit.size(); i++) {

            Unit current = toVisit.get(i);
            int currentCode = nodeToCode.get(current);
            if (current.equals(change)) {
                return true;
            }
            if (!visited[currentCode]) {
                //Set<Unit> predsOf = filterInDataDependencies(pdg.getPredsOf(current), pdg, current);
                List<Unit> predsOf = pdg.getPredsOf(current);
                for (Unit pred : predsOf) {
                    if (nodeToCode.containsKey(pred)) {
                        if (current.equals(change)) {
                            return true;
                        }
                        toVisit.add(pred);
                    }
                }
                visited[currentCode] = true;

            }

        }

        return false;
    }

    static Set<Unit> filterInDataDependencies(List<Unit> preds, HashMutableEdgeLabelledDirectedGraph pdg, Unit unit) {
        Set<Unit> result = new HashSet<>();
        for (Unit pred : preds) {
            if (pdg.containsEdge(pred, unit, DependencyTypes.DATA_DEPENDENCY)) {
                result.add(pred);
            }
        }

        return result;
    }

    static HashMap<Unit, Integer> getNodeToCodeMap(Collection<Unit> units) {
        HashMap<Unit, Integer> result = new HashMap<>();

        int id = 0;
        for (Unit unit : units) {
            result.put(unit, id++);

        }

        return result;
    }


    public static UndirectedGraph buildUndirected(List<String> edges, int size) {
        UndirectedGraph undirectedGraph = new UndirectedGraph(size);
        for (String edge : edges) {
            String[] splitEdge = edge.split(",");
            int unit1 = Integer.parseInt(splitEdge[0]);
            int unit2 = Integer.parseInt(splitEdge[1]);

            undirectedGraph.addEdge(unit1, unit2);
        }
        return undirectedGraph;
    }

    public static int getClassVersion(ITree methodDeclaration, String file1, String file2) throws IOException {
        ITree treeContext1 = Generators.getInstance().getTree(file1).getRoot();
        Iterator<ITree> iTrees1 = treeContext1.breadthFirst().iterator();
        while (iTrees1.hasNext()) {
            ITree iTree = iTrees1.next();
            if (iTree.isIsomorphicTo(methodDeclaration)) {
                return 1;
            }
        }

        ITree treeContext2 = Generators.getInstance().getTree(file2).getRoot();
        Iterator<ITree> iTrees2 = treeContext2.breadthFirst().iterator();
        while (iTrees2.hasNext()) {
            ITree iTree = iTrees2.next();
            if (iTree.isIsomorphicTo(methodDeclaration)) {
                return 2;
            }
        }

        return -1;
    }

    /**
     * check which changed methods are reached by root changes
     *
     * @param mainChanges
     * @param changedSootMethods
     * @return
     */
    public static HashMap<SootMethod, List<String>> getMethodsReachedByRootChange(List<String> mainChanges, List<SootMethod> changedSootMethods,
                                                                                  Pair<DirectedGraph, BidiMap<String, Integer>> directedGraphBidiMapPair) {
        //need to add check that all the methods in between are ones whose API has changed as well
        //and who updated their call to the root change (e.g. the call was not inserted or deleted)

        HashMap<SootMethod, List<String>> reachableMethodsToNeighbor = new HashMap<>();
        BidiMap<String, Integer> fullMethodNameID = directedGraphBidiMapPair.getValue();

        DirectedGraph allChangedMethodsGraph = directedGraphBidiMapPair.getKey();
        DirectedGraph reverseGraph = reverseGraph(allChangedMethodsGraph);

        for (int i = 0; i < changedSootMethods.size(); i++) {

            SootMethod sootMethod = changedSootMethods.get(i);
            String signature = sootMethod.getSignature();
            if (fullMethodNameID.containsKey(signature) && !mainChanges.contains(signature)) {
                int methodKey = fullMethodNameID.get(signature);
                List<String> neighbors = new ArrayList<>();
                for (String mainChange : mainChanges) {
                    //need to add this because there are some root changes that are not reachable by any other node
                    //there is room for improvement
                    if (fullMethodNameID.containsKey(mainChange)) {
                        int mainChangeKey = fullMethodNameID.get(mainChange);
                        if (allChangedMethodsGraph.reaches(mainChangeKey, methodKey)) {

                            LinkedList<Integer> integers = reverseGraph.adjListArray[methodKey];
                            for (int neighbor : integers) {
                                if (allChangedMethodsGraph.reaches(mainChangeKey, neighbor)) {
                                    String neighborSignature = fullMethodNameID.getKey(neighbor);
                                    if (!neighbors.contains(neighborSignature)) {
                                        neighbors.add(neighborSignature);
                                    }
                                }
                            }

                        }
                    }
                }
                reachableMethodsToNeighbor.put(sootMethod, neighbors);
            }

        }
        return reachableMethodsToNeighbor;
    }

    public static void writeCasualtiesToFile(PrintWriter writer, Collection<SootMethod> finalCasualtyChangesOnly) {
        for (SootMethod sootMethod : finalCasualtyChangesOnly) {
            writer.write(sootMethod.getSignature() + ";");
        }
    }

    static DirectedGraph reverseGraph(DirectedGraph graph) {
        DirectedGraph reversedGraph = new DirectedGraph(graph.V);
        for (int i = 0; i < graph.V; i++) {
            LinkedList<Integer> neighbors = graph.adjListArray[i];
            for (int neighbor : neighbors) {
                reversedGraph.addEdge(neighbor, i);
            }
        }
        return reversedGraph;
    }

    /**
     * in this method we map casualty methods from the new version to the old one
     *
     * @param gumTreeMethods
     * @param sootMethods
     * @param files
     * @param mappingStores
     * @return
     * @throws IOException
     */
    public static List<SootMethod> getMappedSootMethod(List<ITree> gumTreeMethods, List<SootMethod> sootMethods,
                                                       String[] files, List<MappingStore> mappingStores) throws IOException {
        List<SootMethod> mappedMethods = new ArrayList<>();
        for (int i = 0; i < sootMethods.size(); i++) {
            SootMethod sootMethod = sootMethods.get(i);
            ITree gumTreeMethod = gumTreeMethods.get(i);

            String className = sootMethod.getDeclaringClass().toString().replace('.', '/');
            int fileNo = SootUtilities.findFileNo(files, className);
            MappingStore mappingStore = mappingStores.get(fileNo / 2);


            ITree mappedMethod = SootUtilities.getMappedMethod(gumTreeMethod, mappingStore);
            if (mappedMethod != null) {
                className = sootMethod.getDeclaringClass().toString();
                TreeContext treeContext = Generators.getInstance().getTree(files[fileNo]).deriveTree();
                SootMethod mappedSootMethod = SootUtilities.getSootMethod(mappedMethod, className, treeContext);
                if (mappedSootMethod != null) {
                    mappedMethods.add(mappedSootMethod);
                } else {
                    mappedMethods.add(sootMethod);
                }
            }

        }

        return mappedMethods;
    }

    public static Unit convertToUnit(SootMethod sootMethod, ITree iTree, TreeContext treeContext) {


        Unit unit = SootUtilities.getUnitFromMethod(sootMethod, iTree, treeContext);


        return unit;
    }

    public static Unit convertToParameterUnit(SootMethod sootMethod, ITree iTree, TreeContext treeContext) {


        Unit unit = SootUtilities.getParameter(sootMethod, iTree, treeContext);


        return unit;
    }

    /**
     * this method gets Edges between two methods through Soot's callgraph
     * @param sootMethods
     * @param methodId
     * @param callGraph
     * @param edges
     * @param id
     * @param sootMethod
     * @return
     */
    public int getEdges(List<SootMethod> sootMethods, BidiMap<String, Integer> methodId, CallGraph callGraph, List<String> edges, int id, SootMethod sootMethod) {
        Iterator<MethodOrMethodContext> sources = new Sources(callGraph.edgesInto(sootMethod));
        Iterator<MethodOrMethodContext> targets = new Targets(callGraph.edgesOutOf(sootMethod));
        String methodSignature = sootMethod.getSignature();

        while (sources.hasNext()) {
            SootMethod sourceMethod = sources.next().method();

            if (sootMethods.contains(sourceMethod)) {

                String sourceMethodSignature = sourceMethod.getSignature();


                id = getEdge(methodId, edges, id, methodSignature, sourceMethodSignature);
                if (DEBUG) {
                    logger.log(Level.INFO, sourceMethod.getSignature() + "->" + sootMethod.getSignature());
                }

            }
        }
        while (targets.hasNext()) {
            SootMethod targetMethod = targets.next().method();
            if (sootMethods.contains(targetMethod)) {
                if (DEBUG) {
                    logger.log(Level.INFO, sootMethod.getSignature() + "->" + targetMethod.getSignature());
                }
                String targetMethodSignature = targetMethod.getSignature();
                id = getEdge(methodId, edges, id, targetMethodSignature, methodSignature);
            }
        }
        return id;
    }

    public static int countPresences(boolean[] presences) {
        int count = 0;
        for (boolean presence : presences) {
            if (presence) {
                count++;
            }
        }

        return count;
    }

    /**
     * this method builds a partial callgraph only of methods that were found to be changed in a patch (not the APIs ones)
     *
     * @param changedMethods
     * @return
     */
    public Pair<DirectedGraph, BidiMap<String, Integer>> buildMethodGraph(List<SootMethod> changedMethods) throws IOException {
        BidiMap<String, Integer> methodId = new DualLinkedHashBidiMap<>();
        int id = 0;
        //CallGraph callGraph = Scene.v().getCallGraph();
        List<String> edges = new ArrayList<>();

        for (SootMethod sootMethod : changedMethods) {
            //if this doesn't work, there is also the method using the soot callgrapgh called getEdges (but in CVE-2011-1184 it seems not to work)
            id = getEdgesNoCallgraph(changedMethods, methodId, edges, id, sootMethod);
        }

        DirectedGraph directedGraph = new DirectedGraph(methodId.size());
        for (String edge : edges) {
            int first = Integer.parseInt(edge.split(",")[0]);
            int second = Integer.parseInt(edge.split(",")[1]);

            directedGraph.addEdge(second, first);
        }

        return new Pair<>(directedGraph, methodId);
    }


    public boolean checkAssignStmt(AssignStmt assignStmt, SootMethod sootMethod) {
        boolean same = false;
        if (assignStmt.getRightOp() instanceof InvokeExpr) {
            InvokeExpr invokeExpr = (InvokeExpr) assignStmt.getRightOp();
            SootMethod calledMethod = invokeExpr.getMethod();
            same = calledMethod.equals(sootMethod);
            //the first one should work but just in case!
            if (!same) {
                same = calledMethod.getSignature().equalsIgnoreCase(sootMethod.getSignature());
            }
        }
        return same;
    }

    public boolean checkInvokeStmt(InvokeStmt invokeStmt, SootMethod sootMethod) {
        SootMethod calledMethod = invokeStmt.getInvokeExpr().getMethod();

        boolean same = calledMethod.equals(sootMethod);
        //the first one should work but just in case!
        if (!same) {
            same = calledMethod.getSignature().equalsIgnoreCase(sootMethod.getSignature());
        }

        return same;
    }

    public static int getUnitLineNumber(Unit unit) {
        int line = unit.getJavaSourceStartLineNumber();
        Tag lineNumberTag = unit.getTag("LineNumberTag");
        if (lineNumberTag != null) {
            line = new BigInteger(lineNumberTag.getValue()).intValue();
        }

        return line;
    }


    public static List<Unit> convertToUnit(SootMethod sootMethod, List<ITree> iTrees, TreeContext treeContext) {
        List<Unit> results = new ArrayList<>();
//        SootClass sootClass = Scene.v().loadClassAndSupport(sootMethod.getDeclaringClass().toString());
//        sootClass.setApplicationClass();
//        SootMethod methodProcessed = ChangeUtil.getSootMethod(sootMethod, sootClass);

        HashMap<Integer, List<Unit>> lineToUnits = sortUnitsInLines(sootMethod);


        for (ITree iTree : iTrees) {
            int line = iTree.getPos();
            boolean matchFound = searchUnits(treeContext, sootMethod, lineToUnits, iTree, line, results);
            int n = 1;
            while (!matchFound && n < 4) {
                matchFound = searchUnits(treeContext, sootMethod, lineToUnits, iTree, line - n, results);

                n++;
            }
            n = 1;
            if (!matchFound) {
                while (!matchFound && n < 4) {
                    matchFound = searchUnits(treeContext, sootMethod, lineToUnits, iTree, line + n, results);

                    n++;
                }
            }


        }
        return results;
    }

    private static boolean searchUnits(TreeContext treeContext, SootMethod methodProcessed, HashMap<Integer, List<Unit>> lineToUnits, ITree iTree, int line, List<Unit> results) {
        boolean matchFound = false;
        if (lineToUnits.containsKey(line)) {
            List<Unit> units = lineToUnits.get(line);
            for (Unit unit : units) {
                boolean match = SootUtilities.isITreeUnit(iTree.getLabel(), unit, iTree, treeContext, methodProcessed.retrieveActiveBody());
                if (match) {
                    matchFound = true;
                    if (!results.contains(unit)) {
                        results.add(unit);
                    }
                    break;
                }
            }

        }

        return matchFound;
    }

    public static SootMethod getProcessedMethod(SootMethod sootMethod) {
        SootClass sootClass = Scene.v().loadClassAndSupport(sootMethod.getDeclaringClass().toString());
        sootClass.setApplicationClass();
        return getSootMethod(sootMethod, sootClass);
    }

    static HashMap<Integer, List<Unit>> sortUnitsInLines(SootMethod sootMethod) {

        Body body = sootMethod.retrieveActiveBody();
        PatchingChain<Unit> units = body.getUnits();

        HashMap<Integer, List<Unit>> results = new HashMap<>();

        int previous = sootMethod.getJavaSourceStartLineNumber();
        for (Unit unit : units) {
            int line = getUnitLineNumber(unit);

            //an approximation of the line
            if (line == -1) {
                line = previous;
            }

            if (results.containsKey(line)) {
                results.get(line).add(unit);
            } else {
                List<Unit> values = new ArrayList<>();
                values.add(unit);

                results.put(line, values);
            }

            previous = line;
        }

        return results;
    }


    /**
     * this method gets edges between two methods without using Soot's callgraph (used for methods that changed APIs when finding the root changes)
     *
     * @param sootMethodsMap
     * @param methodId
     * @param edges
     * @param id
     * @param sootMethod
     * @return
     */
    public int getEdgesNoCallgraph(HashMap<SootMethod, Set<Unit>> sootMethodsMap, BidiMap<String, Integer> methodId, List<String> edges, int id, SootMethod sootMethod) {
        Set<SootMethod> sootMethods = sootMethodsMap.keySet();

        for (SootMethod sootMethod1 : sootMethods) {
            Body body = sootMethod1.retrieveActiveBody();
            PatchingChain<Unit> units = body.getUnits();

            Set<Unit> changedArguments = sootMethodsMap.get(sootMethod1);
            InterProceduralPDG interProceduralPDG = new InterProceduralPDG();


            ProgramDependenceGraph intraProceduralPDG = null;
            for (Unit unit : units) {
                if (unit instanceof AssignStmt) {
                    AssignStmt assignStmt = (AssignStmt) unit;
                    boolean same = checkAssignStmt(assignStmt, sootMethod);


                    if (same) {

                        if (intraProceduralPDG == null) {
                            interProceduralPDG.run(sootMethod1.getDeclaringClass().getName(), sootMethod1);
                            intraProceduralPDG = interProceduralPDG.getInterProceduralPDG();
                        }

                        //we only add edges between two methods if we see that there is a data dependency between calls and added arguments
                        //TODO check here if calls are updated, not inserted or deleted
                        if (areEdgeConnectedThroughDataFlowHelper(intraProceduralPDG, changedArguments, unit)) {
                            //adding to the map here
                            id = getEdge(methodId, edges, id, sootMethod.getSignature(), sootMethod1.getSignature());

                            if (DEBUG) {
                                logger.log(Level.INFO, sootMethod1.getSignature() + "->" + sootMethod.getSignature());
                            }
                        }
                    }
                }
                if (unit instanceof InvokeStmt) {
                    InvokeStmt invokeStmt = (InvokeStmt) unit;

                    boolean same = checkInvokeStmt(invokeStmt, sootMethod);

                    if (same) {
                        if (intraProceduralPDG == null) {
                            interProceduralPDG.run(sootMethod1.getDeclaringClass().getName(), sootMethod1);
                            intraProceduralPDG = interProceduralPDG.getInterProceduralPDG();
                        }

                        if (areEdgeConnectedThroughDataFlowHelper(intraProceduralPDG, changedArguments, unit)) {
                            //adding to the map here
                            id = getEdge(methodId, edges, id, sootMethod.getSignature(), sootMethod1.getSignature());
                            if (DEBUG) {
                                logger.log(Level.INFO, sootMethod1.getSignature() + "->" + sootMethod.getSignature());
                            }
                        }
                    }


                }
            }
        }
        return id;
    }


    public static SootMethod getSootMethod(SootMethod sootMethod, SootClass sootClass) {
        SootMethod sootMethod1 = sootClass.getMethodUnsafe(sootMethod.getName(), sootMethod.getParameterTypes(), sootMethod.getReturnType());
        if (sootMethod1 == null) {
            sootMethod1 = sootClass.getMethodUnsafe(sootMethod.getNumberedSubSignature());
        }
        if (sootMethod1 == null) {
            sootMethod1 = sootClass.getMethod(sootMethod.getSubSignature());
        }
        return sootMethod1;
    }

    public static String getMethodDeclarationReturnType(ITree methodDeclaration, TreeContext treeContext) {
        if (!treeContext.getTypeLabel(methodDeclaration).equalsIgnoreCase(MET_DECL) && !treeContext.getTypeLabel(methodDeclaration).equals(COMPILATION_UNIT)) {

            System.err.println("not method declaration in getMethodDeclarationReturnType");
            System.exit(-1);
        }

        if (treeContext.getTypeLabel(methodDeclaration).equalsIgnoreCase(MET_DECL)) {
            return getRegularMethodDeclarationReturnType(methodDeclaration, treeContext);
        }

        if (treeContext.getTypeLabel(methodDeclaration).equalsIgnoreCase(COMPILATION_UNIT)) {
            return getConstructorMethodDeclarationReturnType(methodDeclaration, treeContext);
        }


        return "";
    }

    public static String getRegularMethodDeclarationReturnType(ITree methodDeclaration, TreeContext treeContext) {
        List<ITree> children = methodDeclaration.getChildren();
        //the return type is always either 0 or 1 (0 if there is no modifier)
        int index = 0;
        ITree child = children.get(index);
        while (treeContext.getTypeLabel(child).equals(MOD) || treeContext.getTypeLabel(child).equalsIgnoreCase(JAVA_DOC) || treeContext.getTypeLabel(child).equalsIgnoreCase(MARKER_ANNOT)) {
            index++;
            if (index < children.size()) {
                child = children.get(index);
            } else {
                break;
            }
        }

        if (index < children.size()) {
            return child.getLabel();
        }

        return "";
    }

    public static String getConstructorMethodDeclarationReturnType(ITree methodDeclaration, TreeContext treeContext) {
        List<ITree> children = methodDeclaration.getChildren();
        //the return type is always either 0 or 1 (0 if there is no modifier)
        int index = 0;
        ITree child = children.get(index);
        while (!treeContext.getTypeLabel(child).equals(TYPE_DECLA)) {
            index++;
            if (index < children.size()) {
                child = children.get(index);
            } else {
                break;
            }
        }

        if (index < children.size()) {
            return getRegularMethodDeclarationReturnType(methodDeclaration, treeContext);

        }

        return "";
    }

    public static Pair<Integer, Integer> getMethodBoundaries(ITree methodDeclaration) {
        int upperBoundary = methodDeclaration.getPos();
        int lowerBoundary = findLastChild(methodDeclaration);

        return new Pair<>(upperBoundary, lowerBoundary);
    }

    /**
     * we use this to set the soot classpasth only if the new needed classpath is not already in the classpath
     * @param classPath
     */
    public static void setSootEnvironment(String classPath) {
        if (!Scene.v().getSootClassPath().contains(classPath)) {
            G.reset();

            SootUtilities.setUpSootEnvironment(classPath);

        }
    }

    /**
     * this method is used to find the last child in a structural code element
     *
     * @param tree
     * @return
     */
    public static int findLastChild(ITree tree) {
        int line;
        List<ITree> children = tree.getChildren();
        ITree lastChild = children.get(children.size() - 1);
        while (!lastChild.isLeaf()) {
            children = lastChild.getChildren();
            lastChild = children.get(children.size() - 1);
        }
        line = lastChild.getPos();
        return line;
    }

    public static void checkDataDependencies(SootMethod sootMethod, List<Unit> casualtyInstances, List<Unit> allChanges, ProgramDependenceGraph intraProceduralPDG, boolean[] presenceInNew) {
        for (Unit unit : casualtyInstances) {
            int line = ChangeUtil.getUnitLineNumber(unit);
            for (int i = 0; i < allChanges.size(); i++) {
                if (!presenceInNew[i]) {
                    Unit newUnit = allChanges.get(i);
                    int newLine = ChangeUtil.getUnitLineNumber(newUnit);
                    if (line == newLine) {
                        presenceInNew[i] = true;
                    } else {
                        boolean dataflow = ChangeUtil.areEdgesConnectedThroughBackwardDataFlow(intraProceduralPDG, unit, newUnit);
                        if (dataflow) {
                            presenceInNew[i] = true;
                        }
                        //taking care of soot things
                        if (!dataflow) {
                            List<Unit> sameLineUnits = SootUtilities.getUnitsInTheSameLine(sootMethod.retrieveActiveBody().getUnits(), line);
                            inner:
                            for (Unit sameLineUnit : sameLineUnits) {
                                dataflow = ChangeUtil.areEdgesConnectedThroughBackwardDataFlow(intraProceduralPDG, sameLineUnit, newUnit);
                                if (dataflow) {
                                    presenceInNew[i] = true;
                                    break inner;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public static ProgramDependenceGraph constructPDGFromMethod(SootMethod sootMethod) {
        InterProceduralPDG interProceduralPDG = new InterProceduralPDG();

        interProceduralPDG.run(sootMethod.getDeclaringClass().toString(), sootMethod);

        ProgramDependenceGraph intraProceduralPDG = interProceduralPDG.getInterProceduralPDG();

        return intraProceduralPDG;
    }

    /**
     * build partial callgraph of methods that changed in a patch
     * (used in the general case, not for the API-based changes)
     *
     * @param sootMethods
     * @param methodId
     * @param edges
     * @param id
     * @param sootMethod
     * @return
     */
    public int getEdgesNoCallgraph(List<SootMethod> sootMethods, BidiMap<String, Integer> methodId, List<String> edges, int id,
                                   SootMethod sootMethod) {

        for (SootMethod sootMethod1 : sootMethods) {
            Body body = sootMethod1.retrieveActiveBody();
            PatchingChain<Unit> units = body.getUnits();


            for (Unit unit : units) {
                if (unit instanceof AssignStmt) {
                    AssignStmt assignStmt = (AssignStmt) unit;
                    boolean same = checkAssignStmt(assignStmt, sootMethod);


                    if (same) {


                        id = getEdge(methodId, edges, id, sootMethod.getSignature(), sootMethod1.getSignature());

                        if (DEBUG) {
                            logger.log(Level.INFO, sootMethod1.getSignature() + "->" + sootMethod.getSignature());
                        }

                    }
                }
                if (unit instanceof InvokeStmt) {
                    InvokeStmt invokeStmt = (InvokeStmt) unit;

                    boolean same = checkInvokeStmt(invokeStmt, sootMethod);

                    if (same) {

                        //adding to the map here
                        id = getEdge(methodId, edges, id, sootMethod.getSignature(), sootMethod1.getSignature());
                        if (DEBUG) {
                            logger.log(Level.INFO, sootMethod1.getSignature() + "->" + sootMethod.getSignature());
                        }

                    }


                }
            }
        }
        return id;
    }

    /**
     * method used to get the classname for gt purposes when you only have a sootmethod
     *
     * @param sootMethod
     */
    public static String getGumtreeClassnameFromSoot(SootMethod sootMethod) {
        //TODO: should this be replaceAll?
        return sootMethod.getDeclaringClass().toString().replaceAll("\\.", "/");

    }


}
