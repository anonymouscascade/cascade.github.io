package proganalysis;

import soot.*;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.options.Options;
import soot.util.Chain;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CallGraphConstructor {
    public static void main(String[] args) throws IOException {
        String sootClassPath = Scene.v().getSootClassPath()+ File.pathSeparator+ args[0];
        Scene.v().setSootClassPath(sootClassPath);
        Options.v().set_keep_line_number(true);
        Options.v().set_verbose(true);
        Options.v().setPhaseOption("jb", "use-original-names");
        Options.v().set_include_all(true);
        Options.v().set_whole_program(true);
        Options.v().set_whole_shimple(true);
        Options.v().set_polyglot(true);
        Options.v().set_allow_phantom_refs(true);


        Options.v().set_whole_shimple(true);
        Options.v().set_full_resolver(true);
        Options.v().set_permissive_resolving(true);

        //we set the cla
        List<String> process_dir = new ArrayList<>();
        String[] classPathArgs = args[0].split(":");
        process_dir.add(classPathArgs[classPathArgs.length-1]);
        Options.v().set_process_dir(process_dir);
        for (SootClass sootClass : Scene.v().getApplicationClasses()) {
            Scene.v().loadClassAndSupport(sootClass.getName());
        }
        Scene.v().loadNecessaryClasses();
        PhaseOptions.v().setPhaseOption("jb", "use-original-names");
        constructCallGraph();
    }

    public static CallGraph constructCallGraph() throws IOException {


        List<SootMethod> sootMethodsList = new ArrayList<>();
        Chain<SootClass> sootClassList = Scene.v().getApplicationClasses();
        for (SootClass sootClass : sootClassList) {

            if (!sootClass.isAbstract())
                sootMethodsList.addAll(sootClass.getMethods());
        }
        //we manually set the entry points as all the classes because it is difficult to know
        //what are entry points for large projects. this might be a bit inefficient, but it will be accurate
        Scene.v().setEntryPoints(sootMethodsList);

        //need to run this to generate the callgraph
        PackManager.v().runPacks();

        //SparkTransformer.v().transform();
        System.out.println("Spark Transformation finished. Call graph being generated...");
        CallGraph callGraph = Scene.v().getCallGraph();

        InterProceduralPDG interProceduralPDG = new InterProceduralPDG();
        interProceduralPDG.filterCallGraph(callGraph);


        return callGraph;
    }

    public static CallGraph constructCallGraph(String entryPoint) throws IOException {

        Scene.v().setMainClass(Scene.v().getSootClass(entryPoint));

        //need to run this to generate the callgraph
        PackManager.v().runPacks();

        //SparkTransformer.v().transform();
        System.out.println("Spark Transformation finished. Call graph being generated...");
        CallGraph callGraph = Scene.v().getCallGraph();

        InterProceduralPDG interProceduralPDG = new InterProceduralPDG();
        interProceduralPDG.filterCallGraph(callGraph);


        return callGraph;
    }




}
