package proganalysis;

public enum DependencyTypes {
    CONTROL_DEPENDENCY, DATA_DEPENDENCY, CALL, RETURN_CALL, SENTINEL
}
