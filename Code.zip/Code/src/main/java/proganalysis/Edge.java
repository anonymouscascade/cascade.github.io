package proganalysis;

import soot.Unit;
import util.SootUtilities;

import java.util.Collections;
import java.util.List;

public class Edge {
    Unit from;
    Unit to;
    String stringifyFrom;
    String stringifyTo;
    List<DependencyTypes> dependencyTypes;

    Edge(Unit from, Unit to, List<DependencyTypes> dependencyTypes) {
        this.from = from;
        this.to = to;
        this.dependencyTypes = dependencyTypes;

        if (from != null) {
            stringifyFrom = SootUtilities.stringifyUnit(this.from);
        } else {
            stringifyFrom = "null";
        }

        if (to != null) {
            stringifyTo = SootUtilities.stringifyUnit(this.to);
        } else {
            stringifyTo = "null";
        }
    }

    public Unit getFrom() {
        return from;
    }

    public void setFrom(Unit from) {
        this.from = from;
    }

    public Unit getTo() {
        return to;
    }

    public void setTo(Unit to) {
        this.to = to;
    }

    public String getStringifyFrom() {
        return stringifyFrom;
    }

    public void setStringifyFrom(String stringifyFrom) {
        this.stringifyFrom = stringifyFrom;
    }

    public String getStringifyTo() {
        return stringifyTo;
    }

    public void setStringifyTo(String stringifyTo) {
        this.stringifyTo = stringifyTo;
    }

    public List<DependencyTypes> getDependencyTypes() {
        return dependencyTypes;
    }

    public void setDependencyTypes(List<DependencyTypes> dependencyTypes) {
        this.dependencyTypes = dependencyTypes;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Edge) {
            Edge edge = (Edge) o;
            Collections.sort(edge.dependencyTypes);
            Collections.sort(this.dependencyTypes);

            String stringifyFromEdge = "null";
            if (edge.from != null) {
                stringifyFromEdge = SootUtilities.stringifyUnit(edge.from);
            }
            String stringifyToEdge = "null";
            if (edge.to != null) {
                stringifyToEdge = SootUtilities.stringifyUnit(edge.to);
            }
            return stringifyFromEdge.equalsIgnoreCase(this.stringifyFrom)
                    && stringifyToEdge.equalsIgnoreCase(this.stringifyTo)
                    && edge.dependencyTypes.equals(this.dependencyTypes);
        }
        return false;
    }
}
