package proganalysis;

import soot.*;
import soot.jimple.*;
import soot.jimple.internal.JInstanceFieldRef;
import soot.jimple.internal.JimpleLocal;
import soot.options.Options;
import soot.toolkits.graph.*;
import soot.toolkits.graph.pdg.HashMutablePDG;
import soot.toolkits.graph.pdg.MHGDominatorTree;
import soot.toolkits.graph.pdg.PDGNode;
import soot.toolkits.scalar.SimpleLocalDefs;
import soot.toolkits.scalar.SimpleLocalUses;
import soot.toolkits.scalar.UnitValueBoxPair;

import java.io.File;
import java.io.Serializable;
import java.util.*;

public class ProgramDependenceGraph implements Serializable {
    public HashMutableEdgeLabelledDirectedGraph pdg;
    public ExceptionalUnitGraph cfg;

    ProgramDependenceGraph(ExceptionalUnitGraph eug) {
        cfg = eug;
        constructPdg(eug);
//        directConstructPDG(eug);
    }

    public static ProgramDependenceGraph run(String className, SootMethod method) {
        SootClass sootClass = Scene.v().loadClassAndSupport(className);

        // Load any other necessary classes.
        Scene.v().loadNecessaryClasses();

        // Application classes and library classes distinguished in soot
        sootClass.setApplicationClass();

        //SootMethod sm = sootClass.getMethod(methodName);
        Body body = method.retrieveActiveBody();

        ExceptionalUnitGraph exceptionalUnitGraph = new ExceptionalUnitGraph(body);
//        EnhancedUnitGraph enhancedUnitGraph = new EnhancedUnitGraph(body);

        ProgramDependenceGraph programDependenceGraph = new ProgramDependenceGraph(exceptionalUnitGraph);

        return programDependenceGraph;
    }
    public static List<Integer> backwardSliceDriver(String[] args) {
        String sootClassPath = Scene.v().getSootClassPath() + File.pathSeparator + args[0];

        Scene.v().setSootClassPath(sootClassPath);
//not to strip away line numbers
        Options.v().set_keep_line_number(true);
        Options.v().set_verbose(true);
        Options.v().setPhaseOption("jb", "use-original-names");
        Options.v().set_include_all(true);
        Options.v().set_whole_program(true);
        Options.v().set_whole_shimple(true);
        String className = args[1];
        String methodName = args[2];
        Integer line = Integer.parseInt(args[3]);
        String variable = args[4];

        SootClass sc = Scene.v().loadClass(className, 3);


        Scene.v().loadNecessaryClasses();

//application classes and library classes distinguished in soot
        sc.setApplicationClass();

        SootMethod sm = sc.getMethodByName(methodName);
        Body b = sm.retrieveActiveBody();
        ExceptionalUnitGraph eug = new ExceptionalUnitGraph(b);

        ProgramDependenceGraph pdg = new ProgramDependenceGraph(eug);
        Set<Unit> backwardSlice = pdg.backwardSlice(line, variable);

        List<Integer> numsSlice = new ArrayList<>();
        for (Unit unit : backwardSlice) {
            if (!numsSlice.contains(unit.getJavaSourceStartLineNumber()) && unit.getJavaSourceStartLineNumber() != -1) {
                numsSlice.add(unit.getJavaSourceStartLineNumber());
            }
        }

        return numsSlice;

    }

    /**
     * This method adds a node to the PDG if the PDG does not contain it already
     *
     * @param pdg  - Program Dependence Graph
     * @param node - node to be added to the PDG
     */
    static void addNode(HashMutableEdgeLabelledDirectedGraph pdg, Unit node) {
        if (pdg.containsNode(node)) {
            return;
        }
        pdg.addNode(node);
    }

    static void addEdge(HashMutableEdgeLabelledDirectedGraph pdg, Unit fromNode, Unit toNode, DependencyTypes label) {
        if (pdg.containsEdge(fromNode, toNode, label)) {
            return;
        }
        addNode(pdg, fromNode);
        addNode(pdg, toNode);
        pdg.addEdge(fromNode, toNode, label);
    }

    public HashMutableEdgeLabelledDirectedGraph getPdg() {
        return pdg;
    }

    public void setPdg(HashMutableEdgeLabelledDirectedGraph pdg) {
        this.pdg = pdg;
    }

    /**
     * This method constructs the Program Dependence Graph (PDG) using Soot's API.
     * It first generates the Postdominance Tree from an Exceptional Unit Graph (Control Flow Graph (CFG) that takes into account exceptions in the flow of control).
     * The Postdominance Tree is generated because it's equivalent to generating the Dominance Tree in a reverse CFG.
     * This enables the calculation of Dominance Frontiers on a reverse CFG, which is equivalent to Control Dependence Tree.
     * Using SimpleLocalUses and SimpleLocalDefs from Soot, the data dependencies can be calculated, completing the PDG.
     *
     * @param eug - Exceptional Unit Graph, a CFG representation of a class generated from Soot
     */
    void constructPdg(ExceptionalUnitGraph eug) {
        Body body = eug.getBody();

        //soot's api for creating postdominator tree
        MHGDominatorTree<Unit> postdominatorTree = new MHGDominatorTree(new MHGPostDominatorsFinder(eug));

        //get dominance frontiers based on the postdominator tree, equivalent to using it
        DominanceFrontier<Unit> dominanceFrontier = new CytronDominanceFrontier<Unit>(postdominatorTree);
        pdg = new HashMutableEdgeLabelledDirectedGraph();
        SimpleLocalDefs definitions = new SimpleLocalDefs(eug);
        SimpleLocalUses uses = new SimpleLocalUses(body, definitions);


        for (Unit unit : body.getUnits()) {
            addNode(pdg, unit);

            for (DominatorNode<Unit> dode : dominanceFrontier.getDominanceFrontierOf(postdominatorTree.getDode(unit))) {
                Unit frontier = dode.getGode();
                addNode(pdg, frontier);

                if (pdg.containsEdge(frontier, unit, DependencyTypes.CONTROL_DEPENDENCY)) {
                    continue;
                }
                pdg.addEdge(frontier, unit, DependencyTypes.CONTROL_DEPENDENCY);

            }
            for (UnitValueBoxPair unitValueBoxPair : uses.getUsesOf(unit)) {
                Unit useNode = unitValueBoxPair.unit;
                addNode(pdg, useNode);
                if (pdg.containsEdge(unit, useNode, DependencyTypes.DATA_DEPENDENCY)) {
                    continue;
                }
                pdg.addEdge(unit, unitValueBoxPair.unit, DependencyTypes.DATA_DEPENDENCY);

            }
        }


    }

    void directConstructPDG(ExceptionalUnitGraph eug) {
        pdg = new HashMutablePDG(eug);
    }

    /**
     * this method provides a forward slice, given a variable name and a line number
     * A forward slice is dependent on successors in a PDG.
     *
     * @param line
     * @param variableName
     * @return
     */

    public Set<Unit> forwardSlice(int line, String variableName) {
        Set<Unit> slicer = new HashSet<Unit>();

        List<Unit> successors = new ArrayList<Unit>();

        //given a PDG, line number, and a variable Name
        //find the unit based on these two pieces of information,
        List<Unit> matches = getUnits(line, variableName);

        //get the successors and predecessors of that unit from the PDG in a set
        for (Unit unit : matches) {
            successors.add(unit);
            successors.addAll(pdg.getSuccsOf(unit));

        }
        //add to that set all the successors and predecessors of those units

        for (int i = 0; i < successors.size(); i++) {
            Unit unit = successors.get(i);
            slicer.add(unit);
            List<Unit> succs = pdg.getSuccsOf(unit);
            for (Unit succ : succs) {

                if (!successors.contains(succ)) {
                    successors.add(succ);
                }
            }
        }

        return slicer;

    }

    public List<Unit> forwardSlice(Unit unit) {
        List<Unit> slicer = new LinkedList<>();

        List<Unit> successors = new ArrayList<Unit>();


        //get the successors and predecessors of that unit from the PDG in a set

        successors.add(unit);
        successors.addAll(pdg.getSuccsOf(unit));


        //add to that set all the successors and predecessors of those units

        for (int i = 0; i < successors.size(); i++) {
            Unit successorUnit = successors.get(i);
            slicer.add(successorUnit);
            List<Unit> succs = pdg.getSuccsOf(successorUnit);
            for (Unit succ : succs) {

                if (!successors.contains(succ)) {
                    successors.add(succ);
                }
            }
        }

        return slicer;
    }

    /**
     * this method provides a backward slice, given a variable name and a line number
     * A backward slice is dependent on predecessors in the PDG
     *
     * @param line
     * @param variableName
     * @return
     */

    public Set<Unit> backwardSlice(int line, String variableName) {
        Set<Unit> slicer = new HashSet<Unit>();

        List<Unit> predecessors = new ArrayList<Unit>();

        //given a PDG, line number, and a variable Name
        //find the unit based on these two pieces of information,
        List<Unit> matches = getUnits(line, variableName);

        //get the successors and predecessors of that unit from the PDG in a set
        for (Unit unit : matches) {
            predecessors.add(unit);
            predecessors.addAll(pdg.getPredsOf(unit));


        }
        //add to that set all the successors and predecessors of those units
        for (int i = 0; i < predecessors.size(); i++) {

            Unit unit = predecessors.get(i);
            slicer.add(unit);
            List<Unit> preds = pdg.getPredsOf(unit);
            for (Unit pred : preds) {

                if (!predecessors.contains(pred)) {
                    predecessors.add(pred);
                }
            }
        }


        return slicer;
    }

    public List<Unit> backwardSlice(Unit unit) {
        List<Unit> slicer = new LinkedList<>();

        List<Unit> predecessors = new ArrayList<Unit>();

        //get the successors and predecessors of that unit from the PDG in a set
        predecessors.add(unit);
        predecessors.addAll(pdg.getPredsOf(unit));

        //add to that set all the successors and predecessors of those units
        for (int i = 0; i < predecessors.size(); i++) {

            Unit predesccorUnit = predecessors.get(i);
            slicer.add(predesccorUnit);
            List<Unit> preds = pdg.getPredsOf(predesccorUnit);
            for (Unit pred : preds) {

                if (!predecessors.contains(pred)) {
                    predecessors.add(pred);
                }
            }
        }


        return slicer;
    }

    public ExceptionalUnitGraph getCfg() {
        return cfg;
    }

    /**
     * This method helps in getting units for a given line
     *
     * @param line
     * @param variableName
     * @return
     */
    public List<Unit> getUnits(int line, String variableName) {
        List<Unit> matches = new ArrayList<>();
        Body body = getCfg().getBody();
        for (Unit unit : body.getUnits()) {
            if (line == unit.getJavaSourceStartLineNumber()) {
                List<ValueBox> values = unit.getUseAndDefBoxes();

                for (ValueBox value : values) {
                    String name = value.getValue().toString();
                    if (unit instanceof AssignStmt) {
                        AssignStmt unitAssign = (AssignStmt) unit;
                        Value leftOp = unitAssign.getLeftOp();

                        Value rightOp = unitAssign.getRightOp();
                        name = leftOp.toString();
                        if (leftOp instanceof JInstanceFieldRef) {
                            JInstanceFieldRef leftOpFieldRef = (JInstanceFieldRef) leftOp;
                            String fieldRefName = leftOpFieldRef.getFieldRef().name();
                            name = fieldRefName;
                        }

                        if (rightOp instanceof JInstanceFieldRef) {
                            JInstanceFieldRef rightOpFieldRef = (JInstanceFieldRef) rightOp;
                            String fieldRefName = rightOpFieldRef.getFieldRef().name();
                            name = fieldRefName;
                        }

                        if (rightOp instanceof StaticFieldRef) {
                            StaticFieldRef rightOpStaticField = (StaticFieldRef) rightOp;
                            String staticFieldName = rightOpStaticField.getFieldRef().name();
                            name = staticFieldName;
                        }

                    }

                    if (unit instanceof IfStmt) {
                        IfStmt unitIfStmt = (IfStmt) unit;
                        Value conditionExpr = unitIfStmt.getCondition();

                        if (conditionExpr instanceof JimpleLocal) {
                            JimpleLocal jlocal = (JimpleLocal) conditionExpr;
                            if (jlocal.getName().contains(variableName)) {

                                name = jlocal.getName();
                            }
                        }

                        Stmt targetBox = unitIfStmt.getTarget();
                        //this needs to be fixed cause it's repeatedly being called
                        if (targetBox instanceof AssignStmt) {
                            AssignStmt targetBoxAssign = (AssignStmt) targetBox;
                            Value leftOp = targetBoxAssign.getLeftOp();
                            if (leftOp.toString().contains(variableName)) {
                                name = leftOp.toString();
                            }
                        }


                    }
                    if (unit instanceof IdentityStmt) {
                        IdentityStmt unitIdStmt = (IdentityStmt) unit;
                        Value unitValue = unitIdStmt.getLeftOp();
                        name = unitValue.toString();
                    }
                    if (name.contains(variableName)) {
                        if (name.contains("$")) {
                            name = name.replace("$", "");
                        }
                        if (name.contains("#")) {
                            name = name.substring(0, name.indexOf("#"));
                        }
                        if (name.equals(variableName)) {
                            matches.add(unit);
                        }
                    }
                }
            }
        }
        return matches;
    }

    /**
     * this method prints the graph when it is constructed using our own API
     * returns a list of edges in the graph
     */
    public List<Edge> printGraph() {
        List<Edge> edgeList = new ArrayList<>();
        Iterator finalPdgiter = pdg.iterator();

        while (finalPdgiter.hasNext()) {
            Unit unit = (Unit) finalPdgiter.next();
//            System.out.println(unit.getJavaSourceStartLineNumber() + ": " + unit.toString());

            List<Unit> succs = pdg.getSuccsOf(unit);
            List<Unit> preds = pdg.getPredsOf(unit);

//            System.out.println("successors: ");
            for (Unit succ : succs) {
                if (pdg.containsAnyEdge(unit, succ)) {
                    List<DependencyTypes> labels = pdg.getLabelsForEdges(unit, succ);
//                    System.out.println(succ.getJavaSourceStartLineNumber() + ": " + succ.toString());

                    Edge edge = new Edge(unit, succ, labels);
                    if (!edgeList.contains(edge)) {
                        edgeList.add(edge);
                    }
                }
            }

//            System.out.println("preds: ");
            for (Unit pred : preds) {
                if (pdg.containsAnyEdge(pred, unit)) {
                    List<DependencyTypes> labels = pdg.getLabelsForEdges(pred, unit);
//                    System.out.println(pred.getJavaSourceStartLineNumber() + ": " + pred.toString());

                    Edge edge = new Edge(pred, unit, labels);
                    if (!edgeList.contains(edge)) {
                        edgeList.add(edge);
                    }
                }
            }
//            System.out.println("===================================");
            if (preds.isEmpty() && succs.isEmpty()) {
                List<DependencyTypes> labels = new ArrayList<>();
                labels.add(DependencyTypes.SENTINEL);
                Edge edge = new Edge(unit, null, labels);
                // we don't check if the list already contains such an edge because
                //all sentinel edges will look the same
                if (!edgeList.contains(edge)) {
                    edgeList.add(edge);
                }

            }


        }

//        System.out.println("Edges: ");
//        for (Edge edge : edgeList) {
//            Unit from = edge.from;
//            Unit to = edge.to;
//
//            List<DependencyTypes> labels = edge.dependencyTypes;
//            String stringFrom = "null";
//            int fromLineNo = -2;
//            if (from != null) {
//                stringFrom = from.toString();
//                fromLineNo = from.getJavaSourceStartLineNumber();
//            }
//
//            String stringTo = "null";
//            int toLineNo = -2;
//
//            if (to != null) {
//                stringTo = to.toString();
//                toLineNo = to.getJavaSourceStartLineNumber();
//            }
//
//
//            System.out.println("Edge from: " + stringFrom + " at " + fromLineNo + "\n" +
//                    "to: " + stringTo + " at " + toLineNo + "\n" +
//                    "with labels: " + Arrays.toString(labels.toArray()));
//            System.out.println("=====================================================");
//        }
        return edgeList;
    }

    /**
     * this method prints the graph when it is constructed using the soot API
     */
    public void printGraph2ndFormat() {
        Iterator finalPdgiter = pdg.iterator();

        while (finalPdgiter.hasNext()) {
            PDGNode unit = (PDGNode) finalPdgiter.next();

            List<PDGNode> succs = pdg.getSuccsOf(unit);
            List<PDGNode> preds = pdg.getPredsOf(unit);
            System.out.println("unit: " + unit);

            System.out.println("successors: ");
            for (PDGNode succ : succs) {
                System.out.println(succ + ": " + succ.toString());
                System.out.println(succ.getType());
                Unit succUnit = (Unit) succ.getNode();
                System.out.println(succUnit.getJavaSourceStartLineNumber() + ": " + succUnit.toString());

            }

            System.out.println("preds: ");
            for (PDGNode pred : preds) {
                System.out.println(pred);
                System.out.println(pred.getType());
                Unit predUnit = (Unit) pred.getNode();
                System.out.println(predUnit.getJavaSourceStartLineNumber() + ": " + predUnit.toString());
            }


            System.out.println("===================================");
        }


    }




}




