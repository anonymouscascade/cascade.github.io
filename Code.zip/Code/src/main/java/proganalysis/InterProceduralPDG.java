package proganalysis;

import soot.Body;
import soot.JastAddJ.ThrowStmt;
import soot.JastAddJ.*;
import soot.*;
import soot.jimple.IfStmt;
import soot.jimple.ReturnStmt;
import soot.jimple.SwitchStmt;
import soot.jimple.*;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Edge;
import soot.jimple.toolkits.callgraph.Sources;
import soot.jimple.toolkits.callgraph.Targets;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.HashMutableEdgeLabelledDirectedGraph;
import soot.util.Chain;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;


/**
 * This is the driver class for the Program Dependence Graph Creation
 */
public class InterProceduralPDG {

    ProgramDependenceGraph pdg;
    CallGraph callGraph;

    public static void main(String[] args) {
    }

    public ProgramDependenceGraph getInterProceduralPDG() {
        return this.pdg;
    }

    public void run(String className, SootMethod method, CallGraph callGraph) {


        // Load the class to be analyzed.
        SootClass sootClass = Scene.v().loadClassAndSupport(className);

        // Load any other necessary classes.
        Scene.v().loadNecessaryClasses();

        // Application classes and library classes distinguished in soot
        sootClass.setApplicationClass();
        this.callGraph = callGraph;

        //SootMethod sm = sootClass.getMethod(methodName);
        Body body = method.retrieveActiveBody();

        ExceptionalUnitGraph exceptionalUnitGraph = new ExceptionalUnitGraph(body);
        pdg = new ProgramDependenceGraph(exceptionalUnitGraph);


        Iterator<MethodOrMethodContext> sources = new Sources(callGraph.edgesInto(method));


        Iterator<MethodOrMethodContext> targets = new Targets(callGraph.edgesOutOf(method));


        List<SootMethod> sourceList = new ArrayList<>();
        //keep track of the methods calling another method
        List<SootMethod> sourceCalleeList = new ArrayList<>();

        List<SootMethod> targetList = new ArrayList<>();
        //keep track of the callee methods
        List<SootMethod> targetCallerList = new ArrayList<>();

        addtoLists(sources, sourceList);
        addtoLists(targets, targetList);

        for (int i = 0; i < sourceList.size(); i++) {
            sourceCalleeList.add(method);
        }

        for (int i = 0; i < targetList.size(); i++) {
            targetCallerList.add(method);
        }


        if (!sourceList.isEmpty() && !sourceCalleeList.isEmpty())
            mergeSourcesToIPDG(sourceList, sourceCalleeList);

        if (!targetCallerList.isEmpty() && !targetList.isEmpty())
            mergeTargetsToIPDG(targetList, targetCallerList);
        // G.reset();


    }

    /**
     * this is the intraprocedural version of the PDG
     *
     * @param className
     * @param method
     */
    public void run(String className, SootMethod method) {


        // Load the class to be analyzed.
        SootClass sootClass = Scene.v().loadClassAndSupport(className);

        // Load any other necessary classes.
        Scene.v().loadNecessaryClasses();

        // Application classes and library classes distinguished in soot
        sootClass.setApplicationClass();

        //SootMethod sm = sootClass.getMethod(methodName);
        Body body = method.retrieveActiveBody();

        ExceptionalUnitGraph exceptionalUnitGraph = new ExceptionalUnitGraph(body);
        pdg = new ProgramDependenceGraph(exceptionalUnitGraph);


    }

    /**
     * this function merges the methods that call the patch (and other methods that call them until the end of the graph) to the IPDG
     *
     * @param sourceList       the list of all sources
     * @param sourceCalleeList the list of methods called b y the sources(the first one is the patch)
     */

    void mergeSourcesToIPDG(List<SootMethod> sourceList, List<SootMethod> sourceCalleeList) {
        for (int i = 0; i < sourceList.size(); i++) {
            SootMethod smSource = sourceList.get(i);
            Iterator<MethodOrMethodContext> sourceSources = new Sources(callGraph.edgesInto(smSource));

            addtoLists(sourceSources, sourceList);
            for (int j = sourceCalleeList.size() - 1; j < sourceList.size(); j++) {
                sourceCalleeList.add(smSource);
            }

            //get the method that is called by smSource
            SootMethod callerMethod = sourceCalleeList.get(i);

            //get the units of the callee method
            Chain<Unit> smAllUnits = smSource.retrieveActiveBody().getUnits();
            for (Unit unit : smAllUnits) {
                try {
                    //find the unit that calls our method
//                    Iterator edgesIterator = callGraph.edgesOutOf(smSource.context(), smSource, unit);
//                    while(edgesIterator.hasNext()){
//                        ContextSensitiveEdge contextSensitiveEdge = (ContextSensitiveEdge) edgesIterator.next();
//                        if(contextSensitiveEdge.tgt().equals(callerMethod)){
//                            String type = getUnitType(unit);
//                            addToIPDG(callerMethod, unit, type);
//                        }
//                    }
                    if (callGraph.findEdge(unit, callerMethod) != null) {
                        String type = getUnitType(unit);

                        //create edges as needed between that unit and the method
                        addToIPDG(callerMethod, unit, type);

                    }
                } catch (NullPointerException noe) {
                }
            }

        }
    }

    /**
     * this function merges target calls from the patch to the Interprocedural PDG
     *
     * @param targetList       - the list of all targets from the patch (and all the targets of the initial targets until the end of the graph)
     * @param targetCallerList - the corresponding list of all methods that call those targets (the first one is the patch)
     */
    void mergeTargetsToIPDG(List<SootMethod> targetList, List<SootMethod> targetCallerList) {
        for (int i = 0; i < targetList.size(); i++) {
            SootMethod smSource = targetList.get(i);
            Iterator<MethodOrMethodContext> sourceSources = new Sources(callGraph.edgesOutOf(smSource));
            addtoLists(sourceSources, targetList);
            for (int j = targetCallerList.size() - 1; j < targetList.size(); j++) {
                targetCallerList.add(smSource);
            }

            SootMethod callerMethod = targetCallerList.get(i);


            Body callerMethodBody = callerMethod.retrieveActiveBody();

            //get the units of the caller
            Chain<Unit> callerUnits = callerMethodBody.getUnits();

            for (Unit unit : callerUnits) {

                try {
                    //find the unit that calls our method
//                        Iterator callerUnitsIterator = callGraph.edgesOutOf(callerMethod.context(), callerMethod, unit);
//                        while(callerUnitsIterator.hasNext()){
//                            ContextSensitiveEdge contextSensitiveEdge = (ContextSensitiveEdge) callerUnitsIterator;
//                            if(contextSensitiveEdge.tgt().equals(smSource)){
//                                String type = getUnitType(unit);
//                                addToIPDG(smSource, unit, type);
//                            }
//                        }

                    if (callGraph.findEdge(unit, smSource) != null) {
                        Unit concernedUnit = unit;

                        String type = getUnitType(unit);

                        //add an edge from the unit to our method
                        addToIPDG(smSource, concernedUnit, type);

                    }


                } catch (NullPointerException noe) {
                } finally {
                    continue;
                }

            }
        }
    }

    /**
     * method used to check if a method is a library method
     *
     * @return
     */
    boolean checkMethod(SootMethod sootMethod) {
        if (sootMethod.isJavaLibraryMethod()) {
            return false;
        }
        if (sootMethod.toString().startsWith("<sun")) {
            return false;
        }
        return !sootMethod.toString().startsWith("<jdk");

    }

    /**
     * @param calleeMethod the method that gets called
     * @param unit         the unit in the caller method from which the call is invoked
     * @param type         type of the unit which calls the calleeMethod
     */
    void addToIPDG(SootMethod calleeMethod, Unit unit, String type) {
        //build the PDG of the method
        Body body = calleeMethod.retrieveActiveBody();
        ExceptionalUnitGraph eug = new ExceptionalUnitGraph(body);
        HashMutableEdgeLabelledDirectedGraph calleeMethodPdg = new ProgramDependenceGraph(eug).getPdg();
        HashMutableEdgeLabelledDirectedGraph pdgGraph = pdg.getPdg();

        //add the first edge
        ProgramDependenceGraph.addNode(pdgGraph, eug.getHeads().get(0));

        if (!type.equalsIgnoreCase("AssignStmt")) {

            ProgramDependenceGraph.addEdge(pdgGraph, unit, eug.getHeads().get(0), DependencyTypes.CALL);

        }

        Iterator calleeMethodIterator = calleeMethodPdg.iterator();


        while (calleeMethodIterator.hasNext()) {
            Unit cmUnit = (Unit) calleeMethodIterator.next();

            ProgramDependenceGraph.addNode(pdgGraph, cmUnit);


            List<Unit> cmUnitSuccs = calleeMethodPdg.getSuccsOf(cmUnit);
            for (Unit cmUnitSucc : cmUnitSuccs) {

                ProgramDependenceGraph.addNode(pdgGraph, cmUnitSucc);


                ProgramDependenceGraph.addEdge(pdgGraph, cmUnit, cmUnitSucc, DependencyTypes.CONTROL_DEPENDENCY);


                //TODO add labels for different edges coming from different forms of dependencies
                ProgramDependenceGraph.addEdge(pdgGraph, cmUnit, cmUnitSucc, DependencyTypes.DATA_DEPENDENCY);
            }
        }


        //add the second edge
        List<Unit> tails = eug.getTails();
        //by doing this we ensure to make our return statements for a call a predecessor of an assign statement
        //and hence include them in the interprocedural slice of the variable, together with its predecessors

        if (type.equalsIgnoreCase("AssignStmt")) {
            for (Unit tail : tails) {
                ProgramDependenceGraph.addNode(pdgGraph, unit);
                ProgramDependenceGraph.addNode(pdgGraph, tail);
                ProgramDependenceGraph.addEdge(pdgGraph, tail, unit, DependencyTypes.RETURN_CALL);

            }
        } else {
            if (pdg.getCfg().getSuccsOf(unit).size() > 0) {
                Unit nextUnit = pdg.getCfg().getSuccsOf(unit).get(0);

                for (Unit tail : tails) {
                    ProgramDependenceGraph.addNode(pdgGraph, nextUnit);
                    ProgramDependenceGraph.addNode(pdgGraph, tail);
                    ProgramDependenceGraph.addEdge(pdgGraph, tail, nextUnit, DependencyTypes.RETURN_CALL);


                }
            }
        }


    }


    /**
     * this method is used to add elements to a list of methods that reach the patch or are reached by the patch
     *
     * @param iterator
     * @param subjectList
     */
    void addtoLists(Iterator<MethodOrMethodContext> iterator, List<SootMethod> subjectList) {
        while (iterator.hasNext()) {
            MethodOrMethodContext nextEdge = iterator.next();
            SootMethod src = nextEdge.method();
            if (!subjectList.contains(src)) {
                subjectList.add(src);
            }

        }
    }

    List<Integer> printSlice(Set<Unit> slice) {
        List<Integer> nums = new ArrayList<Integer>();
        for (Unit unit : slice) {
            if (!nums.contains(unit.getJavaSourceStartLineNumber()) && unit.getJavaSourceStartLineNumber() != -1) {
                nums.add(unit.getJavaSourceStartLineNumber());
            }
        }
        return nums;
    }

    /**
     * this method is used to get the type of the unit, based on which the nodes will be compared in the PDG
     * TODO needs refactoring, potentially with a switch stmt
     *
     * @param unit
     * @return
     */
    String getUnitType(Unit unit) {
        String type = " ";

        if (unit instanceof AssertStmt) {
            return "AssertStmt";
        } else if (unit instanceof Block) {
            return "Block";
        } else if (unit instanceof BranchTargetStmt) {
            return "BranchTargetStmt";
        } else if (unit instanceof BreakStmt) {
            return "BreakStmt";
        } else if (unit instanceof Case) {
            return "Case";
        } else if (unit instanceof ContinueStmt) {
            return "ContinueStmt";
        } else if (unit instanceof EmptyStmt) {
            return "EmptyStmt";
        } else if (unit instanceof ExprStmt) {
            return "ExprStmt";
        } else if (unit instanceof IfStmt) {
            return "IfStmt";
        } else if (unit instanceof LocalClassDeclStmt) {
            return "LocalClassDeclStmt";
        } else if (unit instanceof ReturnStmt) {
            return "ReturnStmt";
        } else if (unit instanceof SynchronizedStmt) {
            return "SynchronizedStmt";
        } else if (unit instanceof ThrowStmt) {
            return "ThrowStmt";
        } else if (unit instanceof TryStmt) {
            return "TryStmt";
        } else if (unit instanceof VarDeclStmt) {
            return "VarDeclStmt";
        } else if (unit instanceof VariableDeclaration) {
            return "VariableDeclaration";
        } else if (unit instanceof AssignStmt) {
            return "AssignStmt";
        } else if (unit instanceof BreakpointStmt) {
            return "BreakPointStmt";
        } else if (unit instanceof DefinitionStmt) {
            return "DefinitionStmt";
        } else if (unit instanceof EnterMonitorStmt) {
            return "EnterMonitorStmt";
        } else if (unit instanceof ExitMonitorStmt) {
            return "ExitMonitorStmt";
        } else if (unit instanceof GotoStmt) {
            return "GotoStmt";
        } else if (unit instanceof IdentityStmt) {
            return "IdentityStmt";
        } else if (unit instanceof InvokeStmt) {
            return "InvokeStmt";
        } else if (unit instanceof LookupSwitchStmt) {
            return "LookupSwitchStmt";
        } else if (unit instanceof MonitorStmt) {
            return "MonitorStmt";
        } else if (unit instanceof NopStmt) {
            return "NopStmt";
        } else if (unit instanceof RetStmt) {
            return "RetStmt";
        } else if (unit instanceof ReturnStmt) {
            return "ReturnStmt";
        } else if (unit instanceof ReturnVoidStmt) {
            return "ReturnVoidStmt";
        } else if (unit instanceof SwitchStmt) {
            return "SwitchStmt";
        } else if (unit instanceof TableSwitchStmt) {
            return "TableSwitchStmt";
        } else if (unit instanceof ThrowStmt) {
            return "ThrowStmt";
        } else {
            return type;
        }

    }

    /**
     * this method eliminates the library method calls
     *
     * @param callGraph
     */
    void filterCallGraph(CallGraph callGraph) {


        Iterator<Edge> edges = callGraph.iterator();
        List<Edge> libraryEdges = new ArrayList<>();
        //TODO need to make this more efficient: the callgraph is already being traversed once to pick up application classes and once to remove the library edges


        while (edges.hasNext()) {
            Edge edge = edges.next();
            SootMethod target = edge.tgt();
            SootMethod src = edge.src();
            boolean targetIsApplication = checkMethod(target);
            boolean srcIsApplication = checkMethod(src);
            if (!targetIsApplication || !srcIsApplication) {
                libraryEdges.add(edge);

            }
        }
        for (Edge edge : libraryEdges) {
            callGraph.removeEdge(edge);
        }

    }

}


