package casualtydetector;

import com.github.gumtreediff.gen.Generators;
import com.github.gumtreediff.tree.ITree;
import com.github.gumtreediff.tree.TreeContext;
import javafx.util.Pair;
import org.apache.commons.collections4.BidiMap;
import org.apache.commons.collections4.bidimap.DualLinkedHashBidiMap;
import proganalysis.InterProceduralPDG;
import proganalysis.ProgramDependenceGraph;
import soot.*;
import util.ChangeUtil;
import util.DirectedGraph;
import util.Registrar;
import util.SootUtilities;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import java.util.logging.Level;

import static util.Constants.*;

public class APICCCharacterizer {
    Registrar registrar;
    LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassNew;
    LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassOld;
    HashMap<String, List<ITree>> methodToITreeChangesOld;
    HashMap<String, List<ITree>> methodToITreeChangesNew;
    int lineCount;
    PrintWriter outCausFineGrainedPWriter;


    APICCCharacterizer(Registrar registrar, LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassNew,
                       LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassold) {
        this.registrar = registrar;
        this.changesPerMethodInClassNew = changesPerMethodInClassNew;
        this.changesPerMethodInClassOld = changesPerMethodInClassold;
        methodToITreeChangesOld = new HashMap<>();
        methodToITreeChangesNew = new HashMap<>();

    }

    APICCCharacterizer(Registrar registrar, LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassNew,
                       LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassold, PrintWriter outCausFineGrainedPWriter) {
        this.registrar = registrar;
        this.changesPerMethodInClassNew = changesPerMethodInClassNew;
        this.changesPerMethodInClassOld = changesPerMethodInClassold;
        methodToITreeChangesOld = new HashMap<>();
        methodToITreeChangesNew = new HashMap<>();
        this.outCausFineGrainedPWriter = outCausFineGrainedPWriter;

    }


    /**
     * this method finds root API changes given a list of API changes
     * it does so by first building a graph of API changes (based on methods whose APIs have changed and call each-other)
     * then it does a reachability analysis on a reverse graph: if a method reaches all others, it is a main change
     *
     * @param apiChanges
     * @return
     * @throws IOException
     */
    public List<String> findRootChanges(List<Pair<Integer, ITree>> apiChanges, boolean old) throws IOException {
        List<String> rootChanges = new ArrayList<>();


        if (DEBUG) {
            String message = "Size of api changes list: " + apiChanges.size();
            logger.log(Level.INFO, message);
        }

//        find all corresponding sootMethods from the apiChanges identified as well as their corresponding changed parameters
        HashMap<SootMethod, Set<Unit>> sootMethodstoApi = getApiChangesSootMethods(apiChanges, old);
        List<SootMethod> sootMethods = new ArrayList<>(sootMethodstoApi.keySet());


        BidiMap<String, Integer> methodId = new DualLinkedHashBidiMap<>();

        List<String> edges = new ArrayList<>();


        getConnectedAPIChanges(sootMethodstoApi, methodId, edges);

        if (sootMethods.size() == 1) {
            if (DEBUG) {
                logger.log(Level.INFO, "findRootMethods: " + sootMethods.get(0).getSignature() + " is a root change");
            }
            rootChanges.add(sootMethods.get(0).getSignature());

            return rootChanges;

        }

        if (methodId.size() == 0) {
            if(DEBUG)
                logger.log(Level.INFO, "findRootMethods: No methods with edges found. Root methods determined through soot methods");
            return getNoEdgeRootChanges(sootMethods);

        } else {

            if (DEBUG) {
                logger.log(Level.INFO, "findRootMethods: Methods with edges found: ");
                logMethods(methodId);
            }
            List<String> rootChangesFromGraph = getRootChangesFromGraph(methodId, edges);

            if (methodId.size() < sootMethods.size()) {

                for (SootMethod sootMethod : sootMethods) {
                    if (!methodId.containsKey(sootMethod.getSignature())) {
                        rootChangesFromGraph.add(sootMethod.getSignature());
                    }
                }

            }

            return rootChangesFromGraph;

        }

    }

    private void getConnectedAPIChanges(HashMap<SootMethod, Set<Unit>> sootMethodsMap, BidiMap<String, Integer> methodId, List<String> edges) {
        int id = 0;
//      get all the methods in the API changes that call each other
        Set<SootMethod> sootMethods = sootMethodsMap.keySet();
        for (SootMethod sootMethod : sootMethods) {
            ChangeUtil changeUtil = new ChangeUtil();
            //if this doesn't work, there is also the method using the soot callgraph called getEdges (but in CVE-2011-1184 it seems not to work)
            id = changeUtil.getEdgesNoCallgraph(sootMethodsMap, methodId, edges, id, sootMethod);
        }
    }

    private void logMethods(BidiMap<String, Integer> methodId) {
        Iterator<Map.Entry<String, Integer>> methodIDiterator = methodId.entrySet().iterator();
        while (methodIDiterator.hasNext()) {
            Map.Entry<String, Integer> entry = methodIDiterator.next();
            String methodName = entry.getKey();
            int methodValue = entry.getValue();

            logger.log(Level.INFO, methodName + ": " + methodValue);
        }
    }

    private List<String> getNoEdgeRootChanges(List<SootMethod> sootMethods) {
        List<String> rootChanges = new ArrayList<>();
        for (SootMethod sootMethod : sootMethods) {
            rootChanges.add(sootMethod.getSignature());
        }
        return rootChanges;
    }

    private List<String> getRootChangesFromGraph(BidiMap<String, Integer> methodId, List<String> edges) {
        List<String> rootChanges = new ArrayList<>();
        BidiMap<String, Integer> processedMethodId = new DualLinkedHashBidiMap<>();

        //we have to do reachability analysis for each component, and we can get connected components by just "pretending" the graph is undirected

        List<DirectedGraph> directedGraphs = ChangeUtil.buildGraphs(edges, methodId.size(), methodId, processedMethodId);


        for (DirectedGraph directedGraph : directedGraphs) {


            directedGraph.reachability();
            HashMap<Integer, List<Integer>> reachable = directedGraph.getReachability();

            Iterator<Map.Entry<Integer, List<Integer>>> reachableIterator = reachable.entrySet().iterator();
            BidiMap<Integer, String> integerStringBidiMap = processedMethodId.inverseBidiMap();
            while (reachableIterator.hasNext()) {
                Map.Entry<Integer, List<Integer>> entry = reachableIterator.next();
                int key = entry.getKey();
                List<Integer> value = entry.getValue();

                if (DEBUG) {
                    logger.log(Level.INFO, "reach key :" + key);
                    logger.log(Level.INFO, "reach value: " + Arrays.toString(value.toArray()));
                }
                boolean rootChange = directedGraph.reachesAll(key);
                String methodFullName = integerStringBidiMap.get(key);
                if (rootChange) {
                    if (DEBUG) {
                        logger.log(Level.INFO, "Changes in method: " + key + "-" + methodFullName + " are root changes");
                    }


                    rootChanges.add(methodFullName);
                } else if (DEBUG) {
                    logger.log(Level.INFO, "Changes in api: " + methodFullName + "are potential casualty changes");
                }
            }
        }

        return rootChanges;
    }

//    private boolean checkMatchesInDG(int key, DirectedGraph directedGraph, BidiMap<String, Integer> processedMethodId, HashMap<SootMethod, ITree> sootMethodToApi){
//        List<Integer> nodes = directedGraph.getReachability().get(key);
//        String mainMethod = processedMethodId.getKey(key);
//        SootMethod method = Scene.v().getMethod(mainMethod);
//        if(sootMethodToApi.containsKey(method)) {
//            for (Integer node : nodes) {
//                if (processedMethodId.containsValue(node)) {
//                    String methodName = processedMethodId.getKey(node);
//
//
//                }
//            }
//        }
//    }


    /**
     * this method maps found API Changes in Gumtree to SootMethods
     *
     * @param apiChanges
     * @param old
     * @return
     * @throws IOException
     */
    private HashMap<SootMethod, Set<Unit>> getApiChangesSootMethods(List<Pair<Integer, ITree>> apiChanges, boolean old)
            throws IOException {
        String prefix = old ? registrar.getFirstPrefix() : registrar.getSecondPrefix();
        String[] files = registrar.getFiles();
        int type = registrar.getType();

        HashMap<SootMethod, Set<Unit>> sootMethodsToApi = new HashMap<>();
        for (Pair<Integer, ITree> apiChange : apiChanges) {
            int fileNo = determineFileNo(old, apiChange.getKey());
            String filePath = files[fileNo];
//            if (old) {
//                filePath = files[apiChange.getKey()];
//            } else {
//                filePath = files[apiChange.getKey() + 1];
//            }
            String className;
            if (type == 4) {
                className = SootUtilities.getClassName(filePath, true);
            } else if (filePath.contains("org")) {
                className = SootUtilities.getClassName(prefix, filePath, true);
            } else {
                className = SootUtilities.getClassName(prefix, filePath);
            }
            TreeContext treeContext = Generators.getInstance().getTree(filePath);
            SootMethod sootMethod = SootUtilities.getSootMethod(apiChange.getValue(), className, treeContext);
            if (sootMethod != null) {
                Unit convertedUnit = ChangeUtil.convertToParameterUnit(sootMethod, apiChange.getValue(), treeContext);
                if (convertedUnit != null) {
                    Set<Unit> units;
                    if (!sootMethodsToApi.containsKey(sootMethod)) {
                        units = new HashSet<>();
                    } else {
                        units = sootMethodsToApi.get(sootMethod);
                    }

                    units.add(convertedUnit);
                    sootMethodsToApi.put(sootMethod, units);
                }
            }
        }
        return sootMethodsToApi;
    }

    public List<SootMethod> findCasualtyInstances(List<SootMethod> changedSootMethods, List<ITree> changedGumtreeMethods,
                                                                List<ITree> addedMethodInvocations, List<ITree> deletedMethodInvocations,
                                                                HashMap<String, List<ITree>> methodsToITreeChanges,
                                                                HashMap<SootMethod, List<String>> reachableMap, boolean old) throws IOException {

        String[] files = registrar.getFiles();
        List<SootMethod> methodNames = new ArrayList<>();
        LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClass = old ? changesPerMethodInClassOld: changesPerMethodInClassNew;

        for (int i = 0; i < changedSootMethods.size(); i++) {
            SootMethod sootMethod = changedSootMethods.get(i);
            if (reachableMap.containsKey(sootMethod)) {

                String className = sootMethod.getDeclaringClass().toString().replace('.', '/');
                int fileNo = SootUtilities.findFileNo(files, className);
                if (fileNo != -1) {
                    fileNo = determineFileNo(old, fileNo);


                    TreeContext treeContext = Generators.getInstance().getTree(files[fileNo]);
                    ITree methodDeclaration = changedGumtreeMethods.get(i);

                    String key = SootUtilities.getMethodName(methodDeclaration, treeContext) + ": " + methodDeclaration.getPos();
                    if (DEBUG) {
                        logger.log(Level.INFO, "findCasualtyInstances: changed soot method: " + key);
                    }

                    if (changesPerMethodInClass.containsKey(fileNo)) {
                        HashMap<String, List<ITree>> changesPerMethod = changesPerMethodInClass.get(fileNo);
                        if (changesPerMethod.containsKey(key)) {

                            List<ITree> originNodes =changesPerMethod.get(key);


                            for (ITree node : originNodes) {
                                String type = node.toPrettyString(treeContext).split(":")[0];
                                boolean presentInOnlyOne = (addedMethodInvocations.contains(node) && !deletedMethodInvocations.contains(node)) || (!addedMethodInvocations.contains(node) && deletedMethodInvocations.contains(node));
                                boolean presentInNone = !addedMethodInvocations.contains(node) && !deletedMethodInvocations.contains(node);

                                //this check should be enough to rule out cases where a call is added from scratch (i.e. not updated or modified), but if not
                                // might need to check refining further in ChangedNodeIdentifier
                                boolean presenceTest = !presentInOnlyOne || presentInNone;
                                if (presenceTest) {
                                    if (type.equalsIgnoreCase(MET_INV)) {
                                        checkMethodInvocationInstances(methodsToITreeChanges, reachableMap, methodNames, sootMethod, treeContext, node);
                                    }
                                    if (type.equalsIgnoreCase(CLASS_INSTC_CREAT)) {
                                        checkClassCreationInstances(methodsToITreeChanges, reachableMap, methodNames, sootMethod, treeContext, node);
                                    }

                                    if (type.equalsIgnoreCase(CONSTR_INV)) {
                                        checkConstructorInvocationInstances(methodsToITreeChanges, reachableMap, methodNames, sootMethod, className, node);
                                    }
                                }

                            }

                        }
                    }
                }
            }


        }
        if(old){
            methodToITreeChangesOld = methodsToITreeChanges;
        }
        else{
            methodToITreeChangesNew = methodsToITreeChanges;
        }
        return methodNames;
    }

    private int determineFileNo(boolean old, int fileNo) {
        if (old && (fileNo + 1) % 2 == 0) {
            fileNo = fileNo - 1;
        } else if (!old && fileNo % 2 == 0) {
            fileNo = fileNo + 1;
        }
        return fileNo;
    }

    /**
     * this method checks Constructor Invocation nodes if they are Casualty Instances
     * @param methodsToITreeChanges
     * @param reachableMap
     * @param methodNames
     * @param sootMethod
     * @param className
     * @param node
     */
    private void checkConstructorInvocationInstances(HashMap<String, List<ITree>> methodsToITreeChanges, HashMap<SootMethod, List<String>> reachableMap, List<SootMethod> methodNames, SootMethod sootMethod, String className, ITree node) {
        String[] constructorNameSplit = className.split("/");
        String constructorName = constructorNameSplit[constructorNameSplit.length - 1].trim();

        List<String> reachableMethods = reachableMap.get(sootMethod);
        for (String method : reachableMethods) {

            String shortMethodName = SootUtilities.getMethodNameFromFullName(method);

            boolean hasLabel = method.contains(constructorName);

            if (hasLabel && shortMethodName.contains("<init>")) {
                if (!methodNames.contains(sootMethod))
                    methodNames.add(sootMethod);
                if (methodsToITreeChanges.containsKey(sootMethod.getSignature())) {
                    List<ITree> iTrees = methodsToITreeChanges.get(sootMethod.getSignature());
                    if (!iTrees.contains(node)) {
                        iTrees.add(node);
                    }
                    methodsToITreeChanges.replace(sootMethod.getSignature(), iTrees);
                } else {
                    List<ITree> iTrees = new ArrayList<>();
                    iTrees.add(node);
                    methodsToITreeChanges.put(sootMethod.getSignature(), iTrees);

                }
            }
        }
    }

    /**
     * this method checks Class Creation nodes if they are Casualty Instances
     * @param methodsToChanges
     * @param reachableMap
     * @param methodNames
     * @param sootMethod
     * @param treeContext
     * @param node
     */
    private void checkClassCreationInstances(
            HashMap<String, List<ITree>> methodsToChanges,
            HashMap<SootMethod, List<String>> reachableMap,
            List<SootMethod> methodNames,
            SootMethod sootMethod,
            TreeContext treeContext,
            ITree node) {
        if (node.getChildren().size() > 0) {
            String childType = node.getChild(0).toPrettyString(treeContext).split(":")[0];
            if (childType.equalsIgnoreCase(SIMPLE_NAME) ||
                    childType.equalsIgnoreCase(SIMPLE_TYPE)) {

                List<String> reachableMethods = reachableMap.get(sootMethod);
                for (String method : reachableMethods) {

                    String shortMethodName = SootUtilities.getMethodNameFromFullName(method);
                    List<String> childLabels = new ArrayList<>();
                    for (ITree child : node.getChildren()) {
                        if (child.hasLabel()) {
                            childLabels.add(child.getLabel().trim());
                        }
                    }
                    boolean hasLabel = false;
                    for (String label : childLabels) {
                        if (method.contains(label)) {
                            hasLabel = true;
                        }
                    }
                    if (hasLabel && shortMethodName.contains("<init>")) {
                        if (!methodNames.contains(sootMethod))
                            methodNames.add(sootMethod);
                        if (methodsToChanges.containsKey(sootMethod.getSignature())) {
                            List<ITree> iTrees = methodsToChanges.get(sootMethod.getSignature());
                            if (!iTrees.contains(node)) {
                                iTrees.add(node);
                            }
                            methodsToChanges.replace(sootMethod.getSignature(), iTrees);
                        } else {
                            List<ITree> iTrees = new ArrayList<>();
                            iTrees.add(node);
                            methodsToChanges.put(sootMethod.getSignature(), iTrees);

                        }
                    }
                }


            }
        }
    }

    /**
     * this method checks is Method Invocation nodes are casualty instances
     * @param methodsToChanges
     * @param reachableMap
     * @param methodNames
     * @param sootMethod
     * @param treeContext
     * @param node
     */
    private void checkMethodInvocationInstances(HashMap<String, List<ITree>> methodsToChanges,
                                                HashMap<SootMethod, List<String>> reachableMap,
                                                List<SootMethod> methodNames,
                                                SootMethod sootMethod,
                                                TreeContext treeContext,
                                                ITree node) {
        if (node.getChildren().size() > 0) {
            String childType = node.getChild(0).toPrettyString(treeContext).split(":")[0];
            if (childType.equalsIgnoreCase(SIMPLE_NAME) ||
                    childType.equalsIgnoreCase(SIMPLE_TYPE)) {

                List<String> reachableMethods = reachableMap.get(sootMethod);
                for (String method : reachableMethods) {

                    String shortMethodName = SootUtilities.getMethodNameFromFullName(method);
                    if (SootUtilities.nameInChildren(shortMethodName, node)) {
                        if (!methodNames.contains(sootMethod))
                            methodNames.add(sootMethod);
                        if (methodsToChanges.containsKey(sootMethod.getSignature())) {
                            List<ITree> iTrees = methodsToChanges.get(sootMethod.getSignature());
                            if (!iTrees.contains(node)) {
                                iTrees.add(node);
                            }
                            methodsToChanges.replace(sootMethod.getSignature(), iTrees);
                        } else {
                            List<ITree> iTrees = new ArrayList<>();
                            iTrees.add(node);
                            methodsToChanges.put(sootMethod.getSignature(), iTrees);

                        }
                    }
                }


            }
        }
    }



    /**
     * propagates casualty instances in methods with both deletes and ins, upd, or mov actions
     * @param sootMethod1
     * @param sootMethod2
     * @param gumTreeMethod1
     * @param gumTreeMethod2
     * @return
     * @throws IOException
     */
    public boolean propagateCasualtyChangesOverlap(SootMethod sootMethod1, SootMethod sootMethod2,
                                                   ITree gumTreeMethod1, ITree gumTreeMethod2) throws IOException {
        boolean oldOnesCovered = true;
        String signature1 = sootMethod1.getSignature();
        if (methodToITreeChangesOld.containsKey(signature1)) {
            oldOnesCovered = casualtyCoversOthers(sootMethod1, gumTreeMethod1, signature1, true);
        }

        boolean newOnesCovered = true;
        String signature2 = sootMethod2.getSignature();
        if (methodToITreeChangesNew.containsKey(signature1)) {
            newOnesCovered = casualtyCoversOthers(sootMethod2, gumTreeMethod2, signature2, false);
        }

        if (oldOnesCovered && newOnesCovered) {
            logger.log(Level.INFO, "propagateCasualtyChangesOverlap: all casualty from overlap - " + sootMethod1.getSignature());
        }
        return oldOnesCovered && newOnesCovered;
    }

    private boolean casualtyCoversOthers(SootMethod sootMethod,
                                         ITree gumTreeMethod,
                                         String signature,
                                         boolean old) throws IOException {
        boolean covered = true;
        String[] files = registrar.getFiles();
        String classPath = old? registrar.getFirstVersionClassPath(): registrar.getSecondVersionClassPath();
        HashMap<String, List<ITree>> methodToITreeChanges = old? methodToITreeChangesOld: methodToITreeChangesNew;
        LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClass = old? changesPerMethodInClassOld: changesPerMethodInClassNew;

        List<ITree> casualtyChangesITree = methodToITreeChanges.get(signature);

        String className = sootMethod.getDeclaringClass().toString();
        String classNameProcessed = className.replace(".", "/");
        int fileNo = SootUtilities.findFileNo(files, classNameProcessed);
        if (fileNo % 2 == 0 && !old) {
            fileNo = fileNo + 1;
        }
        List<ITree> nodes = new ArrayList<>();

        TreeContext treeContext = Generators.getInstance().getTree(files[fileNo]).deriveTree();

        String key = SootUtilities.getMethodName(gumTreeMethod, treeContext) + ": " + gumTreeMethod.getPos();
        if (changesPerMethodInClass.containsKey(fileNo) && changesPerMethodInClass.get(fileNo).containsKey(key)) {
            nodes = changesPerMethodInClass.get(fileNo).get(key);



        }
        if (casualtyChangesITree.size() > 0 && nodes.size() > 0) {
            covered = casualtyChangesITree.size() == nodes.size();

            if (!covered) {
                //this was superfluous
                //G.reset();

                ChangeUtil.setSootEnvironment(classPath);

                SootClass sootClass = Scene.v().loadClassAndSupport(sootMethod.getDeclaringClass().toString());
                sootClass.setApplicationClass();
                SootMethod sootMethodNew = ChangeUtil.getSootMethod(sootMethod, sootClass);
                if (sootMethodNew != null) {
                    List<Unit> casualtyChangesUnit = ChangeUtil.convertToUnit(sootMethodNew, casualtyChangesITree, treeContext);

                    List<Unit> nodesToUnit = ChangeUtil.convertToUnit(sootMethodNew, nodes, treeContext);
                    InterProceduralPDG interProceduralPDG = new InterProceduralPDG();
                    className = className.replace('/', '.');
                    interProceduralPDG.run(className, sootMethodNew);

                    ProgramDependenceGraph intraProceduralPDG = interProceduralPDG.getInterProceduralPDG();
                    boolean[] presenceInNew = new boolean[nodesToUnit.size()];
                    Set<Integer> lines = new HashSet<>();
                    for (Unit unit : casualtyChangesUnit) {
                        int line = ChangeUtil.getUnitLineNumber(unit);
                        inner:
                        for (int i = 0; i < nodesToUnit.size(); i++) {

                            if (!presenceInNew[i]) {
                                Unit newUnit = nodesToUnit.get(i);

                                int newLine = ChangeUtil.getUnitLineNumber(newUnit);
                                if (line == newLine) {
                                    presenceInNew[i] = true;
                                    lines.add(line);
                                } else {
                                    boolean dataflow = ChangeUtil.areEdgesConnectedThroughBackwardDataFlow(intraProceduralPDG, unit, newUnit);
                                    if (dataflow) {
                                        presenceInNew[i] = true;
                                        lines.add(newLine);
                                    }
                                }
                            }
                        }
                    }
                    if (lines.size() > 0 && outCausFineGrainedPWriter != null) {
                        writeFineGrainedCasualties(sootMethodNew.getSignature(), lines);
                    }
                    lineCount = lineCount + lines.size();
                    int count = 0;

                    for (int i = 0; i < presenceInNew.length; i++) {
                        boolean presence = presenceInNew[i];
                        if (presence) {
                            count++;
                        }


                    }


                    covered = count == nodesToUnit.size();
                    G.reset();
                }
            }
        }
        if (casualtyChangesITree.size() == 0 && nodes.size() > 0) {
            covered = false;
        }
        return covered;
    }

    /**
     * propagates casualty instances for given methods that only have one type of action (either del or mov, upd, ins).
     * @param sootMethods
     * @param changedGumtreeMethods
     * @param old
     * @return
     * @throws IOException
     */
    public List<SootMethod> propagateCasualtyChanges(List<SootMethod> sootMethods,
                                                     List<ITree> changedGumtreeMethods,
                                                     boolean old) throws IOException {
        HashMap<String, List<ITree>> methodToITreeChanges = old ? methodToITreeChangesOld: methodToITreeChangesNew;
        String [] files = registrar.getFiles();
        String classPath = old? registrar.getFirstVersionClassPath() : registrar.getSecondVersionClassPath();
        LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClass = old ? changesPerMethodInClassOld : changesPerMethodInClassNew;

        List<SootMethod> result = new ArrayList<>();
        for (int j = 0; j < sootMethods.size(); j++) {
            SootMethod sootMethod = sootMethods.get(j);
            ITree method = changedGumtreeMethods.get(j);
            String signature = sootMethod.getSignature();
            if (methodToITreeChanges.containsKey(signature)) {
                List<ITree> casualtyChangesITree = methodToITreeChanges.get(signature);

                List<ITree> casualtyChanges = new ArrayList<>();

                String className = sootMethod.getDeclaringClass().toString().replace(".", "/");
                int fileNo = SootUtilities.findFileNo(files, className);
                fileNo = determineFileNo(old, fileNo);

                TreeContext treeContext = Generators.getInstance().getTree(files[fileNo]).deriveTree();

                String key = SootUtilities.getMethodName(method, treeContext) + ": " + method.getPos();
                if (changesPerMethodInClass.containsKey(fileNo) && changesPerMethodInClass.get(fileNo).containsKey(key)) {
                    List<ITree> allChanges = changesPerMethodInClass.get(fileNo).get(key);


                    List<ITree> versionNodes = new ArrayList<>();
                    sortChangedNodes(
                            casualtyChangesITree,
                            casualtyChanges,
                            allChanges,
                            versionNodes);

                    boolean covered = true;
                    if (casualtyChanges.size() > 0 && versionNodes.size() > 0) {
                        covered = casualtyChanges.size() == versionNodes.size();

                        if (!covered) {
                            ChangeUtil.setSootEnvironment(classPath);
                            SootClass sootClass = Scene.v().loadClassAndSupport(sootMethod.getDeclaringClass().toString());
                            sootClass.setApplicationClass();
                            SootMethod sootMethodNew = ChangeUtil.getSootMethod(sootMethod, sootClass);
                            covered = getCasualtyInstancesSoot(sootMethodNew, casualtyChanges, treeContext, versionNodes, old);
                        }
                    }
                    if (casualtyChanges.size() == 0 && versionNodes.size() > 0) {
                        covered = false;
                    }
                    if(covered){
                        if(!result.contains(sootMethod)) {
                            result.add(sootMethod);
                        }
                        logger.log(Level.INFO, "all casualty from non-overlap: " + sootMethod.getSignature());
                    }

                }
            }
        }
        return result;
    }

    public void propagateCasualtyChanges(SootMethod sootMethod,
                                         ITree gumTreeMethod,
                                         List<Unit> changedUnits,
                                         boolean[] presence,
                                         boolean old) throws IOException {
        HashMap<String, List<ITree>> methodToITreeChanges = old ? methodToITreeChangesOld : methodToITreeChangesNew;
        String[] files = registrar.getFiles();
        LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClass = old ? changesPerMethodInClassOld : changesPerMethodInClassNew;


        String signature = sootMethod.getSignature();
        if (methodToITreeChanges.containsKey(signature)) {
            List<ITree> casualtyChangesITree = methodToITreeChanges.get(signature);

            List<ITree> casualtyChanges = new ArrayList<>();

            String className = sootMethod.getDeclaringClass().toString().replace(".", "/");
            int fileNo = SootUtilities.findFileNo(files, className);
            fileNo = determineFileNo(old, fileNo);

            TreeContext treeContext = Generators.getInstance().getTree(files[fileNo]).deriveTree();


            String key = SootUtilities.getMethodName(gumTreeMethod, treeContext) + ": " + gumTreeMethod.getPos();

            if (changesPerMethodInClass.containsKey(fileNo) && changesPerMethodInClass.get(fileNo).containsKey(key)) {
                List<ITree> allChanges = changesPerMethodInClass.get(fileNo).get(key);
                sortChangedNodes(casualtyChangesITree, casualtyChanges, allChanges);


                if (casualtyChanges.size() > 0 && allChanges.size() > 0) {

                    //getCasualtyInstancesSoot(sootMethodNew, casualtyChanges, treeContext);
                    getCasualtySetsSoot(sootMethod, casualtyChanges, treeContext, changedUnits, presence);
                }
            }


        }
    }


    private void sortChangedNodes(
            List<ITree> casualtyChangesITree,
            List<ITree> casualtyChanges,

            List<ITree> allChanges) {
        for (ITree node : allChanges) {


            if (casualtyChangesITree.contains(node.getParent())) {
                casualtyChanges.add(node.getParent());
            }
        }


    }


    private void sortChangedNodes(
                                  List<ITree> casualtyChangesITree,
                                  List<ITree> casualtyChanges,
                                  List<ITree> allChanges,
                                  List<ITree> newVersionNodes) {
        for (ITree node : allChanges) {


                if (casualtyChangesITree.contains(node.getParent())) {
                    casualtyChanges.add(node.getParent());
                }
                newVersionNodes.add(node);
            }



    }

    boolean getCasualtyInstancesSoot(SootMethod sootMethod,
                                     List<ITree> casualtyChanges,
                                     TreeContext treeContext,
                                     List<ITree> versionNodes,
                                     boolean old) {
        boolean covered = false;
        String classPath = old ? registrar.getFirstVersionClassPath() : registrar.getSecondVersionClassPath();
        ChangeUtil.setSootEnvironment(classPath);
        SootClass sootClass = Scene.v().loadClassAndSupport(sootMethod.getDeclaringClass().toString());
        String className = sootMethod.getDeclaringClass().toString().replace(".", "/");
        sootClass.setApplicationClass();
        SootMethod sootMethodNew = ChangeUtil.getSootMethod(sootMethod, sootClass);
        if (sootMethodNew != null) {
            List<Unit> newCasualtyChangesUnit = ChangeUtil.convertToUnit(sootMethodNew, casualtyChanges, treeContext);

            List<Unit> newVersionNodesUnit = ChangeUtil.convertToUnit(sootMethodNew, versionNodes, treeContext);
            InterProceduralPDG interProceduralPDG = new InterProceduralPDG();
            className = className.replace('/', '.');
            interProceduralPDG.run(className, sootMethodNew);

            ProgramDependenceGraph intraProceduralPDG = interProceduralPDG.getInterProceduralPDG();
            boolean[] presenceInNew = new boolean[newVersionNodesUnit.size()];
            ChangeUtil.checkDataDependencies(sootMethodNew, newCasualtyChangesUnit, newVersionNodesUnit, intraProceduralPDG, presenceInNew);
            int count = 0;
            Set<Integer> lines = new HashSet<>();
            for (int i = 0; i < presenceInNew.length; i++) {
                boolean presence = presenceInNew[i];
                if (presence) {
                    count++;
                    Unit unit = newVersionNodesUnit.get(i);
                    lines.add(unit.getJavaSourceStartLineNumber());

                }
            }
            if (lines.size() > 0 && outCausFineGrainedPWriter != null) {
                writeFineGrainedCasualties(sootMethodNew.getSignature(), lines);
            }
            lineCount = lineCount + lines.size();

            covered = count == newVersionNodesUnit.size();
            G.reset();
        }

        return covered;
    }

    void writeFineGrainedCasualties(String signature, Set<Integer> lines) {

        outCausFineGrainedPWriter.write(signature + "#");
        for (Integer line : lines) {
            outCausFineGrainedPWriter.write(line + "#");
        }
        outCausFineGrainedPWriter.write(";");
    }


    /**
     * to be used in case we do joint casualties
     *
     * @param sootMethod
     * @param casualtyChanges
     * @param treeContext
     * @param allUnits
     * @param presence
     */

    void getCasualtySetsSoot(SootMethod sootMethod,
                             List<ITree> casualtyChanges,
                             TreeContext treeContext,
                             List<Unit> allUnits,
                             boolean[] presence) {


        List<Unit> newCasualtyChangesUnit = ChangeUtil.convertToUnit(sootMethod, casualtyChanges, treeContext);


        InterProceduralPDG interProceduralPDG = new InterProceduralPDG();
        String className = sootMethod.getDeclaringClass().toString();
        className = className.replace('/', '.');
        interProceduralPDG.run(className, sootMethod);

        ProgramDependenceGraph intraProceduralPDG = interProceduralPDG.getInterProceduralPDG();

        ChangeUtil.checkDataDependencies(sootMethod, newCasualtyChangesUnit, allUnits, intraProceduralPDG, presence);


    }




}
