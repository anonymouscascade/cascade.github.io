package casualtydetector;

import com.github.gumtreediff.gen.Generators;
import com.github.gumtreediff.tree.ITree;
import com.github.gumtreediff.tree.TreeContext;
import fixdetector.ChangedNodesIdentifier;
import gr.uom.java.xmi.UMLModel;
import gr.uom.java.xmi.UMLModelASTReader;
import gr.uom.java.xmi.UMLOperation;
import gr.uom.java.xmi.diff.ExtractOperationRefactoring;
import gr.uom.java.xmi.diff.InlineOperationRefactoring;
import gr.uom.java.xmi.diff.UMLModelDiff;
import org.refactoringminer.api.Refactoring;
import org.refactoringminer.api.RefactoringMinerTimedOutException;
import proganalysis.InterProceduralPDG;
import soot.*;
import soot.jimple.AssignStmt;
import soot.jimple.IfStmt;
import soot.jimple.InvokeExpr;
import soot.jimple.InvokeStmt;
import soot.jimple.internal.JInvokeStmt;
import util.ChangeUtil;
import util.Registrar;
import util.SootUtilities;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static util.Constants.DEBUG;
import static util.Constants.logger;

public class RefactoringCCDetector implements CasualtyChangeDetector {
    PrintWriter outSystemPWriter;
    PrintWriter outCausPWriter;
    PrintWriter outFineGrainedCasPWriter;

    //casualty analysis related variables
    List<SootMethod> newChangedSootMethods;
    List<SootMethod> oldChangedSootMethods;

    List<ITree> newChangedGumtreeMethods;
    List<ITree> oldChangedGumtreeMethods;
    LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassNew;
    LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassOld;

    HashMap<String, List<String>> extractMethodRootToCasualties = new HashMap<>();
    HashMap<String, List<String>> inlineMethodRootToCasualties = new HashMap<>();

    List<String> oldStringifiedMethods = new ArrayList<>();



    Registrar registrar;
    int lineCount;

    @Override
    public void run(ChangedNodesIdentifier changedNodesIdentifier, Registrar registrar) throws IOException {
        this.registrar = registrar;

        HashMap<RefactoringType, HashMap<UMLOperation, List<UMLOperation>>> refactorings = getRefactorings();
        //inline method has the root change in pre revision, casualty changes in the post
        //extract method has the root change and casualty in post revision

        //get changedSootMethods

        if (refactorings.keySet().size() > 0) {
            //these variables are not initialized until they need to be
            initializeCasualtyRelatedVariables();
            SootUnitProxy sootUnitProxy = new SootUnitProxy();

            changesPerMethodInClassNew = changedNodesIdentifier.getChangesPerMethodInClassNew();
            sootUnitProxy.getChangedSootMethods(registrar.getSecondVersionClassPath(),
                    registrar.getSecondPrefix(), newChangedSootMethods,
                    newChangedGumtreeMethods, changesPerMethodInClassNew, registrar.getFiles(), registrar.getType());


            changesPerMethodInClassOld = changedNodesIdentifier.getChangesPerMethodInClassOld();


            if (refactorings.containsKey(RefactoringType.INLINE_METHOD)) {
                G.reset();

                sootUnitProxy.getChangedSootMethods(registrar.getFirstVersionClassPath(),
                        registrar.getFirstPrefix(), oldChangedSootMethods,
                        oldChangedGumtreeMethods, changesPerMethodInClassOld, registrar.getFiles(), registrar.getType());

            }

            List<String> newSootMethodsStringified = stringifySootMethods(newChangedSootMethods);

            List<String> oldSootMethodsStringified = stringifySootMethods(oldChangedSootMethods);




            for (RefactoringType refactoringType : refactorings.keySet()) {
                HashMap<UMLOperation, List<UMLOperation>> rootToCasualtyChanges = refactorings.get(refactoringType);

                if (refactoringType.equals(RefactoringType.EXTRACT_METHOD)) {
                    extractMethodRootToCasualties = analyzeExtractMethodRefs(rootToCasualtyChanges, newSootMethodsStringified);
                }

                if (refactoringType.equals(RefactoringType.INLINE_METHOD)) {
                    inlineMethodRootToCasualties = analyzeInlineMethodRefs(rootToCasualtyChanges, oldSootMethodsStringified, newSootMethodsStringified);
                }


            }

            Set<SootMethod> onlyCasualties = findCasualtyOnlyMethods(newSootMethodsStringified, oldSootMethodsStringified);
            ChangeUtil.writeCasualtiesToFile(outCausPWriter, onlyCasualties);


        }
        writeNewLineToFiles();


    }

    public void run(ChangedNodesIdentifier changedNodesIdentifier, Registrar registrar,
                    List<SootMethod> newChangedSootMethods, List<SootMethod> oldChangedSootMethods,
                    List<ITree> newChangedGumtreeMethods, List<ITree> oldChangedGumtreeMethods) throws IOException {
        this.registrar = registrar;

        HashMap<RefactoringType, HashMap<UMLOperation, List<UMLOperation>>> refactorings = getRefactorings();
        //inline method has the root change in pre revision, casualty changes in the post
        //extract method has the root change and casualty in post revision

        //get changedSootMethods

        if (refactorings.keySet().size() > 0) {
            //these variables are not initialized until they need to be
            initializeCasualtyRelatedVariables();


            changesPerMethodInClassNew = changedNodesIdentifier.getChangesPerMethodInClassNew();


            changesPerMethodInClassOld = changedNodesIdentifier.getChangesPerMethodInClassOld();

            initializeSootProxyVars(newChangedSootMethods, oldChangedSootMethods, newChangedGumtreeMethods, oldChangedGumtreeMethods);


            List<String> newSootMethodsStringified = stringifySootMethods(newChangedSootMethods);

            List<String> oldSootMethodsStringified = stringifySootMethods(oldChangedSootMethods);


            for (RefactoringType refactoringType : refactorings.keySet()) {
                HashMap<UMLOperation, List<UMLOperation>> rootToCasualtyChanges = refactorings.get(refactoringType);

                if (refactoringType.equals(RefactoringType.EXTRACT_METHOD)) {
                    extractMethodRootToCasualties = analyzeExtractMethodRefs(rootToCasualtyChanges, newSootMethodsStringified);
                }

                if (refactoringType.equals(RefactoringType.INLINE_METHOD)) {
                    inlineMethodRootToCasualties = analyzeInlineMethodRefs(rootToCasualtyChanges, oldSootMethodsStringified, newSootMethodsStringified);
                }


            }

            Set<SootMethod> onlyCasualties = findCasualtyOnlyMethods(newSootMethodsStringified, oldSootMethodsStringified);
            ChangeUtil.writeCasualtiesToFile(outCausPWriter, onlyCasualties);


        }
        writeNewLineToFiles();


    }

    private void initializeSootProxyVars(List<SootMethod> newChangedSootMethods, List<SootMethod> oldChangedSootMethods, List<ITree> newChangedGumtreeMethods, List<ITree> oldChangedGumtreeMethods) {
        this.newChangedGumtreeMethods = newChangedGumtreeMethods;
        this.newChangedSootMethods = newChangedSootMethods;
        this.oldChangedGumtreeMethods = oldChangedGumtreeMethods;
        this.oldChangedSootMethods = oldChangedSootMethods;
    }

    private void writeNewLineToFiles() {
        outCausPWriter.write('\n');
        outSystemPWriter.write('\n');
        //outCausFineGrainedPWriter.write('\n');
    }


    private void initializeCasualtyRelatedVariables() {
        newChangedSootMethods = new ArrayList<>();
        oldChangedSootMethods = new ArrayList<>();

        newChangedGumtreeMethods = new ArrayList<>();
        oldChangedGumtreeMethods = new ArrayList<>();

        changesPerMethodInClassNew = new LinkedHashMap<>();
        changesPerMethodInClassOld = new LinkedHashMap<>();

    }


    private Set<SootMethod> findCasualtyOnlyMethods(List<String> newSootMethodsStringified,
                                                    List<String> oldSootMethodsStringified) throws IOException {

        Set<SootMethod> results = new HashSet<>();
        if (extractMethodRootToCasualties.size() > 0 && inlineMethodRootToCasualties.size() > 0) {
            for (String firstKey : extractMethodRootToCasualties.keySet()) {
                List<String> firstValues = extractMethodRootToCasualties.get(firstKey);

                for (String secondKey : inlineMethodRootToCasualties.keySet()) {
                    List<String> secondValues = inlineMethodRootToCasualties.get(secondKey);

                    List<String> overlap = findIntersection(firstValues, secondValues);

                    //we remove the overlap so that we do not perform the analysis twice unnecessarily
                    if (overlap.size() > 0) {
                        extractMethodRootToCasualties.get(firstKey).removeAll(overlap);
                        inlineMethodRootToCasualties.get(secondKey).removeAll(overlap);
                    }


                    for (int i = 0; i < overlap.size(); i++) {
                        String casualty = overlap.get(i);
                        int casualtyIndex = newSootMethodsStringified.indexOf(casualty);
                        SootMethod casualtyMethod = newChangedSootMethods.get(casualtyIndex);
                        List<Unit> casualtyChangedNodes = getChangedNodesPerMethod(casualtyIndex, casualtyMethod, false);
                        boolean[] presenceInNew = new boolean[casualtyChangedNodes.size()];

                        SootMethod oldCasualtyMethod = getOldSootMethod(casualtyMethod);
                        if (oldCasualtyMethod != null) {
                            int index = oldSootMethodsStringified.indexOf(oldCasualtyMethod.getSignature());
                            List<Unit> oldCasualtyChangedNodes = getChangedNodesPerMethod(index, oldCasualtyMethod, true);

                            boolean[] presenceInOld = new boolean[oldCasualtyChangedNodes.size()];

                            inlineMethodRootToCasualtyAnalysis(oldSootMethodsStringified, secondKey, casualtyChangedNodes,
                                    presenceInNew, oldCasualtyMethod, oldCasualtyChangedNodes, presenceInOld);
                            extractMethodRootToCasualtyAnalysis(firstKey, newSootMethodsStringified, casualtyMethod, casualtyChangedNodes, oldCasualtyChangedNodes, presenceInNew, presenceInOld);

                            boolean allTrueNew = allTrue(casualtyMethod.getSignature(), presenceInNew, casualtyChangedNodes);
                            boolean allTrueOld = allTrue(oldCasualtyMethod.getSignature(), presenceInOld, oldCasualtyChangedNodes);
                            if (allTrueNew && allTrueOld) {
                                results.add(casualtyMethod);
                            }


                        } else {
                            inlineMethodRootToCasualtyAnalysis(oldSootMethodsStringified, secondKey, casualtyChangedNodes, presenceInNew);
                            extractMethodRootToCasualtyAnalysis(firstKey, newSootMethodsStringified, casualtyMethod, casualtyChangedNodes, presenceInNew);
                            boolean allTrueNew = allTrue(casualtyMethod.getSignature(), presenceInNew, casualtyChangedNodes);
                            if (allTrueNew) {
                                results.add(casualtyMethod);
                            }
                        }


                    }


                }
            }
        }

        //inline
        results.addAll(inlineMethodRootToCasualtyAnalysis(oldSootMethodsStringified, newSootMethodsStringified));


        //extract method
        results.addAll(extractMethodRootToCasualtyAnalysis(extractMethodRootToCasualties, newSootMethodsStringified));


        return results;
    }

    Set<SootMethod> inlineMethodRootToCasualtyAnalysis(List<String> oldSootMethodsStringified, List<String> newSootMethodsStringified) throws IOException {
        Set<SootMethod> results = new HashSet<>();
        for (String key : inlineMethodRootToCasualties.keySet()) {
            ChangeUtil.setSootEnvironment(registrar.getFirstVersionClassPath());

            List<String> casualtyMethods = inlineMethodRootToCasualties.get(key);

            int rootIndex = oldSootMethodsStringified.indexOf(key);

            SootMethod rootMethod = ChangeUtil.getProcessedMethod(oldChangedSootMethods.get(rootIndex));

            //get the changes per each method
            //List<Unit> rootChangedNodes = getChangedNodesPerMethod(rootIndex, rootMethod, true);
            PatchingChain<Unit> rootUnits = rootMethod.retrieveActiveBody().getUnits();
            List<String> stringifiedRootUnits = stringifyUnits(rootUnits);

            for (String casualty : casualtyMethods) {
                int casualtyIndex = newSootMethodsStringified.indexOf(casualty);
                SootMethod casualtyMethod = newChangedSootMethods.get(casualtyIndex);


                boolean[] presenceOld = null;
                boolean allTrueOld = false;

                SootMethod oldCasualtyMethod = ChangeUtil.getProcessedMethod(getOldSootMethod(casualtyMethod));
                if (oldCasualtyMethod != null) {
                    int index = oldStringifiedMethods.indexOf(oldCasualtyMethod.getSignature());
                    List<Unit> oldMethodChangedNodes = getChangedNodesPerMethod(index, oldCasualtyMethod, true);

                    //CVE-2012-0022_12 there is an if condition that is being deleted, and the call to the method is replaced with its body
                    //that is why the methods in this CVE are not all casualty
                    presenceOld = new boolean[oldMethodChangedNodes.size()];

                    isCallToRoot(oldCasualtyMethod, oldMethodChangedNodes, rootMethod, presenceOld);

                    allTrueOld = allTrue(oldCasualtyMethod.getSignature(), presenceOld, oldMethodChangedNodes);

                    if (allTrueOld) {
                        System.out.println("old all casualty: " + casualtyMethod.getSignature());
                    }
                }

                ChangeUtil.setSootEnvironment(registrar.getSecondVersionClassPath());
                SootMethod casualtyMethodProcessed = ChangeUtil.getProcessedMethod(casualtyMethod);


                List<Unit> casualtyChangedNodes = getChangedNodesPerMethod(casualtyIndex, casualtyMethodProcessed, false);


                //IT HAS EVERYTHING EXCEPT FOR THE ARGUMENTS PASSED TO THE OLD METHOD AND SOME VIRTUAL INVOKATIONS FOR INSTANCE
                //We check if all the identified nodes are a subset of the root method's nodes; if yes fully casualty combined with the fact we know
                //from refminer there was an inline
                boolean[] presenceNew = new boolean[casualtyChangedNodes.size()];

                compareUnits(casualtyChangedNodes, stringifiedRootUnits, presenceNew);

                boolean allTrueNew = allTrue(casualtyMethod.getSignature(), presenceNew, casualtyChangedNodes);

                if (presenceOld != null && allTrueNew && allTrueOld) {
                    System.out.println("old and new all casualty: " + casualtyMethodProcessed.getSignature());
                    results.add(casualtyMethodProcessed);
                }
                if (presenceOld == null && allTrueNew) {
                    System.out.println("new all casualty: " + casualtyMethodProcessed.getSignature());
                    results.add(casualtyMethodProcessed);
                }

            }

        }

        return results;
    }

    void writeFineGrainedCasualties(String signature, Set<Integer> lines) {

        outFineGrainedCasPWriter.write(signature + "#");
        for (Integer line : lines) {
            outFineGrainedCasPWriter.write(line + "#");
        }
        outFineGrainedCasPWriter.write(";");
    }

    boolean allTrue(String signature, boolean[] values, List<Unit> units) {
        boolean result = true;
        Set<Integer> lines = new HashSet<>();
        for (int i = 0; i < values.length; i++) {
            boolean value = values[i];
            if (!value && result) {
                result = false;
            } else if (value) {
                Unit unit = units.get(i);
                lines.add(unit.getJavaSourceStartLineNumber());
            }
        }
        if (lines.size() > 0 && outFineGrainedCasPWriter != null) {
            writeFineGrainedCasualties(signature, lines);
        }
        lineCount = lineCount + lines.size();

        return result;
    }

    void inlineMethodRootToCasualtyAnalysis(List<String> oldSootMethodsStringified,
                                            String key,
                                            List<Unit> casualtyChangedNodesNew, boolean[] presenceInNew,
                                            SootMethod oldCasualtyMethod,
                                            List<Unit> casualtyChangedNodesOld, boolean[] presenceInOld) throws IOException {
        ChangeUtil.setSootEnvironment(registrar.getFirstVersionClassPath());

        int rootIndex = oldSootMethodsStringified.indexOf(key);

        SootMethod rootMethod = ChangeUtil.getProcessedMethod(oldChangedSootMethods.get(rootIndex));

        //get the changes per each method
        PatchingChain<Unit> rootUnits = rootMethod.retrieveActiveBody().getUnits();
        List<String> stringifiedRootUnits = stringifyUnits(rootUnits);


        //IT HAS EVERYTHING EXCEPT FOR THE ARGUMENTS PASSED TO THE OLD METHOD AND SOME VIRTUAL INVOKATIONS FOR INSTANCE
        //We check if all the identified nodes are a subset of the root method's nodes; if yes fully casualty combined with the fact we know
        //from refminer there was an inline

        isCallToRoot(oldCasualtyMethod, casualtyChangedNodesOld, rootMethod, presenceInOld);

        ChangeUtil.setSootEnvironment(registrar.getSecondVersionClassPath());
        compareUnits(casualtyChangedNodesNew, stringifiedRootUnits, presenceInNew);

    }

    void inlineMethodRootToCasualtyAnalysis(List<String> oldSootMethodsStringified,
                                            String key,
                                            List<Unit> casualtyChangedNodesNew, boolean[] presenceInNew) throws IOException {

        int rootIndex = oldSootMethodsStringified.indexOf(key);

        SootMethod rootMethod = ChangeUtil.getProcessedMethod(oldChangedSootMethods.get(rootIndex));

        //get the changes per each method
        //List<Unit> rootChangedNodes = getChangedNodesPerMethod(rootIndex, rootMethod, true);
        PatchingChain<Unit> rootUnits = rootMethod.retrieveActiveBody().getUnits();
        List<String> stringifiedRootUnits = stringifyUnits(rootUnits);


        //IT HAS EVERYTHING EXCEPT FOR THE ARGUMENTS PASSED TO THE OLD METHOD AND SOME VIRTUAL INVOKATIONS FOR INSTANCE
        //We check if all the identified nodes are a subset of the root method's nodes; if yes fully casualty combined with the fact we know
        //from refminer there was an inline

        compareUnits(casualtyChangedNodesNew, stringifiedRootUnits, presenceInNew);
    }

    SootMethod getOldSootMethod(SootMethod sootMethod) {
        //  G.reset();
        ChangeUtil.setSootEnvironment(registrar.getFirstVersionClassPath());

        SootClass sootClass = Scene.v().loadClassAndSupport(sootMethod.getDeclaringClass().toString());
        sootClass.setApplicationClass();
        Scene.v().loadNecessaryClasses();


        if (oldStringifiedMethods.size() != oldChangedSootMethods.size()) {
            for (SootMethod sootMethod1 : oldChangedSootMethods) {
                oldStringifiedMethods.add(sootMethod1.getSignature());
            }
        }


        if (oldStringifiedMethods.contains(sootMethod.getSignature())) {
            int index = oldStringifiedMethods.indexOf(sootMethod.getSignature());
            return oldChangedSootMethods.get(index);
        }

        return null;
    }


    void compareUnits(List<Unit> units, List<String> stringifiedUnits, boolean[] similar) {

        for (int i = 0; i < units.size(); i++) {
            Unit unit = units.get(i);

            //just getting the string values doesn't work since soot has those personalized register names for intermediary variables
            //we need types and strip out those registry names
            String stringifiedUnit = stringifyUnit(unit);
            similar[i] = stringifiedUnits.contains(stringifiedUnit);

        }
    }

    Set<SootMethod> extractMethodRootToCasualtyAnalysis(HashMap<String, List<String>> extractMethodRootToCasualties, List<String> newSootMethodsStringified) throws IOException {
        Set<SootMethod> results = new HashSet<>();
        for (String key : extractMethodRootToCasualties.keySet()) {

            //when we analyze the old methods, we need to reset the classpath to the new version since the analysis of old ones changes the classpath

            ChangeUtil.setSootEnvironment(registrar.getSecondVersionClassPath());

            List<String> casualtyMethods = extractMethodRootToCasualties.get(key);
            int rootIndex = newSootMethodsStringified.indexOf(key);

            SootMethod rootMethod = ChangeUtil.getProcessedMethod(newChangedSootMethods.get(rootIndex));


            //get the changes per each method
            //List<Unit> rootChangedNodes = getChangedNodesPerMethod(rootIndex, rootMethod, true);
            PatchingChain<Unit> rootUnits = rootMethod.retrieveActiveBody().getUnits();
            List<String> stringifiedRootUnits = stringifyUnits(rootUnits);


            for (int i = 0; i < casualtyMethods.size(); i++) {
                String casualty = casualtyMethods.get(i);
                int casualtyIndex = newSootMethodsStringified.indexOf(casualty);
                ChangeUtil.setSootEnvironment(registrar.getSecondVersionClassPath());
                SootMethod casualtyMethod = ChangeUtil.getProcessedMethod(newChangedSootMethods.get(casualtyIndex));


                List<Unit> casualtyChangedNodes = getChangedNodesPerMethod(casualtyIndex, casualtyMethod, false);


                boolean[] presenceInNew = new boolean[casualtyChangedNodes.size()];
                isCallToRoot(casualtyMethod, casualtyChangedNodes, rootMethod, presenceInNew);
                boolean allCasualtyNew = allTrue(casualtyMethod.getSignature(), presenceInNew, casualtyChangedNodes);
                if (allCasualtyNew) {
                    System.out.println("new all casualty: " + casualtyMethod.getSignature());
                }



                SootMethod oldSootMethod = getOldSootMethod(casualtyMethod);
                if (oldSootMethod != null) {
                    ChangeUtil.setSootEnvironment(registrar.getFirstVersionClassPath());
                    oldSootMethod = ChangeUtil.getProcessedMethod(oldSootMethod);
                    int index = oldStringifiedMethods.indexOf(oldSootMethod.getSignature());

                    List<Unit> oldMethodChangedNodes = getChangedNodesPerMethod(index, oldSootMethod, true);
                    boolean[] presenceOld = new boolean[oldMethodChangedNodes.size()];

                    compareUnits(oldMethodChangedNodes, stringifiedRootUnits, presenceOld);
                    boolean allCasualtyOld = allTrue(oldSootMethod.getSignature(), presenceOld, oldMethodChangedNodes);
                    if (allCasualtyNew && allCasualtyOld) {
                        System.out.println("new and old all casualty: " + casualtyMethod.getSignature());
                        results.add(casualtyMethod);
                    }
                } else {
                    if (allCasualtyNew) {
                        results.add(casualtyMethod);
                    }
                }

            }
            }

        return results;

    }


    void extractMethodRootToCasualtyAnalysis(String key, List<String> newSootMethodsStringified,
                                             SootMethod casualtyMethod,
                                             List<Unit> casualtyChangedNodes,
                                             List<Unit> oldMethodChangedNodes,
                                             boolean[] presenceInNew,
                                             boolean[] presenceInOld) {

        ChangeUtil.setSootEnvironment(registrar.getFirstVersionClassPath());

        int rootIndex = newSootMethodsStringified.indexOf(key);

        SootMethod rootMethod = ChangeUtil.getProcessedMethod(newChangedSootMethods.get(rootIndex));


        //get the changes per each method
        //List<Unit> rootChangedNodes = getChangedNodesPerMethod(rootIndex, rootMethod, true);
        PatchingChain<Unit> rootUnits = rootMethod.retrieveActiveBody().getUnits();
        List<String> stringifiedRootUnits = stringifyUnits(rootUnits);

        compareUnits(oldMethodChangedNodes, stringifiedRootUnits, presenceInOld);

        ChangeUtil.setSootEnvironment(registrar.getSecondVersionClassPath());

        isCallToRoot(casualtyMethod, casualtyChangedNodes, rootMethod, presenceInNew);
    }

    void extractMethodRootToCasualtyAnalysis(String key,
                                             List<String> newSootMethodsStringified,
                                             SootMethod casualtyMethod,
                                             List<Unit> casualtyChangedNodes,
                                             boolean[] presenceInNew
    ) {

        ChangeUtil.setSootEnvironment(registrar.getFirstVersionClassPath());

        int rootIndex = newSootMethodsStringified.indexOf(key);

        SootMethod rootMethod = ChangeUtil.getProcessedMethod(newChangedSootMethods.get(rootIndex));

        ChangeUtil.setSootEnvironment(registrar.getSecondVersionClassPath());

        isCallToRoot(casualtyMethod, casualtyChangedNodes, rootMethod, presenceInNew);
    }


    void isCallToRoot(SootMethod casualtyMethod, List<Unit> units, SootMethod rootMethod, boolean[] presence) {
        boolean call = false;
        int index = -1;

        ChangeUtil changeUtil = new ChangeUtil();

        for (int i = 0; i < units.size(); i++) {
            Unit unit = units.get(i);
            if (unit instanceof InvokeStmt) {
                InvokeStmt invokeStmt = (InvokeStmt) unit;
                if (changeUtil.checkInvokeStmt(invokeStmt, rootMethod)) {
                    call = true;
                    index = i;
                    presence[i] = true;
                    break;

                }
            }

            if (unit instanceof AssignStmt) {
                AssignStmt assignStmt = (AssignStmt) unit;
                if (changeUtil.checkAssignStmt(assignStmt, rootMethod)) {
                    call = true;
                    index = i;
                    presence[i] = true;
                    break;
                }
            }

        }

        if (call) {
            Unit callingUnit = units.get(index);

            InterProceduralPDG interProceduralPDG = new InterProceduralPDG();
            interProceduralPDG.run(casualtyMethod.getDeclaringClass().getName(), casualtyMethod);


            for (int i = 0; i < units.size(); i++) {
                if (i != index) {
                    presence[i] = ChangeUtil.areEdgesConnectedThroughDataFlow(interProceduralPDG.getInterProceduralPDG(), callingUnit, units.get(i));
                }
            }


        }


    }

    String stringifyUnit(Unit unit) {
        if (unit instanceof AssignStmt) {
            AssignStmt assignStmt = (AssignStmt) unit;
            Value rightOp = assignStmt.getRightOp();
            if (rightOp instanceof InvokeExpr) {
                InvokeExpr invokeExpr = (InvokeExpr) rightOp;
                String argTypes = "";
                List<Value> args = invokeExpr.getArgs();
                for (Value arg : args) {
                    argTypes += arg.getType().toString();
                }

                return assignStmt.getClass() + "@" + invokeExpr.getMethodRef() + "#" + invokeExpr.getArgCount() + argTypes;
            }
            return assignStmt.getClass() + "@" + rightOp.toString();

        }
        if (unit instanceof JInvokeStmt) {
            JInvokeStmt jInvokeStmt = (JInvokeStmt) unit;
            InvokeExpr invokeExpr = jInvokeStmt.getInvokeExpr();
            String argTypes = "";
            List<Value> args = invokeExpr.getArgs();
            for (Value arg : args) {
                argTypes += arg.getType().toString();
            }

            return removeSootNames(jInvokeStmt.getClass().toString() + "@" + invokeExpr.getMethodRef() + "#" + invokeExpr.getArgCount() + argTypes);
        }

        if (unit instanceof InvokeExpr) {
            InvokeExpr invokeExpr = (InvokeExpr) unit;
            String argTypes = "";
            List<Value> args = invokeExpr.getArgs();
            for (Value arg : args) {
                argTypes += arg.getType().toString();
            }

            return removeSootNames(invokeExpr.getMethodRef() + "#" + invokeExpr.getArgCount() + argTypes);

        }

        if (unit instanceof IfStmt) {
            IfStmt ifStmt = (IfStmt) unit;
            String condition = ifStmt.getCondition().toString();

            //the goto statement sometimes is not the same
            //TODO need to handle this better though;
            return removeSootNames(ifStmt.getClass() + "@" + condition);
        }

        return removeSootNames(unit.toString());

    }

    /**
     * soot names variables with its own registry names
     * this harms the comparison between the units in two different methods, that's why we remove them
     *
     * @param name
     * @return
     */
    public String removeSootNames(String name) {
        String result = name;
        Matcher matcher = Pattern.compile("\\$([rz])\\d{1,2}").matcher(name);
        while (matcher.find()) {
            String match = "\\" + matcher.group(0);
            result = result.replaceAll(match, "");
        }
        return result;
    }

    List<String> stringifyUnits(PatchingChain<Unit> units) {
        List<String> results = new ArrayList<>();

        //stringifyUnits based on their type
        for (Unit unit : units) {
            results.add(stringifyUnit(unit));
        }
        return results;
    }




    private List<Unit> getChangedNodesPerMethod(int index, SootMethod method, boolean old) throws IOException {
        String gumtreeClassname = ChangeUtil.getGumtreeClassnameFromSoot(method);
        List<ITree> changedGumtreeMethods = old ? oldChangedGumtreeMethods : newChangedGumtreeMethods;
        LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClass = old ? changesPerMethodInClassOld : changesPerMethodInClassNew;


        int fileNo = SootUtilities.findFileNo(registrar.getFiles(), gumtreeClassname);
        fileNo = ChangeUtil.determineFileNo(old, fileNo);

        TreeContext treeContext = Generators.getInstance().getTree(registrar.getFiles()[fileNo]);
        ITree methodDeclaration = changedGumtreeMethods.get(index);
        String methodKey = SootUtilities.getMethodName(methodDeclaration, treeContext) + ": " + methodDeclaration.getPos();

        List<ITree> rootNodes = new ArrayList<>();

        if (changesPerMethodInClass.containsKey(fileNo) && changesPerMethodInClass.get(fileNo).containsKey(methodKey)) {
            rootNodes = changesPerMethodInClass.get(fileNo).get(methodKey);
        }

//        ChangeUtil.setSootEnvironment(classPath);
//        SootClass sootClass = Scene.v().loadClassAndSupport(method.getDeclaringClass().toString());
//        sootClass.setApplicationClass();
        // method = ChangeUtil.getSootMethod(method, sootClass);

        return ChangeUtil.convertToUnit(method, rootNodes, treeContext);
    }


    private List<String> findIntersection(List<String> firstList, List<String> secondList) {
        List<String> results = new ArrayList<>();
        boolean[] visited = new boolean[secondList.size()];
        outter:
        for (String firstElem : firstList) {
            for (int i = 0; i < secondList.size(); i++) {
                String secondElem = secondList.get(i);

                if (!visited[i]) {
                    if (firstElem.equalsIgnoreCase(secondElem)) {
                        results.add(secondElem);
                        visited[i] = true;
                        continue outter;
                    }
                }

            }
        }

        return results;
    }


    private HashMap<String, List<String>> analyzeExtractMethodRefs(HashMap<UMLOperation, List<UMLOperation>> rootToCasualtyChanges,
                                                                   List<String> newSootMethodsStringified) {
        HashMap<String, List<String>> casualties = new HashMap<>();
        for (UMLOperation rootChange : rootToCasualtyChanges.keySet()) {


            String rMinerRootMethod = rootChange.codeRange().getCodeElement();
            if (rMinerRootMethod == null) {
                rMinerRootMethod = rootChange.toString();
            }
            String standardizedRMinerRootMethod = stringifyRMinerMethod(rMinerRootMethod, rootChange.getClassName());

            if (newSootMethodsStringified.contains(standardizedRMinerRootMethod)) {

                List<UMLOperation> casualtyChanges = rootToCasualtyChanges.get(rootChange);
                for (UMLOperation casualtyChange : casualtyChanges) {
                    String rMinerCasualtyMethod = casualtyChange.codeRange().getCodeElement();
                    if (rMinerCasualtyMethod == null) {
                        rMinerCasualtyMethod = casualtyChange.toString();
                    }

                    String standardizedRMinerCasualtyMethod = stringifyRMinerMethod(rMinerCasualtyMethod, casualtyChange.getClassName());

                    if (newSootMethodsStringified.contains(standardizedRMinerCasualtyMethod)) {
                        addToSootRootMap(casualties, standardizedRMinerRootMethod, standardizedRMinerCasualtyMethod);
                    }

                    //confirmed that it works
                    //TODO: write a test
//                if (newSootMethodsStringified.contains(standardizedRMinerCasualtyMethod)) {
//                    System.out.println("rminer soot casualty change match");
//                } else {
//                    System.out.println("no match! " + standardizedRMinerCasualtyMethod);
//                }
                    if (!newSootMethodsStringified.contains(standardizedRMinerCasualtyMethod)) {
                        logger.log(Level.INFO, "No match found: " + standardizedRMinerCasualtyMethod + " in " + newSootMethodsStringified.toString());
                    }
                }
            }


        }

        return casualties;
    }

    /**
     * utility function to add to a map
     *
     * @param map
     * @param key
     * @param value
     */
    private void addToSootRootMap(HashMap<String, List<String>> map, String key, String value) {
        if (map.containsKey(key) && !map.get(key).contains(value)) {
            map.get(key).add(value);
            return;
        }

        List<String> values = new ArrayList<>();
        values.add(value);

        map.put(key, values);
    }

    private HashMap<String, List<String>> analyzeInlineMethodRefs(HashMap<UMLOperation, List<UMLOperation>> rootToCasualtyChanges, List<String> oldSootMethodsStringified,
                                                                  List<String> newSootMethodsStringified) {

        HashMap<String, List<String>> casualties = new HashMap<>();
        for (UMLOperation rootChange : rootToCasualtyChanges.keySet()) {

            String rMinerRootMethod = rootChange.codeRange().getCodeElement();
            if (rMinerRootMethod == null) {
                rMinerRootMethod = rootChange.toString();
            }
            String standardizedRMinerRootMethod = stringifyRMinerMethod(rMinerRootMethod, rootChange.getClassName());

            if (oldSootMethodsStringified.contains(standardizedRMinerRootMethod)) {


                List<UMLOperation> casualtyChanges = rootToCasualtyChanges.get(rootChange);
                for (UMLOperation casualtyChange : casualtyChanges) {
                    String rMinerCasualtyMethod = casualtyChange.codeRange().getCodeElement();
                    if (rMinerCasualtyMethod == null) {
                        rMinerCasualtyMethod = casualtyChange.toString();
                    }

                    String standardizedRMinerCasualtyMethod = stringifyRMinerMethod(rMinerCasualtyMethod, casualtyChange.getClassName());

                    if (newSootMethodsStringified.contains(standardizedRMinerCasualtyMethod)) {
                        addToSootRootMap(casualties, standardizedRMinerRootMethod, standardizedRMinerCasualtyMethod);
                    } else {

                        logger.log(Level.INFO, "No match found: " + standardizedRMinerCasualtyMethod + " in " + newSootMethodsStringified.toString());

                    }
                }
            } else {
                logger.log(Level.INFO, "No match found: " + standardizedRMinerRootMethod + " in " + oldSootMethodsStringified.toString());

            }


        }

        return casualties;
    }

    /**
     * utitlity function to get the standardized signature of the rminer method
     * to be used in comparing the results of rminer with soot
     * @param rMinerMethod
     * @return
     */

    /**
     * @param rMinerMethod
     * @return
     */
    public String stringifyRMinerMethod(String rMinerMethod, String className) {
        String[] signatureSplit = rMinerMethod.split("\\s(?![^\\(\\)]*\\))");
        String[] signatureInfo = Arrays.stream(signatureSplit).filter(value -> value != null && value.length() > 0).toArray(String[]::new);
        StringBuilder rebuiltName = null;
        try {
            if (signatureInfo.length == 4) {
                String[] methodSplit = signatureInfo[1].split("\\(|\\s|,");
                String[] methodInfo = Arrays.stream(methodSplit).filter(value -> value != null && value.length() > 0).toArray(String[]::new);
                rebuiltName = new StringBuilder(className + " " + signatureInfo[3] + " " + methodInfo[0] + "(");
                for (int i = 1; i < methodInfo.length; i++) {
                    if (i % 2 == 0) {
                        rebuiltName.append(methodInfo[i]);
                        if (i != methodInfo.length - 1) {
                            rebuiltName.append(",");
                        }
                    }
                }
            } else {
                if (DEBUG)
                    logger.log(Level.INFO, "Signature: " + rMinerMethod + " not of length 4! " +
                            Arrays.toString(signatureSplit));
            }

            String result = rebuiltName.toString();
            if (!result.endsWith(")")) {
                result += ")";
            }

            return result;
        } catch (NullPointerException noe) {
            System.out.println("Null Pointer Exception: " + Arrays.toString(noe.getStackTrace()));
            logger.log(Level.INFO, "Null Pointer Exception: " + Arrays.toString(noe.getStackTrace()));
        }

        return null;
    }

    /**
     * utitlity function to get the standardized signature of the soot methods
     * to be used in comparing the results of RMiner with soot
     *
     * @return
     */
    public List<String> stringifySootMethods(List<SootMethod> sootMethods) {
        List<String> standardizeSootMethods = new ArrayList<>();
        for (SootMethod sootMethod : sootMethods) {
            String result = stringifySootMethod(sootMethod);
            if (result != null) {
                standardizeSootMethods.add(result);
            }
        }

        return standardizeSootMethods;
    }

    /**
     * TODO: wrote an example above the code to explain all steps
     * standardize each method separately
     */

    public String stringifySootMethod(SootMethod sootMethod) {
        String signature = sootMethod.getSignature().replaceAll("<", "").replaceAll(">", "");

        String[] signatureSplit = signature.split("\\s");
        String[] signatureInfo = Arrays.stream(signatureSplit).filter(value -> value != null && value.length() > 0).toArray(String[]::new);
        StringBuilder rebuiltName = null;
        try {
            if (signatureInfo.length == 3) {
                String[] methodInfo = signatureInfo[2].split("\\(|\\s|,");

                String[] modifiers = signatureInfo[1].split("\\.");

                rebuiltName = new StringBuilder(sootMethod.getDeclaringClass().toString() + " " + modifiers[modifiers.length - 1] + " " + methodInfo[0] + "(");
                for (int i = 1; i < methodInfo.length; i++) {
                    String[] paramInfo = methodInfo[i].split("\\.");
                    String param = paramInfo[paramInfo.length - 1];

                    rebuiltName.append(param);
                    if (i != methodInfo.length - 1) {
                        rebuiltName.append(',');
                    }
                }


            } else {
                if (DEBUG)
                    logger.log(Level.INFO, "Signature: " + signature + " not of length 3! " + Arrays.toString(signatureSplit));
            }

            String result = rebuiltName.toString();
            return result;
        } catch (NullPointerException noe) {
            System.out.println(Arrays.toString(noe.getStackTrace()));
            logger.log(Level.INFO, "Null Pointer Exception: " + Arrays.toString(noe.getStackTrace()));
        }

        return null;

    }

    /**
     * get refactoring activities of interest that happened in the patch
     * type, root change, casualty change represented as UMLOperation, RMiner's object
     */
    public HashMap<RefactoringType, HashMap<UMLOperation, List<UMLOperation>>> getRefactorings() {
        HashMap<RefactoringType, HashMap<UMLOperation, List<UMLOperation>>> refactoringsMap = new HashMap<>();

        String[] files = registrar.getFiles();
        //added check for name of system being included in the lsit of files
        //TODO: clean up the input file

        if (files.length % 2 != 0) {
            files = Arrays.copyOfRange(files, 0, files.length - 1);
        }
        for (int i = 0; i < files.length; i += 2) {
            String[] info1 = getJavaClassName(files[i]);
            String[] info2 = getJavaClassName(files[i + 1]);


            try {
                List<String> files1 = new ArrayList<>();
                files1.add(info1[1]);
                List<String> files2 = new ArrayList<>();
                files2.add(info2[1]);
                UMLModel model1 = new UMLModelASTReader(new File(info1[0]), files1).getUmlModel();
                UMLModel model2 = new UMLModelASTReader(new File(info2[0]), files2).getUmlModel();
                UMLModelDiff modelDiff = model1.diff(model2);
                List<Refactoring> refactorings = modelDiff.getRefactorings();


                for (Refactoring refactoring : refactorings) {


                    if (refactoring instanceof InlineOperationRefactoring) {
                        HashMap<UMLOperation, List<UMLOperation>> refactoringsPerType = new HashMap<>();
                        if (refactoringsMap.containsKey(RefactoringType.INLINE_METHOD)) {
                            refactoringsPerType = refactoringsMap.get(RefactoringType.INLINE_METHOD);
                        }
                        InlineOperationRefactoring inlineOperationRefactoring = (InlineOperationRefactoring) refactoring;
                        UMLOperation rootChange = inlineOperationRefactoring.getInlinedOperation();

                        UMLOperation casualtyChange = inlineOperationRefactoring.getTargetOperationAfterInline();

                        addToRootToCasMap(refactoringsPerType, rootChange, casualtyChange);
                        refactoringsMap.put(RefactoringType.INLINE_METHOD, refactoringsPerType);


                    } else if (refactoring instanceof ExtractOperationRefactoring) {
                        HashMap<UMLOperation, List<UMLOperation>> refactoringsPerType = new HashMap<>();
                        if (refactoringsMap.containsKey(RefactoringType.EXTRACT_METHOD)) {
                            refactoringsPerType = refactoringsMap.get(RefactoringType.EXTRACT_METHOD);
                        }
                        ExtractOperationRefactoring extractOperationRefactoring = (ExtractOperationRefactoring) refactoring;
                        UMLOperation rootChange = extractOperationRefactoring.getExtractedOperation();

                        UMLOperation casualtyChange = extractOperationRefactoring.getSourceOperationAfterExtraction();

                        addToRootToCasMap(refactoringsPerType, rootChange, casualtyChange);
                        refactoringsMap.put(RefactoringType.EXTRACT_METHOD, refactoringsPerType);

                    }

                }

            } catch (ArrayIndexOutOfBoundsException | RefactoringMinerTimedOutException | IOException aoe) {
                System.out.println(Arrays.toString(aoe.getStackTrace()));
                logger.log(Level.INFO, " Exception: " + Arrays.toString(aoe.getStackTrace()));

            }
        }

        return refactoringsMap;
    }

    public void addToRootToCasMap(HashMap<UMLOperation, List<UMLOperation>> map, UMLOperation key, UMLOperation value) {
        if (map.containsKey(key) && !map.get(key).contains(value)) {
            map.get(key).add(value);
            return;
        }
        List<UMLOperation> values = new ArrayList<>();
        values.add(value);

        map.put(key, values);
    }

    private String[] getJavaClassName(String filePath) {
        int indexOfSlash = filePath.lastIndexOf(File.separator);
        String path = filePath.substring(0, indexOfSlash + 1);
        String name = filePath.substring(indexOfSlash + 1);

        return new String[]{path, name};
    }

    public void setOutSystemPWriter(PrintWriter outSystemPWriter) {
        this.outSystemPWriter = outSystemPWriter;
    }

    public void setOutCausPWriter(PrintWriter outCausPWriter) {
        this.outCausPWriter = outCausPWriter;
    }

    public void setOutFineGrainedCasPWriter(PrintWriter outFineGrainedCasPWriter) {
        this.outFineGrainedCasPWriter = outFineGrainedCasPWriter;
    }

    public int getLineCount() {
        return lineCount;
    }
}
