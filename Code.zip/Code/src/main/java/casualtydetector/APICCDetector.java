package casualtydetector;

import com.github.gumtreediff.tree.ITree;
import fixdetector.ChangedNodesIdentifier;
import javafx.util.Pair;
import org.apache.commons.collections4.BidiMap;
import soot.G;
import soot.SootMethod;
import util.ChangeUtil;
import util.DirectedGraph;
import util.Registrar;
import util.SootUtilities;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.logging.Level;

import static util.Constants.logger;

public class APICCDetector implements CasualtyChangeDetector{
    PrintWriter outSystemPWriter;
    PrintWriter outCausPWriter;
    PrintWriter outCausFineGrainedPWriter;

    //data object that holds info contained in each row in the input file
    Registrar registrar;

    List<SootMethod> newChangedSootMethods;
    List<SootMethod> oldChangedSootMethods;

    List<ITree> newChangedGumtreeMethods;
    List<ITree> oldChangedGumtreeMethods;


    List<SootMethod> newCasualtyMethods;
    List<SootMethod> oldCasualtyMethods;

    HashMap<String, List<ITree>> methodToITreeChangesOld;
    HashMap<String, List<ITree>> methodToITreeChangesNew;


    APICCCharacterizer apiccCharacterizer;
    int lineCount;



    @Override
    public void run(ChangedNodesIdentifier changedNodesIdentifier, Registrar registrar) throws IOException {
        this.registrar = registrar;
        int type = registrar.getType();
        List<Pair<Integer, ITree>> apiChangesNew = changedNodesIdentifier.getApiChangesNew();
        List<Pair<Integer, ITree>> apiChangesOld = changedNodesIdentifier.getApiChangesOld();

        System.out.println("option " + type + "processing");

        outSystemPWriter.write(registrar.getRevNumber() + " " + registrar.getSystemName() + "\n");
        boolean proceed = (apiChangesNew.size() > 0 || apiChangesOld.size() > 0);


        if (proceed) {

            initializeCasualtyRelatedVariables();
            LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassNew = changedNodesIdentifier.getChangesPerMethodInClassNew();
            LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassOld = changedNodesIdentifier.getChangesPerMethodInClassOld();
            SootUnitProxy sootUnitProxy = new SootUnitProxy();
            if (outCausFineGrainedPWriter != null) {
                apiccCharacterizer = new APICCCharacterizer(registrar, changesPerMethodInClassNew, changesPerMethodInClassOld, outCausFineGrainedPWriter);
            } else {
                apiccCharacterizer = new APICCCharacterizer(registrar, changesPerMethodInClassNew, changesPerMethodInClassOld);

            }
            if (apiChangesNew.size() > 0) {

                newCasualtyMethods = getCasualtyChanges(changedNodesIdentifier,
                        apiChangesNew, sootUnitProxy, false, false);
            }
            if (apiChangesOld.size() > 0) {

                oldCasualtyMethods = getCasualtyChanges(changedNodesIdentifier,
                        apiChangesOld, sootUnitProxy, true, false);

            }
//            if (changedNodesIdentifier.getNewNodes().size() == 0 && changedNodesIdentifier.getOldNodes().size() == 0) {
//                logger.log(Level.INFO, "No nodes found.");
//            }
            List<SootMethod> finalCasualtyChangesOnly = findCasualtyOnlyMethods(changedNodesIdentifier);
            writeCasualtiesToFile(finalCasualtyChangesOnly);

            lineCount = apiccCharacterizer.lineCount;




        }
        if(apiChangesNew.size()==0 && apiChangesOld.size()==0){
            logger.log(Level.INFO, "No API changes were found.");
        }
        writeNewLineToFiles();
    }

    /**
     * this method is used in cases when all changes are requested so that we do not repeat calculations twice
     * @param changedNodesIdentifier
     * @param registrar
     * @param newChangedSootMethods
     * @param oldChangedSootMethods
     * @param newChangedGumtreeMethods
     * @param oldChangedGumtreeMethods
     * @throws IOException
     */
    public void run(ChangedNodesIdentifier changedNodesIdentifier, Registrar registrar,
                    List<SootMethod> newChangedSootMethods, List<SootMethod> oldChangedSootMethods,
                    List<ITree> newChangedGumtreeMethods, List<ITree> oldChangedGumtreeMethods) throws IOException {
        this.registrar = registrar;

        int type = registrar.getType();
        List<Pair<Integer, ITree>> apiChangesNew = changedNodesIdentifier.getApiChangesNew();
        List<Pair<Integer, ITree>> apiChangesOld = changedNodesIdentifier.getApiChangesOld();
        boolean proceed;
        System.out.println("option " + type + "processing");

        proceed = (apiChangesNew.size() > 0 || apiChangesOld.size() > 0);


        if (proceed) {

            initializeCasualtyRelatedVariables();
            setSootMethods(newChangedSootMethods, oldChangedSootMethods, newChangedGumtreeMethods, oldChangedGumtreeMethods);
            LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassNew = changedNodesIdentifier.getChangesPerMethodInClassNew();
            LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassOld = changedNodesIdentifier.getChangesPerMethodInClassOld();
            SootUnitProxy sootUnitProxy = new SootUnitProxy();
            apiccCharacterizer = new APICCCharacterizer(registrar, changesPerMethodInClassNew, changesPerMethodInClassOld);
            if (apiChangesNew.size() > 0) {

                newCasualtyMethods = getCasualtyChanges(changedNodesIdentifier,
                        apiChangesNew, sootUnitProxy, false, true);
            }
            if (apiChangesOld.size() > 0) {

                oldCasualtyMethods = getCasualtyChanges(changedNodesIdentifier,
                        apiChangesOld, sootUnitProxy, true, true);

            }
            //THIS NEEDS TO BE DONE WITH THE USAGE OF THE HASHMAPS NOW
//            if (changedNodesIdentifier.getNewNodes().size() == 0 && changedNodesIdentifier.getOldNodes().size() == 0) {
//                logger.log(Level.INFO, "No nodes found.");
//            }
            List<SootMethod> finalCasualtyChangesOnly = findCasualtyOnlyMethods(changedNodesIdentifier);
            writeCasualtiesToFile(finalCasualtyChangesOnly);


            lineCount = apiccCharacterizer.lineCount;

        }
        if(apiChangesNew.size()==0 && apiChangesOld.size()==0){
            logger.log(Level.INFO, "No API changes were found.");
        }
        writeNewLineToFiles();

    }

    private void setSootMethods(List<SootMethod> newChangedSootMethods,
                                List<SootMethod> oldChangedSootMethods,
                                List<ITree> newChangedGumtreeMethods,
                                List<ITree> oldChangedGumtreeMethods) {
        this.newChangedSootMethods = newChangedSootMethods;
        this.oldChangedSootMethods = oldChangedSootMethods;
        this.newChangedGumtreeMethods = newChangedGumtreeMethods;
        this.oldChangedGumtreeMethods = oldChangedGumtreeMethods;
    }

    private void initializeCasualtyRelatedVariables(){
        newChangedSootMethods = new ArrayList<>();
        oldChangedSootMethods = new ArrayList<>();

        newChangedGumtreeMethods = new ArrayList<>();
        oldChangedGumtreeMethods = new ArrayList<>();


        newCasualtyMethods = new ArrayList<>();
        oldCasualtyMethods= new ArrayList<>();

        methodToITreeChangesOld= new HashMap<>();
        methodToITreeChangesNew= new HashMap<>();
    }

    private void writeNewLineToFiles() {
        outCausPWriter.write('\n');
        outSystemPWriter.write('\n');

        if (outCausFineGrainedPWriter != null)
            outCausFineGrainedPWriter.write('\n');
    }


    private void writeCasualtiesToFile(List<SootMethod> finalCasualtyChangesOnly) {
        for (SootMethod sootMethod : finalCasualtyChangesOnly) {
            outCausPWriter.write(sootMethod.getSignature() + ";");
        }
    }

    /**
     * this method is used to find methods that *solely* contain casualty changes
     * @param changedNodesIdentifier

     * @return
     * @throws IOException
     */
    private List<SootMethod> findCasualtyOnlyMethods(ChangedNodesIdentifier changedNodesIdentifier) throws IOException {

        BidiMap<SootMethod, SootMethod> sootMethodHashMap = ChangeUtil.checkOverlap(
                oldChangedSootMethods, oldChangedGumtreeMethods, newChangedSootMethods, newChangedGumtreeMethods,
                registrar.getFiles(), changedNodesIdentifier.mappingStores);
        List<String> overlapCovered = new ArrayList<>();
        List<SootMethod> finalCasualtyChangesOnly = new ArrayList<>();
        getOverlapingCasualtyMethods(sootMethodHashMap, overlapCovered, finalCasualtyChangesOnly);

        List<SootMethod> filteredCasualtyOld = ChangeUtil.removeListFromList(oldCasualtyMethods, overlapCovered);
        List<SootMethod> filteredCasualtyNew = ChangeUtil.removeListFromList(newCasualtyMethods, overlapCovered);

        List<ITree> filteredGumTreeOld = ChangeUtil.filterList(oldChangedSootMethods, filteredCasualtyOld, oldChangedGumtreeMethods);

        List<SootMethod> oldCasualtyChangesFinal = apiccCharacterizer.propagateCasualtyChanges(filteredCasualtyOld,
                filteredGumTreeOld, true);

        finalCasualtyChangesOnly.addAll(oldCasualtyChangesFinal);

        List<ITree> filteredGumTreeNew = ChangeUtil.filterList(newChangedSootMethods, filteredCasualtyNew, newChangedGumtreeMethods);

        List<SootMethod> newCasualtyChangesFinal = apiccCharacterizer.propagateCasualtyChanges(filteredCasualtyNew,
                filteredGumTreeNew, false);

        List<ITree> filterGumTreeNewFinal = ChangeUtil.filterList(filteredCasualtyNew, newCasualtyChangesFinal, filteredGumTreeNew);

        G.reset();
        SootUtilities.setUpSootEnvironment(registrar.getFirstVersionClassPath());

        List<SootMethod> mappedNewToOld = ChangeUtil.getMappedSootMethod(filterGumTreeNewFinal, newCasualtyChangesFinal, registrar.getFiles(), changedNodesIdentifier.mappingStores);
        finalCasualtyChangesOnly.addAll(mappedNewToOld);
        return finalCasualtyChangesOnly;
    }

    private void getOverlapingCasualtyMethods(BidiMap<SootMethod, SootMethod> sootMethodHashMap, List<String> overlapCovered, List<SootMethod> finalCasualtyChangesOnly) throws IOException {
        for (SootMethod sootMethod1 : sootMethodHashMap.keySet()) {

            SootMethod sootMethod2 = sootMethodHashMap.get(sootMethod1);
            if (oldCasualtyMethods.contains(sootMethod1) && newCasualtyMethods.contains(sootMethod2)) {
                int index1 = oldChangedSootMethods.indexOf(sootMethod1);
                ITree gumTree1 = oldChangedGumtreeMethods.get(index1);

                int index2 = newChangedSootMethods.indexOf(sootMethod2);
                ITree gumTree2 = newChangedGumtreeMethods.get(index2);


                boolean covered = apiccCharacterizer.propagateCasualtyChangesOverlap(sootMethod1, sootMethod2, gumTree1, gumTree2);

                if (covered) {
                    outCausPWriter.write(sootMethod1.getSignature() + ";");
                    finalCasualtyChangesOnly.add(sootMethod1);
                }
            }


            overlapCovered.add(sootMethod1.getSignature());
            overlapCovered.add(sootMethod2.getSignature());
        }
    }

    private List<SootMethod> getCasualtyChanges(ChangedNodesIdentifier changedNodesIdentifier,
                                                List<Pair<Integer, ITree>> apiChanges,
                                                SootUnitProxy sootUnitProxy,
                                                boolean old, boolean sootCalculationFinished) throws IOException {

        String classPath = old ? registrar.getFirstVersionClassPath() : registrar.getSecondVersionClassPath();
        String prefix = old ? registrar.getFirstPrefix(): registrar.getSecondPrefix();
        List<SootMethod>  changedSootMethods = old ? oldChangedSootMethods: newChangedSootMethods;
        List<ITree> changedGumtreeMethods = old ? oldChangedGumtreeMethods: newChangedGumtreeMethods;
        HashMap<String, List<ITree>> methodToITreeChanges = old? methodToITreeChangesOld: methodToITreeChangesNew;
        LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethondInClass = old ? changedNodesIdentifier.changesPerMethodInClassOld : changedNodesIdentifier.getChangesPerMethodInClassNew();

        List<SootMethod> casualtyMethods = new ArrayList<>();

        if(!sootCalculationFinished) {
            sootUnitProxy.getChangedSootMethods(classPath,
                    prefix, changedSootMethods, changedGumtreeMethods, changesPerMethondInClass, registrar.getFiles(), registrar.getType());
        }

        if (apiChanges.size() > 0) {

            //SootUtilities.setUpSootEnvironment(classPath);
            ChangeUtil.setSootEnvironment(classPath);


            List<String> rootChanges = apiccCharacterizer.findRootChanges(apiChanges, old);
            if (rootChanges.size() > 0) {
                ChangeUtil changeUtil1 = new ChangeUtil();
                Pair<DirectedGraph, BidiMap<String, Integer>> directedGraphBidiMapPair = changeUtil1.buildMethodGraph(changedSootMethods);
                DirectedGraph allChangedMethodsGraph = directedGraphBidiMapPair.getKey();
                allChangedMethodsGraph.reachability();
                HashMap<SootMethod, List<String>> changesToNeighbors = ChangeUtil.getMethodsReachedByRootChange(rootChanges, changedSootMethods, directedGraphBidiMapPair);

                List<ITree> deletedMethodInvocations = changedNodesIdentifier.getDeletedMethodInvocations();
                List<ITree> insertedMethodInvocations = changedNodesIdentifier.getInsertedMethodInvocations();


                casualtyMethods =
                        apiccCharacterizer.findCasualtyInstances
                                (changedSootMethods, changedGumtreeMethods, insertedMethodInvocations, deletedMethodInvocations,
                                        methodToITreeChanges,
                                        changesToNeighbors, old);


            }
            G.reset();
        }
        return casualtyMethods;
    }


    public void setOutSystemPWriter(PrintWriter outSystemPWriter) {
        this.outSystemPWriter = outSystemPWriter;
    }


    public void setOutCausPWriter(PrintWriter outCausPWriter) {
        this.outCausPWriter = outCausPWriter;
    }

    public void setOutCausFineGrainedPWriter(PrintWriter outCausFineGrainedPWriter) {
        this.outCausFineGrainedPWriter = outCausFineGrainedPWriter;
    }

    public List<SootMethod> getNewCasualtyMethods() {
        return newCasualtyMethods;
    }

    public List<SootMethod> getOldCasualtyMethods() {
        return oldCasualtyMethods;
    }

    public APICCCharacterizer getApiccCharacterizer() {
        return apiccCharacterizer;
    }

    public int getLineCount() {
        return lineCount;
    }
}
