package casualtydetector;

import com.github.gumtreediff.gen.Generators;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.tree.ITree;
import com.github.gumtreediff.tree.TreeContext;
import javafx.util.Pair;
import soot.SootField;
import soot.SootMethod;
import util.ChangeUtil;
import util.SootUtilities;

import java.io.IOException;
import java.io.Serializable;
import java.util.*;
import java.util.logging.Level;

import static util.Constants.MET_DECL;
import static util.Constants.logger;

public class SootUnitProxy implements Serializable {


    public void getChangedSootMethods(String classPath,
                                      String prefix,
                                      List<SootMethod> sootMethods,
                                      List<ITree> gumTreeMethods,
                                      LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClass,
                                      String[] files,
                                      int type) throws IOException {
//
        List<String> stringifiedMethods = new ArrayList<>();

//            //we get the vulnerable nodes and descendants (nodes that are not directly vulnerable, but whose direct dependencies are vulnerable) with our vulnerableNodeIdentifier class


        String msg = "SOOT METHODS\n";

        //G.reset();
        ChangeUtil.setSootEnvironment(classPath);
        Iterator<Map.Entry<Integer, HashMap<String, List<ITree>>>> iterator = changesPerMethodInClass.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, HashMap<String, List<ITree>>> entry = iterator.next();
            int fileNo = entry.getKey();
            HashMap<String, List<ITree>> value = entry.getValue();
            Iterator<Map.Entry<String, List<ITree>>> iterator1 = value.entrySet().iterator();
            while (iterator1.hasNext()) {
                Map.Entry<String, List<ITree>> entry1 = iterator1.next();
                List<ITree> nodes = entry1.getValue();

                inner:
                for(ITree node: nodes){
                String filePath = files[fileNo];

                TreeContext treeContext = Generators.getInstance().getTree(filePath);
                if (!node.toPrettyString(treeContext).equalsIgnoreCase(MET_DECL)
                        && !node.toPrettyString(treeContext).equalsIgnoreCase("CompilationUnit")) {


                    String className = getClassName(prefix, type, filePath);

                    SootMethod sootMethod = SootUtilities.getSootMethod(node, className, treeContext);


                    if (sootMethod != null && !sootMethods.contains(sootMethod) && !stringifiedMethods.contains(sootMethod.getSignature())) {

                        ITree gumTreeMethod = SootUtilities.getMethod(node, treeContext);
                        gumTreeMethods.add(gumTreeMethod);
                        msg += sootMethod.getSignature() + "\n";
                        msg += node.toPrettyString(treeContext) + ": " + node.getPos() + "\n";
                        sootMethods.add(sootMethod);
                        stringifiedMethods.add(sootMethod.getSignature());
                        break inner;
                    }

                    if (sootMethod == null) {
                        logger.log(Level.INFO, "method not found. class " + className + " " + node.toPrettyString(treeContext));
                    }
                }

                }

            }


        }

        logger.log(Level.INFO, msg);
    }

    public List<SootField> findMatchingFields(List<Pair<Integer, ITree>> mvarChanges,
                                              String classPath,
                                              String prefix,
                                              String[] files,
                                              int type) throws IOException {
        SootUtilities.setUpSootEnvironmentWithCheck(classPath);
        List<SootField> result = new ArrayList<>();
        for (Pair<Integer, ITree> mvarChange : mvarChanges) {
            String filePath = files[mvarChange.getKey()];
            String className = getClassName(prefix, type, filePath);
            TreeContext treeContext = Generators.getInstance().getTree(filePath);
            SootField matchesField = SootUtilities.getField(mvarChange.getValue(), className, treeContext);
            if (matchesField != null && !result.contains(matchesField)) {
                result.add(matchesField);
            }
        }
        return result;
    }

    //to be used in the new cases and to find a matching correspondent between fields
    public HashMap<SootField, SootField> findMatchingFields(List<Pair<Integer, ITree>> mvarChanges,
                                                            String classPath,
                                                            String firstClassPath,
                                                            String prefix,
                                                            String firstPrefix,
                                                            String[] files,
                                                            List<MappingStore> mappingStores,
                                                            int type) throws IOException {
        HashMap<SootField, SootField> result = new HashMap<>();
        SootUtilities.setUpSootEnvironmentWithCheck(classPath);
        HashMap<ITree, SootField> tempResult = new HashMap<>();
        for (Pair<Integer, ITree> mvarChange : mvarChanges) {
            String filePath = files[mvarChange.getKey()];
            String className = getClassName(prefix, type, filePath);

            ITree node = mvarChange.getValue();
            TreeContext treeContext = Generators.getInstance().getTree(filePath);
            SootField matchesField = SootUtilities.getField(node, className, treeContext);

            //System.out.println(matchesField.getName());
            if (matchesField != null)
            tempResult.put(node, matchesField);


        }

        SootUtilities.setUpSootEnvironmentWithCheck(firstClassPath);
        for (Pair<Integer, ITree> mvarChange : mvarChanges) {
            ITree node = mvarChange.getValue();
            String filePath = files[mvarChange.getKey() - 1];
            TreeContext treeContext = Generators.getInstance().getTree(filePath);
            String className = getClassName(firstPrefix, type, filePath);
            if (tempResult.containsKey(node)) {
                SootField mappedField = null;
                ITree mappedNode = mappingStores.get(mvarChange.getKey() / 2).getSrc(node);
                if (mappedNode != null) {
                    mappedField = SootUtilities.getField(node, className, treeContext);
                }

                result.put(tempResult.get(node), mappedField);

            }


        }

        return result;
    }

    private String getClassName(String prefix, int type, String filePath) {
        String className;
        if (type == 4) {
            className = SootUtilities.getClassName(filePath, true);
        } else if (filePath.contains("org")) {
            className = SootUtilities.getClassName(prefix, filePath, true);
        } else {
            className = SootUtilities.getClassName(prefix, filePath);
        }
        return className;
    }
}









