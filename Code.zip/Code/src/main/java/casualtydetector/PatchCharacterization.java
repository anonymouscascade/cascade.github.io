package casualtydetector;

import com.github.gumtreediff.gen.Generators;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.tree.ITree;
import com.github.gumtreediff.tree.TreeContext;
import fixdetector.NodeChanges;
import javafx.util.Pair;
import org.apache.commons.collections4.BidiMap;
import org.apache.commons.collections4.bidimap.DualLinkedHashBidiMap;
import proganalysis.InterProceduralPDG;
import proganalysis.ProgramDependenceGraph;
import soot.G;
import soot.SootMethod;
import soot.Unit;
import util.ChangeUtil;
import util.DirectedGraph;
import util.SootUtilities;
import util.UndirectedGraph;

import java.io.IOException;
import java.util.*;
import java.util.logging.Level;

import static util.Constants.*;

public class PatchCharacterization {


    /**
     * this method is used to obtain nodes that are involved in changes between a pair of fixed and buggy revisions
     *
     * @return
     */
    public static List<ITree> getInvolvedNodes(List<NodeChanges> nodeChanges) {
        //find connected components from the changes
        ChangeUtil changeUtil = new ChangeUtil();

        BidiMap<Integer, ITree> idToNodeMap = changeUtil.getITreesfromChanges(nodeChanges).inverseBidiMap();
        return new ArrayList<>(idToNodeMap.values());
    }



    private List<DirectedGraph> buildGraphs(List<String> edges, int size, BidiMap<String, Integer> methodId, BidiMap<String, Integer> finalProcessedMethodId) {
        UndirectedGraph undirectedGraph = new UndirectedGraph(size);
        LinkedHashMap<Integer, LinkedList<Integer>> directedAdjacencyMatrix = new LinkedHashMap<>();
        List<DirectedGraph> directedGraphs = new ArrayList<>();

        for (String edge : edges) {
            int firstID = Integer.parseInt(edge.split(",")[0]);
            int secondID = Integer.parseInt(edge.split(",")[1]);

            undirectedGraph.addEdge(firstID, secondID);
            LinkedList<Integer> adjacencyList;
            if (directedAdjacencyMatrix.containsKey(secondID)) {
                adjacencyList = directedAdjacencyMatrix.get(secondID);
                if (!adjacencyList.contains(firstID)) {
                    adjacencyList.add(firstID);
                }
            } else {
                adjacencyList = new LinkedList<>();
                adjacencyList.add(firstID);
            }
            directedAdjacencyMatrix.put(secondID, adjacencyList);

        }
        undirectedGraph.connectedComponents();
        List<List<Integer>> connectedComponents = undirectedGraph.getConnectedComponents();
        for (List<Integer> connectedComponent : connectedComponents) {
            DirectedGraph directedGraph = new DirectedGraph(connectedComponent.size());
            int id = 0;
            for (int node : connectedComponent) {
                String nodeSignature = methodId.getKey(node);
                int nodeId;
                if (!finalProcessedMethodId.containsKey(nodeSignature)) {
                    nodeId = id++;
                    finalProcessedMethodId.put(nodeSignature, nodeId);
                } else {
                    nodeId = finalProcessedMethodId.get(nodeSignature);
                }
                if (directedAdjacencyMatrix.containsKey(node)) {
                    List<Integer> adjacencyList = directedAdjacencyMatrix.get(node);
                    for (int neighbor : adjacencyList) {
                        String neighborSignature = methodId.getKey(neighbor);
                        int neighborId;
                        if (!finalProcessedMethodId.containsKey(neighborSignature)) {
                            neighborId = id++;
                            finalProcessedMethodId.put(neighborSignature, neighborId);
                        } else {
                            neighborId = finalProcessedMethodId.get(neighborSignature);
                        }
                        directedGraph.addEdge(nodeId, neighborId);
                    }
                }
            }
            directedGraphs.add(directedGraph);

        }
        return directedGraphs;
    }

    /**
     * this method is used to find simple casualty changes + with surrounding variables
     *
     * @param changesPerMethodInClass
     * @param files
     * @param changedSootMethods
     * @param changedGumtreeMethods
     * @throws IOException
     */
    public static List<SootMethod> findPotentialSimple3CasualtyChanges(LinkedHashMap<Integer, HashMap<String,
            List<NodeChanges>>> changesPerMethodInClass, String[] files, List<SootMethod> changedSootMethods, List<ITree> changedGumtreeMethods,
                                                                       List<ITree> addedMethodInvocations,
                                                                       List<ITree> deletedMethodInvocations,
                                                                       String firstVersionClassPath,
                                                                       String secondVersionClassPath) throws IOException {

        List<SootMethod> methodNames = new ArrayList<>();

        for (int i = 0; i < changedSootMethods.size(); i++) {
            SootMethod sootMethod = changedSootMethods.get(i);
            int connectedComponentsSize = 0;


            //  String key = sootMethod.getName() + ": " + sootMethod.getJavaSourceStartLineNumber();


            String className = sootMethod.getDeclaringClass().toString().replace('.', '/').split("$")[0];
            int fileNo = SootUtilities.findFileNo(files, className);
            //debugging


            if (fileNo != -1) {
                if ((fileNo + 1) % 2 == 0) {
                    fileNo = fileNo - 1;
                }
                TreeContext treeContext = Generators.getInstance().getTree(files[fileNo]);
                ITree methodDeclaration = changedGumtreeMethods.get(i);
                if ((fileNo + 1) % 2 == 0) {
                    G.reset();
                    SootUtilities.setUpSootEnvironment(secondVersionClassPath);
                } else {
                    G.reset();
                    SootUtilities.setUpSootEnvironment(firstVersionClassPath);
                }


                String key = SootUtilities.getMethodName(methodDeclaration, treeContext) + ": " + methodDeclaration.getPos();
                if (DEBUG) {
                    logger.log(Level.INFO, "changed soot method: " + key);
                }

                if (changesPerMethodInClass.containsKey(fileNo)) {
                    HashMap<String, List<NodeChanges>> changesPerMethod = changesPerMethodInClass.get(fileNo);
                    if (changesPerMethod.containsKey(key)) {
                        List<NodeChanges> nodeChanges = changesPerMethod.get(key);
                        if (DEBUG) {
                            logger.log(Level.INFO, "the key is in the map");
                        }
                        List<ITree> originNodes = getInvolvedNodes(nodeChanges);
                        HashMap<Unit, List<ITree>> unitToITreeMap = new HashMap<>();


//                        ITree getMappedMethod = SootUtilities.getMappedMethod(methodDeclaration, mappingStore.get(fileNo / 2));
//                        String className1 = className.replace('/', '.').split("$")[0];
//                        SootMethod sootMethod1;
//                        if (getMappedMethod != null) {
//                            G.reset();
//                            SootUtilities.setUpSootEnvironment(secondVersionClassPath);
//
//                            treeContext = Generators.getInstance().getTree(files[fileNo + 1]);
//                            sootMethod1 = SootUtilities.getSootMethod(getMappedMethod, className1, treeContext);
//
//                        } else {
//                            sootMethod1 = sootMethod;
//                        }

                        for (ITree originNode : originNodes) {

                            Unit unit = SootUtilities.getUnitFromMethod(sootMethod, originNode, treeContext);

                            if (unit != null) {
                                List<ITree> iTrees;
                                if (!unitToITreeMap.containsKey(unit)) {
                                    //sootUnits.add(unit);
                                    iTrees = new ArrayList<>();
                                    iTrees.add(originNode);
                                    unitToITreeMap.put(unit, iTrees);
                                } else {
                                    iTrees = unitToITreeMap.get(unit);
                                    iTrees.add(originNode);
                                    unitToITreeMap.replace(unit, iTrees);
                                }
                            }
                        }
                        Set<Unit> keySet = unitToITreeMap.keySet();
                        System.out.println("origin nodes size: " + originNodes.size());
                        System.out.println("units size: " + keySet.size());

                        if (keySet.size() > 1) {
                            BidiMap<Unit, Integer> unitToIDMap = new DualLinkedHashBidiMap<>();
//                            G.reset();
                            //Scene.v().setSootClassPath(secondVersionClassPath);
                            InterProceduralPDG interProceduralPDG = new InterProceduralPDG();
                            className = className.replace('/', '.');
                            interProceduralPDG.run(className, sootMethod);

                            ProgramDependenceGraph intraProceduralPDG = interProceduralPDG.getInterProceduralPDG();
                            List<String> edges = new ArrayList<>();
                            int unitId = 0;
                            for (Unit unit_1 : keySet) {

                                for (Unit unit_2 : keySet) {
                                    boolean dataFlowEdge = ChangeUtil.areEdgesConnectedThroughDataFlow(intraProceduralPDG, unit_1, unit_2);
                                    if (dataFlowEdge) {
                                        int unit1ID;
                                        int unit2ID;

                                        if (unitToIDMap.containsKey(unit_1)) {
                                            unit1ID = unitToIDMap.get(unit_1);
                                        } else {
                                            unit1ID = unitId++;
                                            unitToIDMap.put(unit_1, unit1ID);
                                        }

                                        if (unitToIDMap.containsKey(unit_2)) {
                                            unit2ID = unitToIDMap.get(unit_2);
                                        } else {
                                            unit2ID = unitId++;
                                            unitToIDMap.put(unit_2, unit2ID);
                                        }


                                        String edge = unit1ID + "," + unit2ID;
                                        edges.add(edge);

                                        System.out.println("edge found: " + edge);

                                    }
                                }
                            }

                            UndirectedGraph undirectedGraph = ChangeUtil.buildUndirected(edges, unitToIDMap.size());
                            undirectedGraph.connectedComponents();
                            List<List<Integer>> connectedComponents = undirectedGraph.getConnectedComponents();
                            connectedComponentsSize = connectedComponents.size();
                            boolean[] presence = new boolean[connectedComponentsSize];
                            //if(connectedComponentsSize == 1) {
                            for (int j = 0; i < connectedComponentsSize; i++) {
                                List<Integer> connectedComponent = connectedComponents.get(j);
                                List<ITree> iTreeList = new ArrayList<>();
                                for (Integer component : connectedComponent) {
                                    Unit unit = unitToIDMap.getKey(component);
                                    List<ITree> iTrees = unitToITreeMap.get(unit);
                                    iTreeList.addAll(iTrees);
                                }

                                for (ITree iTree : iTreeList) {
                                    String type = iTree.toPrettyString(treeContext).split(":")[0];
                                    boolean presentInOnlyOne = (addedMethodInvocations.contains(iTree) && !deletedMethodInvocations.contains(iTree)) ||
                                            (!addedMethodInvocations.contains(iTree) && deletedMethodInvocations.contains(iTree));
                                    boolean presentInNone = !addedMethodInvocations.contains(iTree) && !deletedMethodInvocations.contains(iTree);

                                    boolean presenceTest = presentInOnlyOne || presentInNone;
                                    if (presenceTest && (type.equalsIgnoreCase(MET_INV) || type.equalsIgnoreCase(CLASS_INSTC_CREAT))) {
                                        if (iTree.getChildren().size() > 0) {
                                            String childType = iTree.getChild(0).toPrettyString(treeContext).split(":")[0];
                                            if (childType.equalsIgnoreCase(SIMPLE_NAME) ||
                                                    childType.equalsIgnoreCase(SIMPLE_TYPE)) {
                                                if (DEBUG) {
                                                    ITree child = iTree.getChild(0);
                                                    String label = child.getLabel();
                                                    logger.log(Level.INFO, "the label of the child of the involved node: " + label);
                                                }
                                                // methodNames.add(sootMethod);
//                                                    if (!methodNames.contains(sootMethod))
//                                                        methodNames.add(sootMethod);
                                                if (!presence[j]) {
                                                    presence[j] = true;
                                                }
                                            }
                                        }
                                    }
                                }
                                // }
                            }
                            int presenceTotal = 0;
                            for (boolean present : presence) {
                                if (present) presenceTotal++;
                            }
                            if (presenceTotal == connectedComponentsSize) {
                                if (!methodNames.contains(sootMethod))
                                    methodNames.add(sootMethod);
                            }
                        }

                    }
                }
            }
        }
        // if(connectedComponentsSize == casualtyChanges) {
        return methodNames;
        //}
        //else {
        //  return  new ArrayList<SootMethod>();
        //}
    }

    /**
     * this method finds root API changes given a list of API changes
     * it does so by first building a graph of API changes (based on methods whose APIs have changed and call each-other)
     * then it does a reachability analysis on a reverse graph: if a method reaches all others, it is a main change
     *
     * @param apiChanges
     * @param files
     * @param firstPrefix
     * @return
     * @throws IOException
     */
    public List<String> findRootChanges(List<Pair<Integer, ITree>> apiChanges, String[] files, String firstPrefix, boolean old, int type) throws IOException {
        List<String> mainChanges = new ArrayList<>();
        List<SootMethod> sootMethods = new ArrayList<>();

        if (DEBUG) {
            String message = "Size of api changes list: " + apiChanges.size();
            logger.log(Level.INFO, message);
        }

//        find all corresponding sootMethods from the apiChanges identified
        for (Pair<Integer, ITree> apiChange : apiChanges) {
            String filePath;
            if (old) {
                filePath = files[apiChange.getKey()];
            } else {
                filePath = files[apiChange.getKey() + 1];
            }
            String className;
            if (type == 4) {
                className = SootUtilities.getClassName(filePath, true);
            } else if (filePath.contains("org")) {
                className = SootUtilities.getClassName(firstPrefix, filePath, true);
            } else {
                className = SootUtilities.getClassName(firstPrefix, filePath);
            }
            TreeContext treeContext = Generators.getInstance().getTree(filePath);
            SootMethod sootMethod = SootUtilities.getSootMethod(apiChange.getValue(), className, treeContext);
            if (sootMethod != null && !sootMethods.contains(sootMethod)) {
                sootMethods.add(sootMethod);
            }
        }


        BidiMap<String, Integer> methodId = new DualLinkedHashBidiMap<>();

        List<String> edges = new ArrayList<>();


        int id = 0;
//      get all the methods in the API changes that call each other
        for (SootMethod sootMethod : sootMethods) {
            ChangeUtil changeUtil = new ChangeUtil();
            //if this doesn't work, there is also the method using the soot callgraph called getEdges (but in CVE-2011-1184 it seems not to work)
            id = changeUtil.getEdgesNoCallgraph(sootMethods, methodId, edges, id, sootMethod);
        }

        if (sootMethods.size() == 1) {
            if (DEBUG) {
                logger.log(Level.INFO, "Full name: " + sootMethods.get(0).getSignature() + " is a main change");
                logger.log(Level.INFO, "Name: " + sootMethods.get(0).getName() + " is a main change");
            }
            mainChanges.add(sootMethods.get(0).getSignature());

            return mainChanges;

        }
        if (DEBUG) {
            if (methodId.size() > 0) {
                logger.log(Level.INFO, "Methods found: ");
                Iterator<Map.Entry<String, Integer>> methodIDiterator = methodId.entrySet().iterator();
                while (methodIDiterator.hasNext()) {
                    Map.Entry<String, Integer> entry = methodIDiterator.next();
                    String methodName = entry.getKey();
                    int methodValue = entry.getValue();

                    logger.log(Level.INFO, methodName + ": " + methodValue);
                }
            } else {
                logger.log(Level.INFO, "no methods with edges found");
                for (SootMethod sootMethod : sootMethods) {
                    mainChanges.add(sootMethod.getSignature());
                }
                return mainChanges;
            }
        }



        BidiMap<String, Integer> processedMethodId = new DualLinkedHashBidiMap<>();
        List<DirectedGraph> directedGraphs = buildGraphs(edges, methodId.size(), methodId, processedMethodId);


        for (DirectedGraph directedGraph : directedGraphs) {

            //we have to check reachability analysis for each component, and we can get connected components by just "pretending" the graph is undirected

            directedGraph.reachability();
            HashMap<Integer, List<Integer>> reachable = directedGraph.getReachability();

            Iterator<Map.Entry<Integer, List<Integer>>> reachableIterator = reachable.entrySet().iterator();
            BidiMap<Integer, String> integerStringBidiMap = processedMethodId.inverseBidiMap();
            while (reachableIterator.hasNext()) {
                Map.Entry<Integer, List<Integer>> entry = reachableIterator.next();
                int key = entry.getKey();
                List<Integer> value = entry.getValue();

                if (DEBUG) {
                    logger.log(Level.INFO, "reach key :" + key);
                    logger.log(Level.INFO, "reach value:" + Arrays.toString(value.toArray()));
                }
                boolean mainChange = directedGraph.reachesAll(key);
                String methodFullName = integerStringBidiMap.get(key);
                if (mainChange) {



                    if (DEBUG) {

                        String methodname = SootUtilities.getMethodNameFromFullName(methodFullName);
                        logger.log(Level.INFO, "Changes in method: " + key + "-" + methodFullName + " are main changes");
                        logger.log(Level.INFO, "Method name: " + methodname);
                    }

                    mainChanges.add(methodFullName);
                } else if (DEBUG) {
                    logger.log(Level.INFO, "Changes in api calling: " + methodFullName + "are potential casualty changes");
                }
            }
        }

        return mainChanges;

    }

    /**
     * this method finds potential simple casualty changes given a list of changes per each method
     *
     * @param changesPerMethodInClass
     * @param files
     * @param changedSootMethods
     * @return
     * @throws IOException
     */
    public List<SootMethod> findPotentialSimpleCasualtyChanges(LinkedHashMap<Integer, HashMap<String,
            List<NodeChanges>>> changesPerMethodInClass, String[] files, List<SootMethod> changedSootMethods, List<ITree> changedGumtreeMethods,
                                                               List<ITree> addedMethodInvocations, List<ITree> deletedMethodInvocations) throws IOException {
        List<SootMethod> methodNames = new ArrayList<>();

        for (int i = 0; i < changedSootMethods.size(); i++) {
            SootMethod sootMethod = changedSootMethods.get(i);

            String className = sootMethod.getDeclaringClass().toString().replace('.', '/');
            int fileNo = SootUtilities.findFileNo(files, className);
            if ((fileNo + 1) % 2 == 0) {
                fileNo = fileNo - 1;
            }
            if (fileNo != -1) {

                TreeContext treeContext = Generators.getInstance().getTree(files[fileNo]);
                ITree methodDeclaration = changedGumtreeMethods.get(i);

                String key = SootUtilities.getMethodName(methodDeclaration, treeContext) + ": " + methodDeclaration.getPos();
                if (DEBUG) {
                    logger.log(Level.INFO, "changed soot method: " + key);
                }

                if (changesPerMethodInClass.containsKey(fileNo)) {
                    HashMap<String, List<NodeChanges>> changesPerMethod = changesPerMethodInClass.get(fileNo);
                    if (changesPerMethod.containsKey(key)) {
                        List<NodeChanges> nodeChanges = changesPerMethod.get(key);
                        if (DEBUG) {
                            logger.log(Level.INFO, "the key is in the map");
                        }
                        ChangeUtil changeUtil = new ChangeUtil();
                        DirectedGraph changesGraph = changeUtil.buildChangesGraph(nodeChanges);
                        BidiMap<Integer, ITree> idToNodeMap = changeUtil.getIdToNodeMap().inverseBidiMap();
                        changesGraph.reachability();
                        HashMap<Integer, List<Integer>> changesGraphReachability = changesGraph.getReachability();
                        Iterator<Map.Entry<Integer, List<Integer>>> changesGraphReachibilityIterator = changesGraphReachability.entrySet().iterator();
                        while (changesGraphReachibilityIterator.hasNext()) {
                            Map.Entry<Integer, List<Integer>> entry = changesGraphReachibilityIterator.next();
                            int keyID = entry.getKey();
                            boolean reachesAll = changesGraph.reachesAll(keyID);
                            if (reachesAll) {
                                ITree node = idToNodeMap.get(keyID);
                                if (DEBUG) {
                                    logger.log(Level.INFO, node.toPrettyString(treeContext) + ": is a sole origin node");
                                }
                                String type = node.toPrettyString(treeContext).split(":")[0];
                                boolean presentInOnlyOne = (addedMethodInvocations.contains(node) && !deletedMethodInvocations.contains(node)) || (!addedMethodInvocations.contains(node) && deletedMethodInvocations.contains(node));
                                boolean presentInNone = !addedMethodInvocations.contains(node) && !deletedMethodInvocations.contains(node);

                                boolean presenceTest = presentInOnlyOne || presentInNone;
                                if (presenceTest && (type.equalsIgnoreCase(MET_INV) || type.equalsIgnoreCase(CLASS_INSTC_CREAT))) {

                                    if (node.getChildren().size() > 0) {
                                        String childType = node.getChild(0).toPrettyString(treeContext).split(":")[0];
                                        if (childType.equalsIgnoreCase(SIMPLE_NAME) ||
                                                childType.equalsIgnoreCase(SIMPLE_TYPE)) {
                                            if (DEBUG) {
                                                ITree child = node.getChild(0);
                                                String label = child.getLabel();
                                                logger.log(Level.INFO, "the label of the child of the sole origin node: " + label);
                                            }
                                            if (!methodNames.contains(sootMethod))
                                                methodNames.add(sootMethod);

                                        }
                                    }
                                }

                            }
                        }
                    }
                }
            }


        }
        return methodNames;
    }

    /**
     * this method is used to find simple casualty changes in a method - with out surrounding variables
     *
     * @param changesPerMethodInClass
     * @param files
     * @param changedSootMethods
     * @param changedGumtreeMethods
     * @return
     * @throws IOException
     */
    public List<SootMethod> findPotentialSimple2CasualtyChanges(LinkedHashMap<Integer, HashMap<String,
            List<NodeChanges>>> changesPerMethodInClass, String[] files, List<SootMethod> changedSootMethods, List<ITree> changedGumtreeMethods,
                                                                List<ITree> addedMethodInvocations, List<ITree> deletedMethodInvocations, HashMap<String, List<ITree>> methodsToChanges) throws IOException {
        List<SootMethod> methodNames = new ArrayList<>();

        for (int i = 0; i < changedSootMethods.size(); i++) {
            SootMethod sootMethod = changedSootMethods.get(i);


            //  String key = sootMethod.getName() + ": " + sootMethod.getJavaSourceStartLineNumber();


            String className = sootMethod.getDeclaringClass().toString().replace('.', '/');
            int fileNo = SootUtilities.findFileNo(files, className);
            if (fileNo != -1) {
                if ((fileNo + 1) % 2 == 0) {
                    fileNo = fileNo - 1;
                }


                TreeContext treeContext = Generators.getInstance().getTree(files[fileNo]);
                ITree methodDeclaration = changedGumtreeMethods.get(i);

                String key = SootUtilities.getMethodName(methodDeclaration, treeContext) + ": " + methodDeclaration.getPos();
                if (DEBUG) {
                    logger.log(Level.INFO, "changed soot method: " + key);
                }

                if (changesPerMethodInClass.containsKey(fileNo)) {
                    HashMap<String, List<NodeChanges>> changesPerMethod = changesPerMethodInClass.get(fileNo);
                    if (changesPerMethod.containsKey(key)) {
                        List<NodeChanges> nodeChanges = changesPerMethod.get(key);
                        if (DEBUG) {
                            logger.log(Level.INFO, "the key is in the map");
                        }
                        List<ITree> originNodes = getInvolvedNodes(nodeChanges);


                        for (ITree node : originNodes) {
                            String type = node.toPrettyString(treeContext).split(":")[0];
                            boolean presentInOnlyOne = (addedMethodInvocations.contains(node) && !deletedMethodInvocations.contains(node)) || (!addedMethodInvocations.contains(node) && deletedMethodInvocations.contains(node));
                            boolean presentInNone = !addedMethodInvocations.contains(node) && !deletedMethodInvocations.contains(node);

                            boolean presenceTest = presentInOnlyOne || presentInNone;
                            if (presenceTest && (type.equalsIgnoreCase(MET_INV) || type.equalsIgnoreCase(CLASS_INSTC_CREAT))) {
                                if (node.getChildren().size() > 0) {
                                    String childType = node.getChild(0).toPrettyString(treeContext).split(":")[0];
                                    if (childType.equalsIgnoreCase(SIMPLE_NAME) ||
                                            childType.equalsIgnoreCase(SIMPLE_TYPE)) {
                                        if (DEBUG) {
                                            ITree child = node.getChild(0);
                                            String label = child.getLabel();
                                            logger.log(Level.INFO, "the label of the child of the involved node: " + label);
                                        }
                                        if (!methodNames.contains(sootMethod))
                                            methodNames.add(sootMethod);
                                        if (methodsToChanges.containsKey(sootMethod.getSignature())) {
                                            List<ITree> iTrees = methodsToChanges.get(sootMethod.getSignature());
                                            if (!iTrees.contains(node)) {
                                                iTrees.add(node);
                                            }
                                            methodsToChanges.replace(sootMethod.getSignature(), iTrees);
                                        } else {
                                            List<ITree> iTrees = new ArrayList<>();
                                            iTrees.add(node);
                                            methodsToChanges.put(sootMethod.getSignature(), iTrees);

                                        }


                                    }
                                }
                            }

                        }

                    }
                }
            }


        }
        return methodNames;
    }

    public List<SootMethod> findPotentialSimple4CasualtyChanges(LinkedHashMap<Integer, HashMap<String,
            List<NodeChanges>>> changesPerMethodInClass, String[] files, List<SootMethod> changedSootMethods, List<ITree> changedGumtreeMethods,
                                                                List<ITree> addedMethodInvocations, List<ITree> deletedMethodInvocations,
                                                                HashMap<String, List<ITree>> methodsToChanges,
                                                                HashMap<SootMethod, List<String>> reachableMap, boolean old) throws IOException {
        List<SootMethod> methodNames = new ArrayList<>();

        for (int i = 0; i < changedSootMethods.size(); i++) {
            SootMethod sootMethod = changedSootMethods.get(i);
            if (reachableMap.containsKey(sootMethod)) {

                String className = sootMethod.getDeclaringClass().toString().replace('.', '/');
                int fileNo = SootUtilities.findFileNo(files, className);
                if (fileNo != -1) {
                    if (old && (fileNo + 1) % 2 == 0) {
                        fileNo = fileNo - 1;
                    } else if (!old && fileNo % 2 == 0) {
                        fileNo = fileNo + 1;
                    }


                    TreeContext treeContext = Generators.getInstance().getTree(files[fileNo]);
                    ITree methodDeclaration = changedGumtreeMethods.get(i);

                    String key = SootUtilities.getMethodName(methodDeclaration, treeContext) + ": " + methodDeclaration.getPos();
                    if (DEBUG) {
                        logger.log(Level.INFO, "changed soot method: " + key);
                    }

                    if (changesPerMethodInClass.containsKey(fileNo)) {
                        HashMap<String, List<NodeChanges>> changesPerMethod = changesPerMethodInClass.get(fileNo);
                        if (changesPerMethod.containsKey(key)) {
                            List<NodeChanges> nodeChanges = changesPerMethod.get(key);
                            if (DEBUG) {
                                logger.log(Level.INFO, "the key is in the map");
                            }
                            List<ITree> originNodes = getInvolvedNodes(nodeChanges);


                            for (ITree node : originNodes) {
                                String type = node.toPrettyString(treeContext).split(":")[0];
                                boolean presentInOnlyOne = (addedMethodInvocations.contains(node) && !deletedMethodInvocations.contains(node)) || (!addedMethodInvocations.contains(node) && deletedMethodInvocations.contains(node));
                                boolean presentInNone = !addedMethodInvocations.contains(node) && !deletedMethodInvocations.contains(node);

                                boolean presenceTest = !presentInOnlyOne || presentInNone;
                                if (presenceTest) {
                                    if (type.equalsIgnoreCase(MET_INV)) {
                                        if (node.getChildren().size() > 0) {
                                            String childType = node.getChild(0).toPrettyString(treeContext).split(":")[0];
                                            if (childType.equalsIgnoreCase(SIMPLE_NAME) ||
                                                    childType.equalsIgnoreCase(SIMPLE_TYPE)) {

                                                List<String> reachableMethods = reachableMap.get(sootMethod);
                                                for (String method : reachableMethods) {

                                                    String shortMethodName = SootUtilities.getMethodNameFromFullName(method);
                                                    if (SootUtilities.nameInChildren(shortMethodName, node)) {
                                                        if (!methodNames.contains(sootMethod))
                                                            methodNames.add(sootMethod);
                                                        if (methodsToChanges.containsKey(sootMethod.getSignature())) {
                                                            List<ITree> iTrees = methodsToChanges.get(sootMethod.getSignature());
                                                            if (!iTrees.contains(node)) {
                                                                iTrees.add(node);
                                                            }
                                                            methodsToChanges.replace(sootMethod.getSignature(), iTrees);
                                                        } else {
                                                            List<ITree> iTrees = new ArrayList<>();
                                                            iTrees.add(node);
                                                            methodsToChanges.put(sootMethod.getSignature(), iTrees);

                                                        }
                                                    }
                                                }


                                            }
                                        }
                                    }
                                    if (type.equalsIgnoreCase(CLASS_INSTC_CREAT)) {
                                        if (node.getChildren().size() > 0) {
                                            String childType = node.getChild(0).toPrettyString(treeContext).split(":")[0];
                                            if (childType.equalsIgnoreCase(SIMPLE_NAME) ||
                                                    childType.equalsIgnoreCase(SIMPLE_TYPE)) {

                                                List<String> reachableMethods = reachableMap.get(sootMethod);
                                                for (String method : reachableMethods) {

                                                    String shortMethodName = SootUtilities.getMethodNameFromFullName(method);
                                                    List<String> childLabels = new ArrayList<>();
                                                    for (ITree child : node.getChildren()) {
                                                        if (child.hasLabel()) {
                                                            childLabels.add(child.getLabel().trim());
                                                        }
                                                    }
                                                    boolean hasLabel = false;
                                                    for (String label : childLabels) {
                                                        if (method.contains(label)) {
                                                            hasLabel = true;
                                                        }
                                                    }
                                                    if (hasLabel && shortMethodName.contains("<init>")) {
                                                        if (!methodNames.contains(sootMethod))
                                                            methodNames.add(sootMethod);
                                                        if (methodsToChanges.containsKey(sootMethod.getSignature())) {
                                                            List<ITree> iTrees = methodsToChanges.get(sootMethod.getSignature());
                                                            if (!iTrees.contains(node)) {
                                                                iTrees.add(node);
                                                            }
                                                            methodsToChanges.replace(sootMethod.getSignature(), iTrees);
                                                        } else {
                                                            List<ITree> iTrees = new ArrayList<>();
                                                            iTrees.add(node);
                                                            methodsToChanges.put(sootMethod.getSignature(), iTrees);

                                                        }
                                                    }
                                                }


                                            }
                                        }

                                    }

                                    if (type.equalsIgnoreCase(CONSTR_INV)) {
                                        String[] constructorNameSplit = className.split("/");
                                        String constructorName = constructorNameSplit[constructorNameSplit.length - 1].trim();

                                        List<String> reachableMethods = reachableMap.get(sootMethod);
                                        for (String method : reachableMethods) {

                                            String shortMethodName = SootUtilities.getMethodNameFromFullName(method);

                                            boolean hasLabel = method.contains(constructorName);

                                            if (hasLabel && shortMethodName.contains("<init>")) {
                                                if (!methodNames.contains(sootMethod))
                                                    methodNames.add(sootMethod);
                                                if (methodsToChanges.containsKey(sootMethod.getSignature())) {
                                                    List<ITree> iTrees = methodsToChanges.get(sootMethod.getSignature());
                                                    if (!iTrees.contains(node)) {
                                                        iTrees.add(node);
                                                    }
                                                    methodsToChanges.replace(sootMethod.getSignature(), iTrees);
                                                } else {
                                                    List<ITree> iTrees = new ArrayList<>();
                                                    iTrees.add(node);
                                                    methodsToChanges.put(sootMethod.getSignature(), iTrees);

                                                }
                                            }
                                        }

                                    }
                                }

                            }

                        }
                    }
                }
            }


        }
        return methodNames;
    }

//    public HashMap<String, Pair<List<ITree>, List<ITree>>> findGettersAndSettersCasualtyChanges(ChangedNodesIdentifier changedNodesIdentifier) throws IOException {
//        String[] files = changedNodesIdentifier.listOfFiles;
//        List<MappingStore> mappingStores = changedNodesIdentifier.mappingStores;
//        LinkedHashMap<Integer, HashMap<String, List<NodeChanges>>> changesPerMethodinClass = changedNodesIdentifier.getChangesPerMethodinClass();
//        HashMap<String, Pair<List<ITree>, List<ITree>>> results = new HashMap<>();
//        Iterator<Map.Entry<Integer, HashMap<String, List<NodeChanges>>>> iterator = changesPerMethodinClass.entrySet().iterator();
//        while (iterator.hasNext()) {
//            Map.Entry<Integer, HashMap<String, List<NodeChanges>>> next = iterator.next();
//            int fileNo = next.getKey();
//            String filePath = files[fileNo];
//            HashMap<String, List<NodeChanges>> changesPerMethod = next.getValue();
//            List<ITree> methodDeclarations = new ArrayList<>();
//            List<ITree> fieldDeclarations = new ArrayList<>();
//
//            //for getters
//            List<ITree> returnStatements = new ArrayList<>();
//
//            //for setters
//            List<ITree> fieldAccesses = new ArrayList<>();
//            List<ITree> assignments = new ArrayList<>();
//
//            if (changesPerMethod.keySet().size() > 1) {
//                TreeContext treeContext = Generators.getInstance().getTree(filePath);
//                for (String key : changesPerMethod.keySet()) {
//                    List<NodeChanges> nodeChangesList = changesPerMethod.get(key);
//                    getTypesOfChanges(nodeChangesList, methodDeclarations, fieldDeclarations,
//                            returnStatements, fieldAccesses, assignments, treeContext, mappingStores.get(fileNo / 2));
//
//                }
//                List<ITree> getterCasualties = getGetterCasualtyChanges(methodDeclarations, fieldDeclarations, returnStatements, treeContext);
//                List<ITree> setterCasualties = getSetterCasualtyChanges(methodDeclarations, fieldDeclarations, fieldAccesses, assignments, treeContext);
//
//                results.put(filePath, new Pair<>(getterCasualties, setterCasualties));
//            }
//
//
//        }
//        return results;
//    }

    void getTypesOfChanges(List<NodeChanges> nodeChangesList,
                           List<ITree> methodDeclarations,
                           List<ITree> fieldDeclarations,
                           List<ITree> returnStatements,
                           List<ITree> fieldAcesses,
                           List<ITree> assignments,
                           TreeContext treeContext,
                           MappingStore mappingStore) {
        //TODO TEST FOR UPDATES
        //TODO CHECK IF IT'S NECESSARY TO CHECK FOR TYPE
        for (NodeChanges nodeChanges : nodeChangesList) {

            ITree node = nodeChanges.getAction().getNode();
            if (nodeChanges.getActionType().equalsIgnoreCase("UPD") || nodeChanges.getActionType().equalsIgnoreCase("MOV")) {
                ITree oldNode = mappingStore.getSrc(node);
                if (oldNode == null) {
                    oldNode = mappingStore.getDst(node);
                }
                if (oldNode != null) {
                    node = oldNode;
                }
            }
            String type = treeContext.getTypeLabel(node);
            String parentType = treeContext.getTypeLabel(node.getParent());

            if (type.equalsIgnoreCase(FIELD_DECL)) {
                addNodeToList(node, fieldDeclarations);
            } else if (parentType.equalsIgnoreCase(FIELD_DECL)) {
                addNodeToList(node.getParent(), fieldDeclarations);
            } else if (type.equalsIgnoreCase(MET_DECL)) {
                addNodeToList(node, methodDeclarations);
            } else if (type.equalsIgnoreCase(SIMPLE_NAME) && parentType.equalsIgnoreCase(MET_DECL)) {
                addNodeToList(node.getParent(), methodDeclarations);
            } else if (type.equalsIgnoreCase(RETURN)) {
                addNodeToList(node, returnStatements);
            } else if (parentType.equalsIgnoreCase(RETURN)) {
                addNodeToList(node.getParent(), returnStatements);
            } else if (type.equalsIgnoreCase(FIELD_ACC)) {
                addNodeToList(node, fieldAcesses);
            } else if (parentType.equalsIgnoreCase(FIELD_ACC)) {
                addNodeToList(node.getParent(), fieldAcesses);
            } else if (type.equalsIgnoreCase(ASSGNMT)) {
                addNodeToList(node, assignments);
            } else if (parentType.equalsIgnoreCase(ASSGNMT)) {
                addNodeToList(node.getParent(), assignments);
            }
        }
    }

    void addNodeToList(ITree node, List<ITree> nodes) {
        if (!nodes.contains(node)) {
            nodes.add(node);
        }
    }

    List<ITree> getSetterCasualtyChanges(List<ITree> methodDeclarations, List<ITree> fieldDeclarations, List<ITree> fieldAccesses,
                                         List<ITree> assignments, TreeContext treeContext) throws IOException {
        List<ITree> casualtyChanges = new ArrayList<>();
        List<String> methodNames = new ArrayList<>();
        List<String> parameterTypes = new ArrayList<>();
        List<Pair<Integer, Integer>> methodBounds = new ArrayList<>();
        for (int i = 0; i < methodDeclarations.size(); i++) {
            ITree methodDeclaration = methodDeclarations.get(i);
            getMethodDeclarationSetterInfo(methodDeclaration, treeContext, methodNames, parameterTypes, methodBounds, i);
        }

        List<String> fieldDeclarationTypes = new ArrayList<>();
        List<String> fieldDeclarationNames = new ArrayList<>();

        for (int i = 0; i < fieldDeclarations.size(); i++) {
            ITree fieldDeclaration = fieldDeclarations.get(i);
            getFieldDeclarationInfo(fieldDeclaration, treeContext, fieldDeclarationTypes, fieldDeclarationNames, i);

        }

        List<String> fieldAccessNames = new ArrayList<>();
        List<Integer> fieldAcessPositions = new ArrayList<>();


        getFieldAccessesInfo(fieldAccesses, treeContext, fieldAccessNames, fieldAcessPositions);


        List<ITree> assignmentAccesses = new ArrayList<>();
        List<Integer> assignmentPositions = new ArrayList<>();

        getAssignmentsInfo(assignments, treeContext, assignmentAccesses, assignmentPositions);
        List<Integer> indices = checkForSetterCasualtyChanges(methodNames, parameterTypes, fieldDeclarationTypes, fieldDeclarationNames, fieldAccessNames, fieldAccesses, assignmentAccesses, methodBounds, assignmentPositions);
        for (int index : indices) {
            casualtyChanges.add(methodDeclarations.get(index));
            System.out.println(methodNames.get(index));
        }
        return casualtyChanges;
    }

    List<Integer> checkForSetterCasualtyChanges(List<String> methodNames, List<String> parameterTypes, List<String> fieldDeclarationTypes,
                                                List<String> fieldDeclarationNames, List<String> fieldAccessNames, List<ITree> fieldAccesses, List<ITree> assignmentAccesses,
                                                List<Pair<Integer, Integer>> methodBounds, List<Integer> assignmentPositions) {
        List<Integer> indices = new ArrayList<>();
        for (int m = 0; m < methodNames.size(); m++) {
            String methodName = methodNames.get(m);
            if (methodName.contains("set")) {
                String parameterType = parameterTypes.get(m);
                List<Integer> fieldDeclarationIndices = findItemInList(fieldDeclarationTypes, parameterType);
                for (int f : fieldDeclarationIndices) {
                    String fieldDeclaration = fieldDeclarationNames.get(f);
                    List<Integer> fieldAccessIndices = findItemInList(fieldAccessNames, fieldDeclaration);
                    for (int fieldAccesIndex : fieldAccessIndices) {
                        ITree fieldAccess = fieldAccesses.get(fieldAccesIndex);
                        int position = fieldAccess.getPos();
                        Pair<Integer, Integer> methodBound = methodBounds.get(m);
                        if (checkPresenceInBounds(methodBound, position)) {
                            List<Integer> assignmentIndices = findTreeInList(assignmentAccesses, fieldAccess);
                            for (int assignmentIndex : assignmentIndices) {
                                int assignmentPosition = assignmentPositions.get(assignmentIndex);
                                if (checkPresenceInBounds(methodBound, assignmentPosition)) {
                                    indices.add(m);
                                }
                            }
                        }
                    }

                }
            }
        }

        return indices;
    }

    List<ITree> getGetterCasualtyChanges(List<ITree> methodDeclarations, List<ITree> fieldDeclarations, List<ITree> returnStatements, TreeContext treeContext) throws IOException {
        List<ITree> casualtyChanges = new ArrayList<>();
        List<String> methodNames = new ArrayList<>();
        List<String> methodReturnTypes = new ArrayList<>();
        List<Pair<Integer, Integer>> methodBounds = new ArrayList<>();
        for (int i = 0; i < methodDeclarations.size(); i++) {
            ITree methodDeclaration = methodDeclarations.get(i);
            getMethodDeclarationInfo(methodDeclaration, treeContext, methodNames, methodReturnTypes, methodBounds, i);
        }

        List<String> fieldDeclarationTypes = new ArrayList<>();
        List<String> fieldDeclarationNames = new ArrayList<>();

        for (int i = 0; i < fieldDeclarations.size(); i++) {
            ITree fieldDeclaration = fieldDeclarations.get(i);
            getFieldDeclarationInfo(fieldDeclaration, treeContext, fieldDeclarationTypes, fieldDeclarationNames, i);

        }

        List<String> returnStatementLabels = new ArrayList<>();
        List<Integer> returnStatementPositions = new ArrayList<>();
        for (int i = 0; i < returnStatements.size(); i++) {
            ITree returnStatement = returnStatements.get(i);
            getReturnStatementInfo(treeContext, returnStatementLabels, returnStatement);
            returnStatementPositions.add(i, returnStatement.getPos());

        }

        Set<Integer> indices = new HashSet<>(checkForCasualtyChanges(methodNames, methodReturnTypes, methodBounds, fieldDeclarationTypes, fieldDeclarationNames, returnStatementLabels, returnStatementPositions));

        for (int index : indices) {
            ITree methodDeclaration = methodDeclarations.get(index);
            casualtyChanges.add(methodDeclaration);
            System.out.println(methodNames.get(index));
        }
        return casualtyChanges;


    }

    private void getReturnStatementInfo(TreeContext treeContext, List<String> returnStatementLabels, ITree returnStatement) {
        List<ITree> children = returnStatement.getChildren();
        boolean simpleChild = false;
        inner:
        for (ITree child : children) {
            if (treeContext.getTypeLabel(child).equalsIgnoreCase(SIMPLE_NAME)) {
                returnStatementLabels.add(child.getLabel());
                simpleChild = true;
                break inner;
            }
        }
        if (!simpleChild) {
            returnStatementLabels.add("void");
        }
    }

    private void getFieldDeclarationInfo(ITree fieldDeclaration, TreeContext treeContext, List<String> fieldDeclarationTypes, List<String> fieldDeclarationNames, int i) {

        List<ITree> children = fieldDeclaration.getChildren();
        int index = 0;

        ITree child = children.get(index);

        while (treeContext.getTypeLabel(child).equals(MOD) ||
                treeContext.getTypeLabel(child).equals(JAVA_DOC) ||
                treeContext.getTypeLabel(child).equalsIgnoreCase(MARKER_ANNOT)) {
            index++;
            if (index < children.size()) {
                child = children.get(index);
            } else {
                break;
            }
        }

        if (index < children.size()) {
            String type = children.get(index).getLabel();
            fieldDeclarationTypes.add(i, type);
        }
        if (index + 1 < children.size()) {
            child = children.get(index + 1);
            String childType = treeContext.getTypeLabel(child);
            if (childType.equalsIgnoreCase(VAR_FRAG)) {
                List<ITree> grandChildren = child.getChildren();
                inner:
                for (ITree grandChild : grandChildren) {
                    if (treeContext.getTypeLabel(grandChild).equalsIgnoreCase(SIMPLE_NAME)) {
                        fieldDeclarationNames.add(i, grandChild.getLabel());
                        break inner;
                    }
                }
            }
        }
    }

    private void getMethodDeclarationInfo(ITree methodDeclaration, TreeContext treeContext, List<String> methodNames,
                                          List<String> returnTypes, List<Pair<Integer, Integer>> bounds, int i) throws IOException {


        String methodName = SootUtilities.getMethodName(methodDeclaration, treeContext);
        String returnType = ChangeUtil.getMethodDeclarationReturnType(methodDeclaration, treeContext);
        returnTypes.add(i, returnType);
        methodNames.add(i, methodName);


        bounds.add(i, ChangeUtil.getMethodBoundaries(methodDeclaration));
    }

    private void getMethodDeclarationSetterInfo(ITree methodDeclaration, TreeContext treeContext, List<String> methodNames,
                                                List<String> parameterTypes, List<Pair<Integer, Integer>> bounds, int i) throws IOException {
        String methodName = SootUtilities.getMethodName(methodDeclaration, treeContext);
        String parameterType = "";
        List<ITree> children = methodDeclaration.getChildren();
        for (ITree child : children) {
            if (treeContext.getTypeLabel(child).equalsIgnoreCase(SINGLE_VAR_DECL)) {
                ITree grandChild = child.getChild(0);
                parameterType = grandChild.getLabel();
                break;
            }
        }

        methodNames.add(methodName);
        parameterTypes.add(parameterType);

        bounds.add(i, ChangeUtil.getMethodBoundaries(methodDeclaration));

    }

    private void getFieldAccessesInfo(List<ITree> fieldAccesses, TreeContext treeContext, List<String> fieldNames, List<Integer> fieldAccessPositions) {
        for (int i = 0; i < fieldAccesses.size(); i++) {
            ITree fieldAccess = fieldAccesses.get(i);
            String fieldName = "";
            List<ITree> children = fieldAccess.getChildren();
            for (ITree child : children) {
                if (treeContext.getTypeLabel(child).equalsIgnoreCase(SIMPLE_NAME)) {
                    fieldName = child.getLabel();
                    break;
                }
            }
            fieldNames.add(i, fieldName);
            fieldAccessPositions.add(i, fieldAccess.getPos());
        }
    }

    private void getAssignmentsInfo(List<ITree> assignments, TreeContext treeContext, List<ITree> fieldAccesses, List<Integer> assignmentPositions) {
        for (int i = 0; i < assignments.size(); i++) {
            ITree assignment = assignments.get(i);
            ITree fieldAccess = null;
            for (ITree child : assignment.getChildren()) {
                if (treeContext.getTypeLabel(child).equalsIgnoreCase(FIELD_ACC)) {
                    fieldAccess = child;
                    break;
                }
            }
            if (fieldAccess != null) {
                fieldAccesses.add(fieldAccess);
                assignmentPositions.add(assignment.getPos());
            }
        }

    }

    private List<Integer> checkForCasualtyChanges(List<String> methodNames, List<String> methodReturnTypes,
                                                  List<Pair<Integer, Integer>> methodBounds, List<String> fieldDeclarationTypes,
                                                  List<String> fieldDeclarationNames, List<String> returnStatementLabels,
                                                  List<Integer> returnStatementPositions) {

        List<Integer> casualtyIndices = new ArrayList<>();
        for (int m = 0; m < methodNames.size(); m++) {
            String methodName = methodNames.get(m);
            if (methodName.contains("get") || methodName.contains("is")) {
                String returnType = methodReturnTypes.get(m);

                List<Integer> declarationLabelIndices = findItemInList(fieldDeclarationTypes, returnType);
                for (int declarationLabelIndex : declarationLabelIndices) {
                    if (declarationLabelIndex != -1) {
                        String declarationLabel = fieldDeclarationNames.get(declarationLabelIndex);

                        List<Integer> returnStatementIndices = findItemInList(returnStatementLabels, declarationLabel);

                        for (int returnStatementIndex : returnStatementIndices) {
                            if (returnStatementIndex != -1) {
                                int returnPos = returnStatementPositions.get(returnStatementIndex);
                                Pair<Integer, Integer> methodBound = methodBounds.get(m);
                                boolean presenceinBounds = checkPresenceInBounds(methodBound, returnPos);
                                if (presenceinBounds) {
                                    casualtyIndices.add(m);
                                }

                            }
                        }

                    }
                }
            }


        }

        return casualtyIndices;
    }

    List<Integer> findItemInList(List<String> stringList, String item) {
        List<Integer> indices = new ArrayList<>();
        for (int f = 0; f < stringList.size(); f++) {
            String declarationType = stringList.get(f);
            if (item.equalsIgnoreCase(declarationType)) {
                indices.add(f);
            }
        }
        return indices;
    }

    List<Integer> findTreeInList(List<ITree> trees, ITree item) {
        List<Integer> indices = new ArrayList<>();
        for (int f = 0; f < trees.size(); f++) {
            ITree tree = trees.get(f);
            if (item.isIsomorphicTo(tree)) {
                indices.add(f);
            }
        }
        return indices;
    }


    boolean checkPresenceInBounds(Pair<Integer, Integer> methodBounds, int nodePos) {
        return nodePos >= methodBounds.getKey() && nodePos <= methodBounds.getValue();
    }

}
