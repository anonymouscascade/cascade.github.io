package casualtydetector;

import com.github.gumtreediff.tree.ITree;
import fixdetector.ChangedNodesIdentifier;
import soot.SootMethod;
import util.Registrar;

import java.io.IOException;
import java.util.List;

public interface CasualtyChangeDetector {
    void run(ChangedNodesIdentifier changedNodesIdentifier, Registrar registrar) throws IOException;

}
