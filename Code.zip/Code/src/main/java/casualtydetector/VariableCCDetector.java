package casualtydetector;

import com.github.gumtreediff.gen.Generators;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.tree.ITree;
import com.github.gumtreediff.tree.TreeContext;
import fixdetector.ChangedNodesIdentifier;
import javafx.util.Pair;
import org.apache.commons.collections4.BidiMap;
import proganalysis.ProgramDependenceGraph;
import soot.*;
import soot.jimple.AssignStmt;
import soot.jimple.FieldRef;
import soot.jimple.InvokeStmt;
import soot.jimple.ReturnStmt;
import soot.util.Chain;
import util.ChangeUtil;
import util.Registrar;
import util.SootUtilities;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import java.util.logging.Level;

import static util.Constants.logger;

public class VariableCCDetector implements CasualtyChangeDetector {

    int type;
    String[] files;
    LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassOld = new LinkedHashMap<>();
    LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClassNew = new LinkedHashMap<>();

    PrintWriter outCasPWriter;
    PrintWriter outFineGrainedCasPWriter;

    PrintWriter outAllPWriter;

    Registrar registrar;
    HashMap<SootMethod, List<Unit>> newCasualtyInstances;
    HashMap<SootMethod, List<Unit>> oldCasualtyInstances;

    List<SootMethod> newChangedSootMethods;
    List<ITree> newChangedGumTreeMethods;

    List<SootMethod> oldChangedSootMethods;
    List<ITree> oldChangedGumTreeMethods;


    HashMap<String, String> newSootToGTSignatures = new HashMap<>();
    HashMap<String, String> oldSootToGTSignatures = new HashMap<>();
    List<MappingStore> mappingStores;

    int lineCount;
    boolean logAllChanges;

    @Override
    public void run(ChangedNodesIdentifier changedNodesIdentifier, Registrar registrar) throws IOException {
        List<Pair<Integer, ITree>> mvarChangesOld = changedNodesIdentifier.getMvarChangesOld();
        List<Pair<Integer, ITree>> mvarChangesNew = changedNodesIdentifier.getMvarChangesNew();
        mappingStores = changedNodesIdentifier.mappingStores;
        boolean proceed = (mvarChangesNew.size() > 0 || mvarChangesOld.size() > 0);

        if (proceed) {
            initiateVariables(registrar);
            initiateVariables(changedNodesIdentifier);
            initializeCasualtyRelatedVariables();

            if (mvarChangesOld.size() > 0) {
                oldCasualtyInstances = findCasualtyInstances(mvarChangesOld, changesPerMethodInClassOld, true, false);
            }

            if (mvarChangesNew.size() > 0) {
                newCasualtyInstances = findCasualtyInstances(mvarChangesNew, changesPerMethodInClassNew, false, false);
            }
            if (logAllChanges) {
                logAllTheChanges();
            }
            Set<SootMethod> casualtyOnly = propagateCasualtyInstances();
            writeCasualtiesToFile(casualtyOnly);

        }

        writeNewLineToFiles();

    }

    public void run(ChangedNodesIdentifier changedNodesIdentifier, Registrar registrar, List<SootMethod> newChangedSootMethods, List<SootMethod> oldChangedSootMethods,
                    List<ITree> newChangedGumtreeMethods, List<ITree> oldChangedGumtreeMethods) throws IOException {
        List<Pair<Integer, ITree>> mvarChangesOld = changedNodesIdentifier.getMvarChangesOld();
        List<Pair<Integer, ITree>> mvarChangesNew = changedNodesIdentifier.getMvarChangesNew();
        mappingStores = changedNodesIdentifier.mappingStores;
        boolean proceed = (mvarChangesNew.size() > 0 || mvarChangesOld.size() > 0);

        if (proceed) {
            initiateVariables(registrar);
            initiateVariables(changedNodesIdentifier);
            initializeCasualtyRelatedVariables();
            initializeSootProxyVars(newChangedSootMethods, oldChangedSootMethods, newChangedGumtreeMethods, oldChangedGumtreeMethods);

            if (mvarChangesOld.size() > 0) {
                oldCasualtyInstances = findCasualtyInstances(mvarChangesOld, changesPerMethodInClassOld, true, true);
            }

            if (mvarChangesNew.size() > 0) {
                newCasualtyInstances = findCasualtyInstances(mvarChangesNew, changesPerMethodInClassNew, false, true);
            }

            if (logAllChanges) {
                logAllTheChanges();
            }
            Set<SootMethod> casualtyOnly = propagateCasualtyInstances();
            writeCasualtiesToFile(casualtyOnly);

        }

        writeNewLineToFiles();

    }

    private void logAllTheChanges() {
        Set<String> signatures = new HashSet<>();
        for (SootMethod sootMethod : newChangedSootMethods) {
            signatures.add(sootMethod.getSignature());
        }

        for (SootMethod sootMethod : oldChangedSootMethods) {
            signatures.add(sootMethod.getSignature());
        }

        writeAllToFile(signatures);
    }

    private void writeAllToFile(Collection<String> changedSootMethods) {
        for (String sootMethod : changedSootMethods) {
            outAllPWriter.write(sootMethod + ",");
        }
    }

    private void initializeSootProxyVars(List<SootMethod> newChangedSootMethods, List<SootMethod> oldChangedSootMethods, List<ITree> newChangedGumtreeMethods, List<ITree> oldChangedGumtreeMethods) {
        this.newChangedGumTreeMethods = newChangedGumtreeMethods;
        this.newChangedSootMethods = newChangedSootMethods;
        this.oldChangedGumTreeMethods = oldChangedGumtreeMethods;
        this.oldChangedSootMethods = oldChangedSootMethods;
    }


    private void initializeCasualtyRelatedVariables() {
        newChangedSootMethods = new ArrayList<>();
        oldChangedSootMethods = new ArrayList<>();

        newChangedGumTreeMethods = new ArrayList<>();
        oldChangedGumTreeMethods = new ArrayList<>();


        oldCasualtyInstances = new HashMap<>();
        newCasualtyInstances = new HashMap<>();

    }

    private void writeCasualtiesToFile(Collection<SootMethod> finalCasualtyChangesOnly) {
        for (SootMethod sootMethod : finalCasualtyChangesOnly) {
            outCasPWriter.write(sootMethod.getSignature() + ";");
        }
    }

    private void writeNewLineToFiles() {
        outCasPWriter.write('\n');

        if (outFineGrainedCasPWriter != null)
            outFineGrainedCasPWriter.write('\n');

        if (outAllPWriter != null) {
            outAllPWriter.write('\n');
        }
    }


    private HashMap<SootMethod, List<Unit>> findCasualtyInstances(List<Pair<Integer, ITree>> mvarChangesOld, LinkedHashMap<Integer, HashMap<String,
            List<ITree>>> changesPerMethodInClassOld, boolean old, boolean sootCalculationFinished) throws IOException {
        String classPath = old ? registrar.getFirstVersionClassPath() : registrar.getSecondVersionClassPath();
        String prefix = old ? registrar.getFirstPrefix() : registrar.getSecondPrefix();

        List<SootMethod> changedSootMethods = old ? oldChangedSootMethods : newChangedSootMethods;
        List<ITree> gumTreeMethods = old ? oldChangedGumTreeMethods : newChangedGumTreeMethods;
        SootUnitProxy sootUnitProxy = new SootUnitProxy();
        if (!sootCalculationFinished) {
            sootUnitProxy.getChangedSootMethods(classPath, prefix, changedSootMethods, gumTreeMethods,
                    changesPerMethodInClassOld, files, type);
        }


        HashMap<SootMethod, List<Unit>> fieldDUs = new HashMap<>();
        getMappings(changedSootMethods, gumTreeMethods, old);
        if (old) {
            List<SootField> rootChangedFields = sootUnitProxy.findMatchingFields
                    (mvarChangesOld,
                            classPath, prefix, files, type);


            for (SootField sootField : rootChangedFields) {
                findFieldDUs(sootField, changedSootMethods, fieldDUs);

            }
        } else {
            HashMap<SootField, SootField> rootChangedFieldstoMapped = sootUnitProxy.findMatchingFields(mvarChangesOld, classPath,
                    registrar.getFirstVersionClassPath(), prefix, registrar.getFirstPrefix(), files, mappingStores, type);

            Set<SootField> rootChangedFields = rootChangedFieldstoMapped.keySet();
            List<SootMethod> mappedSootMethods = null;
            HashMap<SootField, Set<Unit>> mappedToUsages = new HashMap<>();
            ChangeUtil.setSootEnvironment(registrar.getFirstVersionClassPath());
            //for each soot field we check its corresponding field in the previous version
            for (SootField sootField : rootChangedFields) {

                SootField mapped = rootChangedFieldstoMapped.get(sootField);
                //if it exists
                if (mapped != null) {
                    if (mappedSootMethods == null) {
                        mappedSootMethods = ChangeUtil.getMappedSootMethod(newChangedGumTreeMethods, newChangedSootMethods, files, mappingStores);
                    }

                    //we find the usages of that field
                    Set<Unit> usages = new HashSet<>();
                    for (SootMethod sootMethod : mappedSootMethods) {
                        usages.addAll(findFieldUsages(mapped, sootMethod, false));
                    }

                    mappedToUsages.put(mapped, usages);
                }

            }
            ChangeUtil.setSootEnvironment(classPath);
            //then for each field
            for (SootField sootField : rootChangedFields) {

                SootField mapped = rootChangedFieldstoMapped.get(sootField);
                if (mapped != null) {


                    HashMap<SootMethod, List<Unit>> temporary = new HashMap<>();
                    for (SootMethod sootMethod : changedSootMethods) {
                        List<Unit> units = findFieldUsages(sootField, sootMethod, false);
                        for (Unit unit : units) {
                            addToMethodToUnit(sootMethod, unit, temporary);
                        }
                    }


                    //for each usage we compare the usages of the past, and only keep those that match &&
                    //those that are on return statements
                    removeUnmatchedUsages(mappedToUsages, mapped, temporary);

                    Set<SootMethod> tempKeySet = temporary.keySet();
                    //add the remianing ones
                    for (SootMethod sootMethod : tempKeySet) {
                        List<Unit> tempUnits = temporary.get(sootMethod);
                        for (Unit tempUnit : tempUnits) {
                            addToMethodToUnit(sootMethod, tempUnit, fieldDUs);
                        }
                    }

                    //add all the definitions
                    for (SootMethod sootMethod : changedSootMethods) {
                        List<Unit> current = fieldDUs.get(sootMethod);
                        List<Unit> defs = findFieldDefs(sootField, sootMethod);
                        if (defs.size() > 0) {
                            if (current == null) {
                                current = new ArrayList<>();
                            }
                            current.addAll(defs);
                            fieldDUs.put(sootMethod, current);
                        }
                    }

                } else {
                    //for each inserted one
                    //definitions all
                    //and return statements only and invocations with no dependency
                    for (SootMethod sootMethod : changedSootMethods) {
                        List<Unit> usages = findFieldUsages(sootField, sootMethod, true);

                        List<Unit> defs = findFieldDefs(sootField, sootMethod);
                        usages.addAll(defs);
                        for (Unit unit : usages) {
                            addToMethodToUnit(sootMethod, unit, fieldDUs);
                        }

                    }


                }

            }

        }
        checkIfCasualtyInstance(fieldDUs, old);
        return fieldDUs;
    }

    //this needs to be fixed
    private void removeUnmatchedUsages(HashMap<SootField, Set<Unit>> mappedToUsages,
                                       SootField mapped,
                                       HashMap<SootMethod, List<Unit>> usages) {
        Set<Unit> mappedUsages = mappedToUsages.get(mapped);
        Set<Unit> mappedMatched = new HashSet<>();
        //check all the ones that match with past ones;
        Set<SootMethod> usageMethods = usages.keySet();

        for (SootMethod usageMethod : usageMethods) {
            Set<Unit> matched = new HashSet<>();
            List<Unit> units = usages.get(usageMethod);
            outter:
            for (Unit unit : units) {
                for (Unit map : mappedUsages) {
                    if (!mappedMatched.contains(map) && areEquivalent(unit, map)) {
                        mappedMatched.add(map);
                        matched.add(unit);
                        continue outter;
                    }
                }
            }
            for (int i = 0; i < units.size(); i++) {
                Unit unit = units.get(i);
                if (!matched.contains(unit)) {
                    if (!(unit instanceof ReturnStmt) && !(unit instanceof InvokeStmt)) {
                        units.remove(unit);
                        i--;
                    }
                }
            }
        }
    }

    boolean areEquivalent(Unit unit1, Unit unit2) {

        if (!compareGenInfo(unit1, unit2)) {
            return false;
        }

        List<ValueBox> defBoxes1 = unit1.getDefBoxes();
        List<ValueBox> defBoxes2 = unit2.getDefBoxes();
        if (defBoxes1.size() != defBoxes2.size()) {
            return false;
        }

        List<ValueBox> useBoxes1 = unit1.getUseBoxes();
        List<ValueBox> useBoxes2 = unit2.getUseBoxes();

        if (useBoxes1.size() != useBoxes2.size()) {
            return false;
        }

        List<UnitBox> boxesPointingToThis1 = unit1.getBoxesPointingToThis();
        List<UnitBox> boxesPointingToThis2 = unit2.getBoxesPointingToThis();

        if (boxesPointingToThis1.size() != boxesPointingToThis2.size()) {
            return false;
        }

        List<UnitBox> unitBoxes1 = unit1.getUnitBoxes();
        List<UnitBox> unitBoxes2 = unit2.getUnitBoxes();

        return unitBoxes1.size() == unitBoxes2.size();
    }

    boolean compareGenInfo(Unit unit1, Unit unit2) {
        String class1 = unit1.getClass().toString();
        String class2 = unit2.getClass().toString();

        if (!class1.equalsIgnoreCase(class2)) {
            return false;
        }

        boolean branches1 = unit1.branches();
        boolean branches2 = unit2.branches();

        if (branches1 != branches2) {
            return false;
        }

        boolean fallsThrough1 = unit1.fallsThrough();
        boolean fallsThrough2 = unit2.fallsThrough();

        return fallsThrough1 == fallsThrough2;
    }

    Set<SootMethod> propagateCasualtyInstances(boolean old) throws IOException {
        String classPath = old ? registrar.getFirstVersionClassPath() : registrar.getSecondVersionClassPath();
        ChangeUtil.setSootEnvironment(classPath);
        HashMap<SootMethod, List<Unit>> casualtyInstancesPerMethod = old ? oldCasualtyInstances : newCasualtyInstances;
        Set<SootMethod> result = new HashSet<>();
        Iterator<Map.Entry<SootMethod, List<Unit>>> iterator = casualtyInstancesPerMethod.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<SootMethod, List<Unit>> entry = iterator.next();
            SootMethod sootMethod = entry.getKey();

            List<Unit> instances = entry.getValue();

            boolean isInstance = propagateCasualtyInstancePerMethod(sootMethod, instances, old);
            if (isInstance) {
                logger.log(Level.INFO, "all var cc: " + sootMethod.getSignature());
                result.add(sootMethod);
            }


        }

        return result;
    }

    private boolean propagateCasualtyInstancePerMethod(SootMethod sootMethod,
                                                       List<Unit> instances, boolean old) throws IOException {
        HashMap<String, String> sootToGumtreeMap = old ? oldSootToGTSignatures : newSootToGTSignatures;
        String classPath = old ? registrar.getFirstVersionClassPath() : registrar.getSecondVersionClassPath();
        ChangeUtil.setSootEnvironment(classPath);
        int fileNo = ChangeUtil.determineFileNo(old, files, sootMethod);
        String gumtreeSignature = sootToGumtreeMap.get(sootMethod.getSignature());

        List<ITree> iTrees = getChangedITreesPerMethod(old, gumtreeSignature, fileNo);
        TreeContext treeContext = Generators.getInstance().getTree(files[fileNo]).deriveTree();
        if (sootMethod.getSignature().contains("void setHeaders(org.apache.tomcat.util.http.MimeHeaders)")) {
            System.out.println("stop here");
        }
        List<Unit> changedUnits = ChangeUtil.convertToUnit(sootMethod, iTrees, treeContext);


        ProgramDependenceGraph intraProceduralPDG = ChangeUtil.constructPDGFromMethod(sootMethod);

        boolean[] presences = new boolean[changedUnits.size()];
        ChangeUtil.checkDataDependencies(sootMethod, instances, changedUnits, intraProceduralPDG, presences);

        Set<Integer> lines = new HashSet<>();
        int count = 0;
        for (int i = 0; i < presences.length; i++) {
            boolean presence = presences[i];
            if (presence) {
                count++;
                Unit unit = changedUnits.get(i);
                lines.add(unit.getJavaSourceStartLineNumber());
            }
        }
        if (lines.size() > 0 && outFineGrainedCasPWriter != null) {
            writeFineGrainedCasualties(sootMethod.getSignature(), lines);
        }

        lineCount = lineCount + lines.size();


        if (count == changedUnits.size()) {
            return true;
        } else {
            logger.log(Level.INFO, "percentage casualty: " + (float) (count / changedUnits.size()));
            countCasualties(changedUnits, presences);
            return false;
        }
    }

    void writeFineGrainedCasualties(String signature, Set<Integer> lines) {

        outFineGrainedCasPWriter.write(signature + "#");
        for (Integer line : lines) {
            outFineGrainedCasPWriter.write(line + "#");
        }
        outFineGrainedCasPWriter.write(";");
    }

    Set<SootMethod> propagateCasualtyInstances() throws IOException {
        Set<SootMethod> result = new HashSet<>();

        BidiMap<SootMethod, SootMethod> overlap = ChangeUtil.checkOverlap(oldChangedSootMethods, oldChangedGumTreeMethods,
                newChangedSootMethods, newChangedGumTreeMethods, files, mappingStores);

        List<String> overlapCovered = new ArrayList<>();
        List<SootMethod> finalCasualtyChangeOnly = new ArrayList<>();

        getOverlapingCasualtyMethods(overlap, overlapCovered, finalCasualtyChangeOnly);

        //remove all the methods which have both old and new changes
        cleanCasualtyInstanceMaps(overlapCovered);

        result.addAll(finalCasualtyChangeOnly);

        //get the results for the remaining methods
        result.addAll(propagateCasualtyInstances(true));
        result.addAll(propagateCasualtyInstances(false));


        return result;
    }

    private void cleanCasualtyInstanceMaps(List<String> overlapCovered) {
        cleanCasualtyInstanceMap(overlapCovered, true);
        cleanCasualtyInstanceMap(overlapCovered, false);

    }

    private void cleanCasualtyInstanceMap(List<String> overlapCovered, boolean old) {
        HashMap<SootMethod, List<Unit>> casualtyInstances = old ? oldCasualtyInstances : newCasualtyInstances;
        Iterator<Map.Entry<SootMethod, List<Unit>>> iterator = casualtyInstances.entrySet().iterator();

        while (iterator.hasNext()) {
            SootMethod sootMethod = iterator.next().getKey();
            if (overlapCovered.contains(sootMethod.getSignature())) {
                iterator.remove();
            }
        }

    }

    private void getOverlapingCasualtyMethods(BidiMap<SootMethod, SootMethod> sootMethodHashMap, List<String> overlapCovered,
                                              List<SootMethod> finalCasualtyChangesOnly) throws IOException {
        Set<SootMethod> oldCasualtyMethods = oldCasualtyInstances.keySet();
        Set<SootMethod> newCasualtyMethods = newCasualtyInstances.keySet();
        for (SootMethod sootMethod1 : sootMethodHashMap.keySet()) {

            SootMethod sootMethod2 = sootMethodHashMap.get(sootMethod1);

            if (oldCasualtyMethods.contains(sootMethod1) && newCasualtyMethods.contains(sootMethod2)) {

                boolean covered = propagateCasualtyChangesOverlap(sootMethod1, sootMethod2);

                if (covered) {
                    finalCasualtyChangesOnly.add(sootMethod1);
                }
            }


            overlapCovered.add(sootMethod1.getSignature());
            overlapCovered.add(sootMethod2.getSignature());
        }
    }

    public boolean propagateCasualtyChangesOverlap(SootMethod sootMethod1, SootMethod sootMethod2) throws IOException {

        boolean oldOnesCovered = propagateCasualtyInstancePerMethod(sootMethod1, oldCasualtyInstances.get(sootMethod1), true);


        boolean newOnesCovered = propagateCasualtyInstancePerMethod(sootMethod2, newCasualtyInstances.get(sootMethod2), false);


        if (oldOnesCovered && newOnesCovered) {
            logger.log(Level.INFO, "propagateCasualtyChangesOverlap: all casualty from overlap - " + sootMethod1.getSignature());
        }
        return oldOnesCovered && newOnesCovered;
    }


    private void countCasualties(List<Unit> units, boolean[] presences) {
        for (int i = 0; i < presences.length; i++) {
            boolean presence = presences[i];
            if (presence) {
                Unit unit = units.get(i);
                logger.log(Level.INFO, "unit is cc: " + unit.toString() + "@" + unit.getJavaSourceStartLineNumber());
            }
        }
    }

    /**
     * util method used to get mappings of the signatures of each method in soot and in gumtree
     * signatures in gumtree have to match the ones that are used in ChangedNodesIdentifier.changesPerMethodInClass
     *
     * @param sootMethods
     * @param gumTreeMethods
     * @param old
     * @return
     * @throws IOException
     */
    void getMappings(List<SootMethod> sootMethods, List<ITree> gumTreeMethods, boolean old) throws IOException {
        HashMap<String, String> map = old ? oldSootToGTSignatures : newSootToGTSignatures;
        for (int i = 0; i < sootMethods.size(); i++) {
            SootMethod sootMethod = sootMethods.get(i);
            ITree gumTreeMethod = gumTreeMethods.get(i);

            int fileNo = ChangeUtil.determineFileNo(old, files, sootMethod);
            TreeContext treeContext = Generators.getInstance().getTree(files[fileNo]).deriveTree();
            String gumTreeSignature = SootUtilities.getMethodName(gumTreeMethod, treeContext) + ": " + gumTreeMethod.getPos();
            map.put(sootMethod.getSignature(), gumTreeSignature);

        }

    }

    /**
     * checks if a change in a method (where a member variable is defined or used)
     * happened only because of that member variable
     * @param fieldDUs all the places where the field (member variable) is defined or referenced
     * @param old
     */
    public void checkIfCasualtyInstance(HashMap<SootMethod, List<Unit>> fieldDUs,

                                        boolean old) throws IOException {
        HashMap<String, String> sootToGumtreeMap = old ? oldSootToGTSignatures : newSootToGTSignatures;
        Iterator<Map.Entry<SootMethod, List<Unit>>> iterator = fieldDUs.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<SootMethod, List<Unit>> next = iterator.next();
            List<Unit> value = next.getValue();
            SootMethod sootMethod = next.getKey();

            int fileNo = ChangeUtil.determineFileNo(old, files, sootMethod);

            String gumtreeSignature = sootToGumtreeMap.get(sootMethod.getSignature());

            List<ITree> iTrees = getChangedITreesPerMethod(old, gumtreeSignature, fileNo);

            Body body = sootMethod.retrieveActiveBody();
            TreeContext treeContext = Generators.getInstance().getTree(files[fileNo]).deriveTree();
            //for every unit that defines or references the root change - the change involving MV
            if (iTrees == null) {
                System.out.println("Stop here");
            }
            for (int i = 0; i < value.size(); i++) {
                Unit unit = value.get(i);
                boolean match = false;
                inner:
                //for every iTree in change in the method where the field is referenced or used

                for (ITree iTree : iTrees) {

                    //is it the unit where the field is referenced
                    if (SootUtilities.isITreeUnit(iTree.getLabel(), unit, iTree, treeContext, body)) {
                        logger.log(Level.INFO, "casualty instance unit: " + unit.toString() + " @ " + unit.getJavaSourceStartLineNumber());
                        //writeCasualties(unit, sootMethod);
                        match = true;
                        break inner;

                    }
                }
                //if not remove the unit from the method list
                if (!match) {
                    value.remove(unit);
                    i--;
                }

            }
            if (value.size() > 0) {
                fieldDUs.replace(sootMethod, value);
            } else {
                //remove the methods that have no casualty instances
                iterator.remove();
            }
        }
    }

    public List<ITree> getChangedITreesPerMethod(boolean old, String gumtreeSignature, int fileNo) {
        LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClass = old ? changesPerMethodInClassOld : changesPerMethodInClassNew;

        return changesPerMethodInClass.get(fileNo).get(gumtreeSignature);
    }

//    void writeCasualties(Unit unit, SootMethod sootMethod) {
//        outCasPWriter.write(sootMethod.getSignature() + "# " + unit.toString() + " @ " + unit.getJavaSourceStartLineNumber());
//    }

    void initiateVariables(Registrar registrar) {
        type = registrar.getType();
        files = registrar.getFiles();
        this.registrar = registrar;
    }

    public void initiateVariables(ChangedNodesIdentifier changedNodesIdentifier) {
        changesPerMethodInClassNew = changedNodesIdentifier.getChangesPerMethodInClassNew();
        changesPerMethodInClassOld = changedNodesIdentifier.getChangesPerMethodInClassOld();
    }

    /**
     * finds usages and definitions of the sootfields
     *
     * @param sootField
     * @param sootClass
     */
    public void findFieldDUs(SootField sootField, SootClass sootClass) {
        List<SootMethod> sootMethodList = sootClass.getMethods();
        for (SootMethod sootMethod : sootMethodList) {
            findFieldUsages(sootField, sootMethod, false);
            findFieldDefs(sootField, sootMethod);
        }
    }

    /**
     * finds usages and definitions of the sootfields
     *
     * @param sootField
     * @param sootMethodList
     * @return
     */
    public HashMap<SootMethod, List<Unit>> findFieldDUs(SootField sootField, List<SootMethod> sootMethodList,
                                                        HashMap<SootMethod, List<Unit>> methodToUnitsMap) {
        for (SootMethod sootMethod : sootMethodList) {

            List<Unit> fieldUsages = findFieldUsages(sootField, sootMethod, false);

            for (Unit unit : fieldUsages) {
                addToMethodToUnit(sootMethod, unit, methodToUnitsMap);
            }


            List<Unit> fieldDefs = findFieldDefs(sootField, sootMethod);

            for (Unit unit : fieldDefs) {
                addToMethodToUnit(sootMethod, unit, methodToUnitsMap);
            }
        }

        return methodToUnitsMap;
    }


    public void findFieldDUs(Chain<SootField> sootFields, SootClass sootClass) {

        for (SootField sootField : sootFields) {
            findFieldDUs(sootField, sootClass);
        }
    }

    public List<Unit> findFieldUsages(SootField sootField, SootMethod sootMethod, boolean filter) {
        List<Unit> results = new ArrayList<>();

        List<ValueBox> useBoxes = sootMethod.retrieveActiveBody().getUseBoxes();
        for (ValueBox useBox : useBoxes) {
            if (useBox.getClass().getSimpleName().equalsIgnoreCase("LinkedRValueBox") && useBox.getValue() instanceof FieldRef) {
                FieldRef fieldRef = (FieldRef) useBox.getValue();
                SootField field = fieldRef.getField();
                if (field.equals(sootField)) {
                    logger.log(Level.INFO, "found a use match!" + ": " + sootMethod.getSignature() + "-" + sootField.getSignature());
                    Unit unit;
                    if (filter) {
                        unit = findUseUnitFromValueBoxWithFilter(useBox, sootMethod);
                    } else {
                        unit = findUseUnitFromValueBox(useBox, sootMethod);
                    }
                    if (unit != null && !results.contains(unit)) {
                        results.add(unit);
                    }
                }

            }
        }
        return results;
    }

    public void addToMethodToUnit(SootMethod method, Unit unit, HashMap<SootMethod, List<Unit>> methodToUnitsMap) {
        List<Unit> units;
        if (methodToUnitsMap.containsKey(method)) {
            units = methodToUnitsMap.get(method);
        } else {
            units = new ArrayList<>();
        }
        if (!units.contains(unit)) {
            units.add(unit);
        }

        methodToUnitsMap.put(method, units);

    }

    public List<Unit> findFieldDefs(SootField sootField, SootMethod sootMethod) {
        List<Unit> results = new ArrayList<>();

        List<ValueBox> defBoxes = sootMethod.retrieveActiveBody().getDefBoxes();
        for (ValueBox defBox : defBoxes) {
            if (defBox.getClass().getSimpleName().equalsIgnoreCase("LinkedVariableBox") && defBox.getValue() instanceof FieldRef) {
                FieldRef fieldRef = (FieldRef) defBox.getValue();
                SootField field = fieldRef.getField();
                if (field.equals(sootField)) {
                    logger.log(Level.INFO, ("found a def match!" + ": " + sootMethod.getSignature() + "-" + sootField.getSignature()));
                    Unit unit = findDefUnitFromValueBox(defBox, sootMethod);
                    if (unit != null && !results.contains(unit)) {
                        results.add(unit);
                    }
                }

            }
        }
        return results;
    }

    Unit findDefUnitFromValueBox(ValueBox valueBox, SootMethod sootMethod) {
        PatchingChain<Unit> units = sootMethod.retrieveActiveBody().getUnits();
        for (Unit unit : units) {
            if (unit instanceof AssignStmt) {
                AssignStmt assignStmt = (AssignStmt) unit;
                //TODO: check the impact of commenting out the right part of the assignment this
                //did this because in CVE-2010-2227_1 HTTPNioProcessor addInputFilter
                if (assignStmt.getLeftOp().equals(valueBox.getValue())) { // || assignStmt.getRightOp().equals(valueBox.getValue())) {
                    return unit;
                }
            }
        }
        return null;
    }

    //used in cases when variables are inserted
    Unit findUseUnitFromValueBoxWithFilter(ValueBox valueBox, SootMethod sootMethod) {
        PatchingChain<Unit> units = sootMethod.retrieveActiveBody().getUnits();
        for (Unit unit : units) {
            //for getters
            if (unit instanceof ReturnStmt) {
                ReturnStmt returnStmt = (ReturnStmt) unit;
                if (returnStmt.getOp().equals(valueBox.getValue())) { // || assignStmt.getRightOp().equals(valueBox.getValue())) {
                    return unit;
                } else {
                    int line = ChangeUtil.getUnitLineNumber(unit);
                    List<ValueBox> useBoxes = returnStmt.getUseBoxes();

                    for (ValueBox useBox : useBoxes) {
                        if (useBox.getValue().equals(valueBox.getValue())) {
                            return unit;
                        }

                        Unit defUnit = findDefUnitFromValueBox(useBox, sootMethod);
                        if (defUnit != null && ChangeUtil.getUnitLineNumber(defUnit) == line && defUnit instanceof AssignStmt) {
                            AssignStmt assignStmt = (AssignStmt) defUnit;
                            if (assignStmt.getRightOp().equals(valueBox.getValue())) {
                                return unit;
                            }
                        }


                    }

                }
            }

            //operations on the variable like clear or add are handled here
            if (unit instanceof InvokeStmt) {
                List<ValueBox> useBoxes = unit.getUseBoxes();
                if (unit.fallsThrough() && unit.getBoxesPointingToThis().size() == 0) {

                    int unitLine = ChangeUtil.getUnitLineNumber(unit);

                    for (ValueBox useBox : useBoxes) {
                        Unit definition = findDefUnitFromValueBox(useBox, sootMethod);
                        if (definition instanceof AssignStmt && ChangeUtil.getUnitLineNumber(definition) == unitLine) {
                            AssignStmt assignStmt = (AssignStmt) definition;
                            if (assignStmt.getRightOp().equals(valueBox.getValue())) {
                                return unit;
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    Unit findUseUnitFromValueBox(ValueBox valueBox, SootMethod sootMethod) {
        PatchingChain<Unit> units = sootMethod.retrieveActiveBody().getUnits();
        for (Unit unit : units) {
            //for getters
            if (unit instanceof ReturnStmt) {
                ReturnStmt returnStmt = (ReturnStmt) unit;
                if (returnStmt.getOp().equals(valueBox.getValue())) { // || assignStmt.getRightOp().equals(valueBox.getValue())) {
                    return unit;
                } else {
                    List<ValueBox> useBoxes = returnStmt.getUseBoxes();
                    for (ValueBox useBox : useBoxes) {
                        if (useBox.getValue().equals(valueBox.getValue())) {
                            return unit;
                        }
                    }

                }
            }
            if (unit instanceof InvokeStmt) {
                List<ValueBox> useBoxes = unit.getUseBoxes();
                if (unit.fallsThrough() && unit.getBoxesPointingToThis() == null) {

                    int unitLine = ChangeUtil.getUnitLineNumber(unit);

                    for (ValueBox useBox : useBoxes) {
                        Unit definition = findDefUnitFromValueBox(useBox, sootMethod);
                        if (definition instanceof AssignStmt && ChangeUtil.getUnitLineNumber(definition) == unitLine) {
                            AssignStmt assignStmt = (AssignStmt) definition;
                            if (assignStmt.getRightOp().equals(valueBox.getValue())) {
                                return unit;
                            }
                        }
                    }
                }
            }

            if (unit instanceof AssignStmt) {
                AssignStmt assignStmt = (AssignStmt) unit;
                if (assignStmt.getRightOp().equals(valueBox.getValue())) {
                    return unit;
                }
            }
        }
        return null;
    }

    public void setOutCasPWriter(PrintWriter outVarCasPWriter) {
        this.outCasPWriter = outVarCasPWriter;
    }

    public void setOutFineGrainedCasPWriter(PrintWriter outVarFineGrainedCasPWriter) {
        this.outFineGrainedCasPWriter = outVarFineGrainedCasPWriter;
    }

    public int getLineCount() {
        return lineCount;
    }

    public void setLogAllChanges(boolean logAllChanges) {
        this.logAllChanges = logAllChanges;
    }

    public void setOutAllPWriter(PrintWriter outAllPWriter) {
        this.outAllPWriter = outAllPWriter;
    }
}
