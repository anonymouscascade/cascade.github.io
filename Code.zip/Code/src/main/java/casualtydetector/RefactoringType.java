package casualtydetector;

public enum RefactoringType {
    INLINE_METHOD, EXTRACT_METHOD
}
