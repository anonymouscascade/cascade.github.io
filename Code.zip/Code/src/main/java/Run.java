import casualtydetector.APICCDetector;
import casualtydetector.RefactoringCCDetector;
import casualtydetector.VariableCCDetector;
import com.github.gumtreediff.gen.Generators;
import com.github.gumtreediff.tree.ITree;
import com.github.gumtreediff.tree.TreeContext;
import fixdetector.ChangedNodesIdentifier;
import soot.G;
import soot.SootMethod;
import util.ChangeUtil;
import util.Registrar;
import util.SootUtilities;

import java.io.*;
import java.util.*;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.SimpleFormatter;

import static util.Constants.logger;

public class Run {

    HashMap<String, String> configurations;

    //output files variables
    PrintWriter outAPICasPWriter;
    PrintWriter outAPIFineGrainedCasPWriter;
    PrintWriter outVarCasPWriter;
    PrintWriter outVarFineGrainedCasPWriter;
    PrintWriter outRefCasPWriter;
    PrintWriter outRefFineGrainedCasPWriter;
    PrintWriter outAllPWriter;
    PrintWriter outSystemPWriter;
    PrintWriter outProcessedPWriter;
    String inputFile;


    File outAPICas;
    FileWriter outAPICasWriter;

    File outAPIFineGrainedCas;
    FileWriter outAPIFineGrainedCasWriter;

    File outVarCas;
    FileWriter outVarCasWriter;

    File outVarFineGrainedCas;
    FileWriter outVarFineGrainedCasWriter;

    File outRefCas;
    FileWriter outRefCasWriter;

    File outRefFineGrainedCas;
    FileWriter outRefFineGrainedCasWriter;

    File outAll;
    FileWriter outAllWriter;

    File outSystem = new File("system.out");
    FileWriter outSystemWriter;

    File outProcessed;
    FileWriter outProcessedWriter;

    File lineCounter;
    FileWriter lineCounterWriter;
    PrintWriter lineCounterPWriter;

    //tasks to be carried out
    boolean allChanges;
    boolean apiCasualties;
    boolean apiFineGrainedCasualties;
    boolean varCasualties;
    boolean varFineGrainedCasualties;
    boolean refCasualties;
    boolean refFineGrainedCasualties;


    //if the program should print out methods that have only casualties
    boolean casualtyOnly;

    //if the program should print out methods that include casualties
    boolean casualtiesIncluded;

    //this variable corresponds to the type of subject systems we are running our tool on
    int revisionType;

    //this variable contains the list of files which were changed through a patch
    String[] files;

    //soot related variables
    String firstVersionClassPath;
    String secondVersionClassPath;
    String firstPrefix;
    String secondPrefix;
    String systemName;

    List<SootMethod> newChangedSootMethods;
    List<SootMethod> oldChangedSootMethods;

    List<ITree> newChangedGumtreeMethods;
    List<ITree> oldChangedGumtreeMethods;
    FileHandler fileHandler;



    public String getInputFile() {
        return inputFile;
    }

    /**
     * Main class, takes as input paths to files involved in the patch, and it produces patterns for them
     *
     * @param args - array of @{@link String}, where each element represented as the comma separated values (paths of files involved in a vulnerability patch).
     */
    public static void main(String[] args) throws IOException {

        String file = args[0];

        Run run = new Run();
        run.loadConfigFile(file);
        run.run();
        run.closeFiles();


    }

    void loadConfigFile(String filePath) throws IOException {
        File file = new File(filePath);
        configurations = new HashMap<>();
        if (!file.exists()) {
            System.err.println("Configuration file at: " + filePath + " doesn't exist");
            System.exit(-1);
        } else {
            Scanner in = new Scanner(file);
            while (in.hasNext()) {
                String line = in.nextLine();
                if (!line.startsWith("#") && line.contains("=")) {
                    if(line.split("=").length==2)
                    configurations.put(line.split("=")[0].trim(), line.split("=")[1].trim());
                }
            }
        }
        fileHandler = new FileHandler(configurations.get("logger"));
        lineCounter = new File(configurations.get("lineCounter"));
        outProcessed = new File(configurations.get("processed"));



        if(configurations.containsKey("inputFile")){
            inputFile = configurations.get("inputFile");
        }
        else{
            System.err.println("Input filepath missing.");
            System.exit(-1);
        }

        if(configurations.containsKey("revisionType")){
            revisionType = Integer.parseInt(configurations.get("revisionType"));
        }
        else{
            System.err.println("Revision type missing. This might affect the results.");
        }


        if(configurations.containsKey("allChanges")){
            outAll = new File(configurations.get("allChanges"));
            allChanges = true;
        } else{
            allChanges = false;
        }

        if(configurations.containsKey("apiCasualties")){
            outAPICas = new File(configurations.get("apiCasualties"));
            apiCasualties = true;
        }

        else{
            apiCasualties = false;
        }
        if(configurations.containsKey("apiFineGrainedCasualties")){
            outAPIFineGrainedCas = new File(configurations.get("apiFineGrainedCasualties"));
            apiFineGrainedCasualties = true;
        } else{
            apiFineGrainedCasualties = false;
        }

        if(configurations.containsKey("varCasualties")){
            outVarCas = new File(configurations.get("varCasualties"));
            varCasualties = true;
        }
        else{
            varCasualties = false;
        }

        if (configurations.containsKey("varFineGrainedCasualties")) {
            outVarFineGrainedCas = new File(configurations.get("varFineGrainedCasualties"));
            varFineGrainedCasualties = true;
        } else {
            varFineGrainedCasualties = false;
        }

        if (configurations.containsKey("refCasualties")) {
            outRefCas = new File(configurations.get("refCasualties"));
            refCasualties = true;
        } else {
            refCasualties = false;
        }

        if (configurations.containsKey("refFineGrainedCasualties")) {
            outRefFineGrainedCas = new File(configurations.get("refFineGrainedCasualties"));
            refFineGrainedCasualties = true;
        } else {
            refFineGrainedCasualties = false;
        }

        casualtyOnly = configurations.containsKey("casualtyOnly");

        casualtiesIncluded = configurations.containsKey("casualtyIncluded");


    }

    private boolean checkIfBuilt(){
        File firstVersionClassPathDir = new File(firstVersionClassPath);
        File secondVersionClassPathDir = new File(secondVersionClassPath);

        return firstVersionClassPathDir.exists() && //firstVersionClassPathDir.isDirectory() &&
                secondVersionClassPathDir.exists(); //&& secondVersionClassPathDir.isDirectory();

    }
    private void reset() {
        files = null;
        firstVersionClassPath = null;
        secondVersionClassPath = null;
        firstPrefix = null;
        secondPrefix = null;
        systemName = null;

        newChangedSootMethods = null;
        oldChangedSootMethods = null;

        newChangedGumtreeMethods = null;
        oldChangedGumtreeMethods = null;

    }

    private void initializeClassPaths(String firstVersionClassPath, String secondVersionClassPath){
        this.firstVersionClassPath = firstVersionClassPath;
        this.secondVersionClassPath = secondVersionClassPath;
    }

    private void run() throws IOException {
        initiateFiles();
        log();
        Scanner in = new Scanner(new File(inputFile));
        while(in.hasNext()) {
            try {
                G.reset();
                List<String> processedRevisions = getProcessedRevisions();
                String line = in.nextLine();
                String[] subsetArgs = getSubsetArgs(line);
                if (subsetArgs.length > 1) {

                    List<String> nonEmptyArgs = getNonEmptyStrings(subsetArgs);
                    String revNumber = getRevNumber(revisionType, subsetArgs[1]);
                    logger.log(Level.INFO, "rev number: " + revNumber);

                    if (nonEmptyArgs.size() >= 6 && !processedRevisions.contains(revNumber)) {
                        initializeClassPaths(nonEmptyArgs.get(0), nonEmptyArgs.get(1));
                        if (checkIfBuilt()) {

                            writeRevNumberToFiles(revNumber);

                            initializeRemainingVariables(nonEmptyArgs);
                            ChangedNodesIdentifier changedNodesIdentifier = new ChangedNodesIdentifier();
                            changedNodesIdentifier.setApiChanges(apiCasualties);
                            changedNodesIdentifier.setMvarChanges(varCasualties);
                            changedNodesIdentifier.run(files);
                            int countLine = changedNodesIdentifier.getLineCount();
                            lineCounterPWriter.write(countLine + "\t");


                            Registrar registrar = getRegistrar(revNumber);
                            int casualtiesLines = 0;

//                            if(allChanges){
//                                SootUnitProxy sootUnitProxy = new SootUnitProxy();
//                                initializeSootLists();
//                                sootUnitProxy.getChangedSootMethods(firstVersionClassPath, firstPrefix, oldChangedSootMethods, oldChangedGumtreeMethods,
//                                        changedNodesIdentifier.changesPerMethodInClassOld, files, revisionType);
//
//                                sootUnitProxy.getChangedSootMethods(secondVersionClassPath, secondPrefix, newChangedSootMethods, newChangedGumtreeMethods,
//                                        changedNodesIdentifier.changesPerMethodInClassNew, files, revisionType);
//
//                                logAllTheChanges();
//                                VariableCCDetector variableCCDetector = getVariableCCDetector();
//                                variableCCDetector.run(changedNodesIdentifier, registrar, newChangedSootMethods, oldChangedSootMethods, newChangedGumtreeMethods, oldChangedGumtreeMethods);
//                                casualtiesLines = casualtiesLines + variableCCDetector.getLineCount();
//
//                                RefactoringCCDetector refactoringCCDetector = getRefactoringCCDetector();
//                                refactoringCCDetector.run(changedNodesIdentifier, registrar, newChangedSootMethods, oldChangedSootMethods, newChangedGumtreeMethods, oldChangedGumtreeMethods);
//                                casualtiesLines = casualtiesLines + refactoringCCDetector.getLineCount();
//
//
//                            } else {
                                if (apiCasualties) {
                                    APICCDetector apiccDetector = getAPICCDetector();
                                    apiccDetector.run(changedNodesIdentifier, registrar);
                                    casualtiesLines = casualtiesLines + apiccDetector.getLineCount();
                                }
                                if (varCasualties) {
                                    VariableCCDetector variableCCDetector = getVariableCCDetector();
                                    variableCCDetector.run(changedNodesIdentifier, registrar);
                                    casualtiesLines = casualtiesLines + variableCCDetector.getLineCount();
                                }
                                if (refCasualties) {
                                    RefactoringCCDetector refactoringCCDetector = getRefactoringCCDetector();
                                    refactoringCCDetector.run(changedNodesIdentifier, registrar);
                                    casualtiesLines = casualtiesLines + refactoringCCDetector.getLineCount();
                                }
                            //}
                            lineCounterPWriter.write(casualtiesLines + "\t");

                        } else {
                            logger.log(Level.INFO, "The revision is not built.");

                        }
                    } else {
                        logger.log(Level.INFO, "No source code files found.");


                    }
                }
                writeNewLineToFiles();


                G.reset();
            } catch (RuntimeException | IOException rte) {
                writeNewLineToFiles();
                logger.log(Level.FINEST, "Exception: " + Arrays.toString(rte.getStackTrace()));
                System.out.println(rte.getMessage());
                System.out.println(Arrays.toString(rte.getStackTrace()));

            }
            finally {
                reset();
                continue;
            }

        }
    }

    List<ITree> getChangedITreesPerMethod(boolean old, SootMethod sootMethod, ChangedNodesIdentifier changedNodesIdentifier, int fileNo) throws IOException {

        List<SootMethod> sootMethods = old ? oldChangedSootMethods : newChangedSootMethods;
        List<ITree> gumtreeMethods = old ? oldChangedGumtreeMethods : newChangedGumtreeMethods;
        ITree gumtree = gumtreeMethods.get(sootMethods.indexOf(sootMethod));
        TreeContext treeContext = Generators.getInstance().getTree(files[fileNo]);
        String gumtreeSignature = SootUtilities.getMethodName(gumtree, treeContext) + ": " + gumtree.getPos();

        LinkedHashMap<Integer, HashMap<String, List<ITree>>> changesPerMethodInClass = old ? changedNodesIdentifier.changesPerMethodInClassOld : changedNodesIdentifier.changesPerMethodInClassNew;


        return changesPerMethodInClass.get(fileNo).get(gumtreeSignature);
    }

    private void logAllTheChanges(){
        writeAllToFile(newChangedSootMethods);
        writeAllToFile(oldChangedSootMethods);
    }

    private void writeAllToFile(List<SootMethod> changedSootMethods) {
        for (SootMethod sootMethod : changedSootMethods) {
            outAllPWriter.write(sootMethod.getSignature() + ",");
        }
    }

    private APICCDetector getAPICCDetector() {
        APICCDetector apiccDetector = new APICCDetector();
        apiccDetector.setOutCausFineGrainedPWriter(outAPIFineGrainedCasPWriter);
        apiccDetector.setOutCausPWriter(outAPICasPWriter);
        apiccDetector.setOutSystemPWriter(outSystemPWriter);
        return apiccDetector;
    }

    private VariableCCDetector getVariableCCDetector() {
        VariableCCDetector variableCCDetector = new VariableCCDetector();
        variableCCDetector.setOutCasPWriter(outVarCasPWriter);
        variableCCDetector.setOutFineGrainedCasPWriter(outVarFineGrainedCasPWriter);
        if (allChanges) {
            variableCCDetector.setLogAllChanges(true);
            variableCCDetector.setOutAllPWriter(outAllPWriter);
        }
        return variableCCDetector;
    }

    private RefactoringCCDetector getRefactoringCCDetector() {
        RefactoringCCDetector refactoringCCDetector = new RefactoringCCDetector();
        refactoringCCDetector.setOutCausPWriter(outRefCasPWriter);
        refactoringCCDetector.setOutFineGrainedCasPWriter(outRefFineGrainedCasPWriter);
        refactoringCCDetector.setOutSystemPWriter(outSystemPWriter);
        return refactoringCCDetector;
    }

    private Registrar getRegistrar(String revNumber) {
        Registrar registrar = new Registrar();
        registrar.setFiles(files);
        registrar.setFirstPrefix(firstPrefix);
        registrar.setSecondPrefix(secondPrefix);
        registrar.setFirstVersionClassPath(firstVersionClassPath);
        registrar.setSecondVersionClassPath(secondVersionClassPath);
        registrar.setSystemName(systemName);
        registrar.setRevNumber(revNumber);
        registrar.setType(revisionType);
        return registrar;
    }

    private String[] getSubsetArgs(String line) {
        String[] subsetArgs = line.split(",");
        subsetArgs = Arrays.copyOfRange(subsetArgs, 0, subsetArgs.length - 1);
        return subsetArgs;
    }

    private void initializeRemainingVariables(List<String> nonEmptyArgs) {
        firstPrefix = nonEmptyArgs.get(2);
        systemName = nonEmptyArgs.get(nonEmptyArgs.size() - 1);
        secondPrefix = nonEmptyArgs.get(3);

        files = new String[nonEmptyArgs.size() - 4];

        for (int i = 4; i < nonEmptyArgs.size(); i++) {
            files[i - 4] = nonEmptyArgs.get(i);
        }
    }


    private void writeRevNumberToFiles(String revNumber) {

        outProcessedPWriter.write(revNumber + "\n");
        lineCounterPWriter.write(revNumber + "\t");
        if (apiCasualties)
            outAPICasPWriter.write(revNumber + ";");

        if (allChanges)
            outAllPWriter.write(revNumber + ";");

        if (apiFineGrainedCasualties)
            outAPIFineGrainedCasPWriter.write(revNumber + ";");

        if (varCasualties) {
            outVarCasPWriter.write(revNumber + ";");
        }

        if (varFineGrainedCasualties)
            outVarFineGrainedCasPWriter.write(revNumber + ";");

        if (refCasualties)
            outRefCasPWriter.write(revNumber + ";");

        if (refFineGrainedCasualties)
            outRefFineGrainedCasPWriter.write(revNumber + ";");


    }

    private void writeNewLineToFiles() {
        if (allChanges)
            outAllPWriter.write('\n');

        if (apiCasualties)
            outAPICasPWriter.write('\n');

        if (apiFineGrainedCasualties)
            outAPIFineGrainedCasPWriter.write('\n');

        if (varCasualties)
            outVarCasPWriter.write('\n');

        if (varFineGrainedCasualties)
            outVarFineGrainedCasPWriter.write('\n');

        if (refCasualties)
            outRefCasPWriter.write('\n');

        if (refFineGrainedCasualties)
            outRefFineGrainedCasPWriter.write('\n');

        outSystemPWriter.write('\n');
        lineCounterPWriter.write("\n");
    }


    /**
     * utility method used to get the revision number for subject systems we use
     *
     * @param type     the type of subject system (nonessential, security dataset, locus)
     * @param filepath
     * @return
     */
    private String getRevNumber(int type, String filepath) {
        //type 1 is security dataset
        if (type == 1) {
            return SootUtilities.getCVEName(filepath);
        } //type 2 is nonessential paper
        else if (type == 2) {
            return ChangeUtil.getRevisionNumber(filepath);
        }  //type 3 is locus paper located in homedrive directory
        else if (type == 3) {
            return ChangeUtil.getRevisionNumberForCC(filepath);
        } //type 4
        else {
            return ChangeUtil.getRevisionNumberForCC2(filepath);
        }

    }

    private List<String> getProcessedRevisions() throws FileNotFoundException {
        List<String> processedRevisions = new ArrayList<>();
        if(outProcessed.exists() && outProcessed.isFile()) {
            Scanner in = new Scanner(outProcessed);
            while (in.hasNext()) {
                String revision = in.nextLine().trim();
                if (!processedRevisions.contains(revision)) {
                    processedRevisions.add(revision);
                }
            }
        }
        return processedRevisions;
    }


    private List<String> getNonEmptyStrings(String[] subsetArgs) {
        List<String> nonEmptyArgs = new ArrayList<>(Arrays.asList(subsetArgs));
        for (int i = 0; i < nonEmptyArgs.size(); i++) {
            String oneArg = nonEmptyArgs.get(i);
            if (oneArg.isEmpty() || oneArg.equals("\"") || oneArg.contains("test") || oneArg.contains("Test")) {
                nonEmptyArgs.remove(oneArg);
                i--;
            }

        }
        return nonEmptyArgs;
    }

    public void initiateFiles() throws IOException {
        if(apiCasualties) {
            if (outAPICas.exists() && outAPICas.isFile()) {
                outAPICasWriter = new FileWriter(outAPICas, true);
            } else {
                outAPICasWriter = new FileWriter(outAPICas);
            }
            outAPICasPWriter = new PrintWriter(outAPICasWriter);
        }

        if (apiFineGrainedCasualties) {
            if (outAPIFineGrainedCas.exists() && outAPIFineGrainedCas.isFile()) {
                outAPIFineGrainedCasWriter = new FileWriter(outAPIFineGrainedCas, true);
            } else {
                outAPIFineGrainedCasWriter = new FileWriter(outAPIFineGrainedCas);
            }
            outAPIFineGrainedCasPWriter = new PrintWriter(outAPIFineGrainedCasWriter);
        }

        if (varCasualties) {
            if (outVarCas.exists() && outVarCas.isFile()) {
                outVarCasWriter = new FileWriter(outVarCas, true);
            } else {
                outVarCasWriter = new FileWriter(outVarCas);
            }
            outVarCasPWriter = new PrintWriter(outVarCasWriter);
        }

        if (varFineGrainedCasualties) {
            if (outVarFineGrainedCas.exists() && outVarFineGrainedCas.isFile()) {
                outVarFineGrainedCasWriter = new FileWriter(outVarFineGrainedCas, true);
            } else {
                outVarFineGrainedCasWriter = new FileWriter(outVarFineGrainedCas);
            }
            outVarFineGrainedCasPWriter = new PrintWriter(outVarFineGrainedCasWriter);
        }

        if (refCasualties) {
            if (outRefCas.exists() && outRefCas.isFile()) {
                outRefCasWriter = new FileWriter(outRefCas, true);
            } else {
                outRefCasWriter = new FileWriter(outRefCas);
            }

            outRefCasPWriter = new PrintWriter(outRefCasWriter);
        }

        if (refFineGrainedCasualties) {
            if (outRefFineGrainedCas.exists() && outRefFineGrainedCas.isFile()) {
                outRefFineGrainedCasWriter = new FileWriter(outRefFineGrainedCas, true);
            } else {
                outRefFineGrainedCasWriter = new FileWriter(outRefFineGrainedCas, true);
            }

            outRefFineGrainedCasPWriter = new PrintWriter(outRefFineGrainedCasWriter);
        }


        if (allChanges) {
            if (outAll.isFile() && outAll.exists()) {
                outAllWriter = new FileWriter(outAll, true);
            } else {
                outAllWriter = new FileWriter(outAll);
            }
            outAllPWriter = new PrintWriter(outAllWriter);
        }

        if (outSystem.exists() && outSystem.isFile()) {
            outSystemWriter = new FileWriter(outSystem, true);
        } else {
            outSystemWriter = new FileWriter(outSystem);
        }
        outSystemPWriter = new PrintWriter(outSystemWriter);


        if (outProcessed.isFile() && outProcessed.exists()) {
            outProcessedWriter = new FileWriter(outProcessed, true);
        } else {
            outProcessedWriter = new FileWriter(outProcessed);

        }
        outProcessedPWriter = new PrintWriter(outProcessedWriter);

        if (lineCounter.isFile() && lineCounter.exists()) {
            lineCounterWriter = new FileWriter(lineCounter, true);
        } else {
            lineCounterWriter = new FileWriter(lineCounter);

        }

        lineCounterPWriter = new PrintWriter(lineCounterWriter);


    }

    public void closeFiles() throws IOException {
        if (apiCasualties) {
            outAPICasWriter.close();
            outAPICasPWriter.close();
        }

        if (apiFineGrainedCasualties) {
            outAPIFineGrainedCasWriter.close();
            outAPIFineGrainedCasPWriter.close();
        }

        if (varCasualties) {
            outVarCasWriter.close();
            outVarCasPWriter.close();
        }

        if (varFineGrainedCasualties) {
            outVarFineGrainedCasWriter.close();
            outVarCasPWriter.close();
        }

        if (refCasualties) {
            outRefCasWriter.close();
            outRefCasPWriter.close();
        }

        if (refFineGrainedCasualties) {
            outRefFineGrainedCasWriter.close();
            outRefFineGrainedCasPWriter.close();
        }

        if (allChanges) {
            outAllWriter.close();
            outAllPWriter.close();
        }


        outSystemWriter.close();
        outProcessedWriter.close();

        outSystemPWriter.close();
        outProcessedPWriter.close();

        lineCounterWriter.close();
        lineCounterPWriter.close();

        fileHandler.close();
    }

    private void initializeSootLists() {
        newChangedSootMethods = new ArrayList<>();
        oldChangedSootMethods = new ArrayList<>();

        newChangedGumtreeMethods = new ArrayList<>();
        oldChangedGumtreeMethods = new ArrayList<>();

    }

    void log() {
        logger.addHandler(fileHandler);
        SimpleFormatter formatter = new SimpleFormatter();
        fileHandler.setFormatter(formatter);
    }
}






